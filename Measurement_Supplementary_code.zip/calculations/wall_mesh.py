"""Resolution dependence of the eight one-particle proxy shifts at fixed domain."""
from pathlib import Path
import runpy
import numpy as np
src=Path(__file__).resolve().parent
m=runpy.run_path(str(next(src.glob('15_*.py'))))
previous=None
rows=[]
for n in (1300,2600,5200,10400):
    k=m['eig_k'](N=n)
    delta=m['bog_omega'](k)/m['bog_omega'](m['k_hard'])-1
    dif=np.nan if previous is None else np.max(np.abs(delta-previous))
    rows.append([n,*delta,dif])
    previous=delta
np.savetxt(src.parent/'outputs/wall_mesh.csv',rows,delimiter=',',header='N,'+','.join('shift_j'+str(j) for j in range(1,9))+',max_change_from_preceding_grid',comments='')
print(np.array(rows)[:,[0,1,8,-1]])
