#!/usr/bin/env python3
"""
Diagnostic finite-wall identifiability check.

Uses a 1D finite-square-well phase condition
    k L + 2 atan(k/kappa) = pi j,
    kappa = sqrt(kappa0^2-k^2),  kappa0=sqrt(2mV0)/hbar,
to test whether energy-dependent wall penetration breaks the exact hard-wall
scale degeneracy for a phenomenological uniform spectral factor s.

This is a diagnostic model only, not a quantitative model of an optical box.
"""
import numpy as np
from scipy.optimize import brentq

HBAR=1.054571817e-34
AMU=1.66053906660e-27
M=87*AMU
A=5.3e-9
N_DENS=1e20
XI0=1/np.sqrt(8*np.pi*N_DENS*A)
L0=5e-6
J=6


def k_modes(L,V0,J=J):
    k0=np.sqrt(2*M*V0)/HBAR
    out=[]
    for j in range(1,J+1):
        kinf=np.pi*j/L
        hi=min(kinf*(1-1e-12),k0*(1-1e-12))
        def f(k):
            kap=np.sqrt(max(k0*k0-k*k,1e-300))
            return k*L+2*np.arctan(k/kap)-np.pi*j
        # Valid bound states require f(hi)>0. For the chosen barriers it is.
        if f(hi)<=0:
            raise RuntimeError(f'no bound root for j={j}, k0L={k0*L}')
        out.append(brentq(f,1e-16/L,hi,xtol=1e-14/L,rtol=1e-13))
    return np.array(out)


def logfreq(xi,L,V0):
    k=k_modes(L,V0)
    c=HBAR/(np.sqrt(2)*M*xi)
    return np.log(c*k*np.sqrt(1+(k*xi)**2/2))


def deriv_ln(param,xi,L,V0,h=1e-5):
    vals=[xi,L,V0]
    i={'xi':0,'L':1,'V0':2}[param]
    vp=vals.copy(); vm=vals.copy()
    vp[i]*=np.exp(h); vm[i]*=np.exp(-h)
    return (logfreq(*vp)-logfreq(*vm))/(2*h)


def residual(signal,Z):
    Q=np.linalg.qr(Z,mode='reduced')[0]
    r=signal-Q@(Q.T@signal)
    return np.linalg.norm(r)/np.linalg.norm(signal),np.linalg.norm(r)

print('=== FINITE-WALL IDENTIFIABILITY DIAGNOSTIC ===')
print(f'xi={XI0*1e6:.6f} um, L={L0*1e6:.3f} um, modes j=1..{J}')
print('Model: 1D finite square barrier; diagnostic only.')
print()
for k0L in [20,30,50,100,200]:
    k0=k0L/L0
    V0=(HBAR*k0)**2/(2*M)
    dxi=deriv_ln('xi',XI0,L0,V0)
    dL=deriv_ln('L',XI0,L0,V0)
    dV=deriv_ln('V0',XI0,L0,V0)
    one=np.ones(J)
    frac_fixed,_=residual(one,np.column_stack([dxi,dL]))
    frac_float,_=residual(one,np.column_stack([dxi,dL,dV]))
    rank_fixed=np.linalg.matrix_rank(np.column_stack([one,dxi,dL]),tol=1e-10)
    rank_float=np.linalg.matrix_rank(np.column_stack([one,dxi,dL,dV]),tol=1e-10)
    # Scale identity when V0 is floated: common lambda with V0->lambda^-2 V0.
    ident=np.max(np.abs(dxi+dL-2*dV+2*one))
    print(f'kappa0 L={k0L:3d}: fixed-V0 rank={rank_fixed}/3, signal orth.frac={frac_fixed:.3e}; '
          f'float-V0 rank={rank_float}/4, signal orth.frac={frac_float:.3e}; scale-id residual={ident:.3e}')
