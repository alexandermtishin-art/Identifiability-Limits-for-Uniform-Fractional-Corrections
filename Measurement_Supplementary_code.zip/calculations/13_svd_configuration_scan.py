#!/usr/bin/env python3
"""SVD visualization of configuration-scan identifiability.

Compares the column-normalized Jacobian singular values for:
  (i) a global phenomenological uniform shift s, and
  (ii) a global DG-motivated coefficient c_scr with s_r=c_scr*eta_r,
      eta_r=(xi_r/L_r)^2.

Also scans the eta-range and tracks the smallest singular value.
"""
from pathlib import Path
import numpy as np
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parents[1]
FIGDIR = ROOT / "figures"
OUTDIR = ROOT / "outputs"
FIGDIR.mkdir(exist_ok=True)
OUTDIR.mkdir(exist_ok=True)

A = 5.3e-9
N_DENS = 1e20
L0 = 5e-6
C_SCR = 0.00833
XI0 = 1 / np.sqrt(8 * np.pi * N_DENS * A)


def jacobian_scan(J, L_ratios, xi_ratios, model):
    rows = []
    for lr, xr in zip(L_ratios, xi_ratios):
        j = np.arange(1, J + 1, dtype=float)
        xi = XI0 * xr
        L = L0 * lr
        eta = (xi / L) ** 2
        u = (np.pi * j * xi / L) ** 2 / 2
        dxi_B = -1 / (1 + u)
        dL_B = -(1 + 2 * u) / (1 + u)
        if model == "uniform":
            rows.append(np.column_stack([np.ones_like(j), dxi_B, dL_B]))
        elif model == "dg":
            fac = (C_SCR * eta) / (1 + C_SCR * eta)
            dc = np.full_like(j, eta / (1 + C_SCR * eta))
            dxi = dxi_B + 2 * fac
            dL = dL_B - 2 * fac
            rows.append(np.column_stack([dc, dxi, dL]))
        else:
            raise ValueError(model)
    return np.vstack(rows)


def normalized_singular_values(J):
    X = J / np.linalg.norm(J, axis=0)
    return np.linalg.svd(X, compute_uv=False)


Lr = np.array([0.7, 1.0, 1.4, 0.8, 1.2])
Xr = np.array([1.2, 1.0, 0.8, 0.7, 1.4])
sv_uniform = normalized_singular_values(jacobian_scan(4, Lr, Xr, "uniform"))
sv_dg = normalized_singular_values(jacobian_scan(4, Lr, Xr, "dg"))

for model in ("uniform", "dg"):
    matrix = jacobian_scan(4, Lr, Xr, model)
    np.savetxt(OUTDIR / f"{model}_matrix.csv", matrix, delimiter=",", fmt="%.17g", header="signal,log_xi,log_L", comments="")

amps = np.linspace(0, 0.65, 70)
eta_spread, smin_uniform, smin_dg = [], [], []
for a in amps:
    lr = np.array([np.exp(-a), 1.0, np.exp(a)])
    xr = np.ones(3)
    etas = (XI0 * xr / (L0 * lr)) ** 2
    eta_spread.append(np.ptp(etas) / np.mean(etas))
    smin_uniform.append(normalized_singular_values(jacobian_scan(4, lr, xr, "uniform"))[-1])
    smin_dg.append(normalized_singular_values(jacobian_scan(4, lr, xr, "dg"))[-1])

fig = plt.figure(figsize=(10.5, 4.4))
ax1 = fig.add_axes([0.08, 0.18, 0.36, 0.72])
x = np.arange(1, 4)
w = 0.34
ax1.bar(x - w / 2, sv_uniform, width=w, label=r"global $s$")
ax1.bar(x + w / 2, sv_dg, width=w, label=r"global $c_{\mathrm{scr}}$")
ax1.set_yscale("log")
ax1.set_xticks(x, [r"$\sigma_1$", r"$\sigma_2$", r"$\sigma_3$"])
ax1.set_ylabel("Singular value (column-normalized Jacobian)")
ax1.set_title("(a) Representative crossed configuration scan")
ax1.legend(frameon=False, fontsize=9, loc="lower center", bbox_to_anchor=(0.5,-0.29), ncol=2)

ax2 = fig.add_axes([0.56, 0.18, 0.39, 0.72])
ax2.plot(eta_spread, smin_uniform, label=r"global $s$")
ax2.plot(eta_spread, smin_dg, label=r"global $c_{\mathrm{scr}}$")
ax2.set_yscale("log")
ax2.set_xlabel(r"Relative range of $\eta=(\xi/L)^2$")
ax2.set_ylabel(r"Smallest singular value $\sigma_3$")
ax2.set_title("(b) Rank recovery as geometry is varied")
ax2.legend(frameon=False, fontsize=11, loc="center right")

fig.savefig(FIGDIR / "Figure2_SVD_configuration_scans.png", dpi=350, bbox_inches="tight")
plt.close(fig)

with open(OUTDIR / "13_svd_configuration_scan_values.txt", "w") as f:
    f.write("COLUMN-NORMALIZED JACOBIAN SVD\n")
    f.write(f"uniform global s singular values: {sv_uniform}\n")
    f.write(f"DG global c_scr singular values: {sv_dg}\n")
    f.write(f"uniform smallest singular value: {sv_uniform[-1]:.9e}\n")
    f.write(f"DG smallest singular value: {sv_dg[-1]:.9e}\n")

print("uniform global s:", sv_uniform)
print("DG global c_scr:", sv_dg)
print("wrote", Path("figures") / "Figure2_SVD_configuration_scans.png")
