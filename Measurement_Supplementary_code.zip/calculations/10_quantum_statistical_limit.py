#!/usr/bin/env python3
"""
the identifiability manuscript, Test 2.6: quantum/statistical feasibility bound.

Purpose
-------
Ask whether the sub-mHz-to-few-mHz line-center requirements found in Test 2.4
are near a fundamental quantum-statistical limit, or instead far above an
ideal standard-quantum-limit (SQL) bound.

We use an optimistic but transparent phase-estimation SQL:
    sigma_phi >= 1/sqrt(N_tot)
and, for interrogation time T,
    sigma_f >= 1 / (2*pi*T*sqrt(N_tot)).

N_tot is the total number of independently detected atoms contributing to the
phase estimate (atoms per shot times number of statistically independent shots).
This is NOT a claim that a particular Bragg protocol automatically saturates
the bound. It is a lower bound / resource benchmark.

For a target line-center uncertainty delta_f, the required atom-time resource is
    N_tot*T^2 >= 1/(2*pi*delta_f)^2.

We compare this with the manuscript required center uncertainties from Test 2.4:
0.1898--2.1037 mHz for the first 8 nominal momenta at 1e-6 relative precision.

We also compare the ideal SQL with the 2014 homogeneous-box Bragg experiment's
reported 2-Hz resonance-shift precision. The difference between that published
performance and the SQL illustrates technical/metrological headroom; it does not
imply that all of the headroom is practically recoverable.
"""

import numpy as np

req_mhz=np.array([0.1898,0.3878,0.6017,0.8381,1.1027,1.3997,1.7325,2.1037])
published_sigma_hz=2.0
T0=0.035  # 35 ms Bragg pulse, published homogeneous-box anchor

def sql_hz(T,Ntot):
    return 1/(2*np.pi*T*np.sqrt(Ntot))

def required_atoms(T, df_hz):
    return 1/(2*np.pi*T*df_hz)**2

print("=== IDENTIFIABILITY MANUSCRIPT TEST 2.6: QUANTUM/STATISTICAL FEASIBILITY ===")
print("Ideal standard-quantum-limit benchmark:")
print("sigma_f >= 1/(2*pi*T*sqrt(N_tot))")
print("This is a resource lower bound, not a demonstrated Bragg sensitivity.")
print()

print("A) SQL AT 35-ms INTERROGATION")
for Nshot in [1e4,1e5,1e6]:
    for shots in [1,10,100,1000,10000]:
        Ntot=Nshot*shots
        sig=sql_hz(T0,Ntot)
        print(f"N/shot={Nshot:.0e}, shots={shots:5d}: SQL sigma_f={sig*1e3:9.4f} mHz")
    print()

print("B) TOTAL DETECTED ATOMS NEEDED TO REACH EACH MANUSCRIPT CENTER REQUIREMENT")
print("j  required sigma (mHz)   N_tot @35ms    shots @1e5 atoms")
for j,dfm in enumerate(req_mhz,1):
    n=required_atoms(T0,dfm*1e-3)
    print(f"{j:2d} {dfm:19.4f} {n:13.3e} {n/1e5:16.1f}")

print()
print("C) INTERROGATION-TIME LEVER FOR THE HARDEST REQUIREMENT (0.1898 mHz)")
df=req_mhz[0]*1e-3
for T in [0.035,0.1,0.3,0.5,1.0,3.0,10.0]:
    n=required_atoms(T,df)
    print(f"T={T:5.3f} s: N_tot={n:10.3e}; shots at 1e5 atoms={n/1e5:9.2f}")

print()
print("D) QUANTUM HEADROOM RELATIVE TO PUBLISHED 2-Hz SHIFT PRECISION")
for Nshot,shots in [(1e5,1),(1e5,100),(1e5,1000),(1e6,100)]:
    sig=sql_hz(T0,Nshot*shots)
    print(f"N/shot={Nshot:.0e}, shots={shots:4d}: SQL={sig:.3e} Hz; "
          f"2 Hz / SQL = {published_sigma_hz/sig:.2e}")

print()
print("E) REQUIRED TOTAL EXPERIMENT TIME (IDEAL SQL, NO DEAD TIME)")
for dfm in [0.1898,0.5,1.0,2.1037]:
    n=required_atoms(T0,dfm*1e-3)
    shots=n/1e5
    interrogation_time=shots*T0
    print(f"target sigma={dfm:7.4f} mHz: shots@1e5={shots:9.1f}, "
          f"pure interrogation time={interrogation_time/60:8.2f} min")
print("Real experimental wall-clock time is longer because preparation, cooling, detection,")
print("and decorrelation/dead time are omitted.")

print()
print("F) IS THE MANUSCRIPT REQUIREMENT A FUNDAMENTAL QUANTUM LIMIT?")
print("No. At the SQL, increasing atom number, number of repetitions, or coherent interrogation")
print("time continuously improves sigma_f as 1/(T sqrt(N_tot)). There is no nonzero mHz floor")
print("in this model. The actual hard limits are therefore coherence/lifetime, technical frequency")
print("stability, momentum calibration, density/wall systematics, and achievable line-shape control.")
print()
