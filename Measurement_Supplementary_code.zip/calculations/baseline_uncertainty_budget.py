"""Propagate independent standard uncertainties for the Section VII baseline (no drift)."""
from pathlib import Path
import csv
import numpy as np

root = Path(__file__).resolve().parents[1]
x = np.geomspace(.18, 1.8, 12)
h = 1/(1+x*x/2)
raw = np.column_stack([h, 1/(1+x*x), 1/(x*x+.15**2), x*x])
shapes = raw / np.sqrt(np.mean(raw**2, axis=0))
J = np.column_stack([np.ones(12), -h, 2-h, np.ones(12), shapes])
widths = np.array([5e-6, 2e-6, 1e-9, 2e-6, 2e-6, 2e-6, 2e-6])
A = np.vstack([J/1e-6, np.eye(8)[1:]/widths[:, None]])
# First row maps whitened observations and independent auxiliary calibration data to s.
weights = np.linalg.pinv(A)[0]
variances = np.r_[np.sum(weights[:12]**2), weights[12:]**2]
labels = ['line_centres','healing_length','wave_number','frequency','interaction_shape','thermal_shape','wall_shape','drive_shape']
with (root/'outputs/baseline_variance.csv').open('w') as f:
    w = csv.writer(f)
    w.writerow(['source','standard_contribution_ppm','fraction_of_variance'])
    for label,v in zip(labels, variances):
        w.writerow([label, np.sqrt(v)*1e6, v/variances.sum()])
print('combined standard uncertainty (ppm)', np.sqrt(variances.sum())*1e6)
