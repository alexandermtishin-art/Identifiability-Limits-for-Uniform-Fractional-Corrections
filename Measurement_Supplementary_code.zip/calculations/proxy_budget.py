"""Figure 5 and conditional calibration sensitivity. Run from any directory."""
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from scipy.optimize import brentq

root = Path(__file__).resolve().parents[1]
x = np.geomspace(.18, 1.8, 12)
u = x*x/2
h = 1/(1+u)
one = np.ones_like(x)
alpha = 16/np.sqrt(np.pi)*np.sqrt(1e20*(5.3e-9)**3)
tau = .10
res = []
fig, axes = plt.subplots(1,2, figsize=(8.3,3.5), layout='constrained')
for label,q,marker in [('LHY',1+alpha,'o'),('Thermal',1-tau**1.5,'s')]:
    shift = np.expm1(.5*np.log1p((q-1)*h))
    xi_ratio = 1/np.sqrt(q)
    refit = np.sqrt(1+u*xi_ratio**2)/(xi_ratio*np.sqrt(1+u))-1
    constant_res = shift-shift.mean()
    res += [f'{label}: q={q:.10g}, xi_eff/xi={xi_ratio:.10g}, residual norm fraction (constant)={np.linalg.norm(constant_res)/np.linalg.norm(shift):.8f}, max abs fractional residual (xi refit)={max(abs(shift-refit)):.3e}']
    axes[0].plot(x,100*shift,marker=marker,label=label)
    axes[1].plot(x,100*constant_res,marker=marker,label=label+' after constant fit')
axes[1].axhline(0, color='black',ls='--',label='Both after healing-length fit')
for ax in axes:
    ax.set_xlabel(r'$k\xi$')
    ax.legend(frameon=False,fontsize=8)
axes[0].set_ylabel('Fractional shift (%)')
axes[1].set_ylabel('Residual shift (%)')
fig.savefig(root/'figures/Figure5_proxy_refit.png',dpi=320)
h_rms=np.sqrt(np.mean(h*h))
res.append(f'At unperturbed reference: RMS dlnw/dlnmu={h_rms/2:.9g}, equivalent standard uncertainty in lnmu for 2 ppm={4e-6/h_rms:.9g}')
raw=np.column_stack([h,1/(1+x*x),1/(x*x+.15**2),x*x])
sh=raw/np.sqrt(np.mean(raw**2,axis=0))
A=np.column_stack([one,-h,2-h,one,sh])
def z(w,order,drift):
    data=A[order]/1e-6
    p=np.diag([0,1/5e-6,1/2e-6,1/1e-9]+[1/w]*4)
    if drift:
        data=np.column_stack([data,np.linspace(-1,1,12)/1e-6])
        p=np.column_stack([p,np.zeros(8)])
    aug=np.vstack([data,p])
    assert np.linalg.matrix_rank(aug)==aug.shape[1]
    return 2.50144e-5/np.linalg.norm(np.linalg.pinv(aug)[0])
for name,order,drift in [('baseline',np.arange(12),False),('monotonic drift',np.arange(12),True),('interleaved drift',np.array([0,11,1,10,2,9,3,8,4,7,5,6]),True)]:
    vals=[z(w,order,drift) for w in [1e-6,2e-6,5e-6,np.inf]]
    threshold=brentq(lambda w:z(w,order,drift)-5,1e-10,1e-4,xtol=1e-16)
    res.append(f'{name}: Z at 1,2,5 ppm and free={vals}; common width at Z=5: {threshold*1e6:.7f} ppm')
(root/'outputs/proxy_budget.txt').write_text('\n'.join(res)+'\n')
print('\n'.join(res))
