#!/usr/bin/env python3
"""Two-dimensional Fisher calibration-budget map.

Maps nominal significance Z=s/sigma_s versus the external absolute wave-number
prior sigma_k/k and healing-length prior sigma_xi/xi. Other priors are held at
the baseline values used in the manuscript.
"""
from pathlib import Path
import numpy as np
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parents[1]
FIGDIR = ROOT / "figures"
OUTDIR = ROOT / "outputs"
FIGDIR.mkdir(exist_ok=True)
OUTDIR.mkdir(exist_ok=True)

s = 2.50144e-5
sigma = 1e-6
x = np.geomspace(0.18, 1.8, 12)
u = x * x / 2
one = np.ones_like(x)
dxi = -1 / (1 + u)
dk = (1 + 2 * u) / (1 + u)
raw = {
    "LHY-like": 1 / (1 + u),
    "finite-T-like": 1 / (1 + x * x),
    "wall-like": 1 / (x * x + 0.15 ** 2),
    "drive-like": x * x,
}
sh = {k: v / np.sqrt(np.mean(v * v)) for k, v in raw.items()}


def sigma_s(kprior, xiprior, fprior=1e-9, structprior=2e-6):
    cols = [one, dxi, dk, one] + [sh[k] for k in sh]
    J = np.column_stack(cols)
    F = J.T @ J / sigma ** 2
    priors = [None, xiprior, kprior, fprior] + [structprior] * 4
    for i, p in enumerate(priors):
        if i == 0:
            continue
        F[i, i] += 1 / p ** 2
    C = np.linalg.inv(F)
    return np.sqrt(C[0, 0])


kg = np.geomspace(3e-7, 1e-5, 120)
xig = np.geomspace(5e-7, 2e-5, 120)
Z = np.empty((len(xig), len(kg)))
for iy, xp in enumerate(xig):
    for ix, kp in enumerate(kg):
        Z[iy, ix] = s / sigma_s(kp, xp)

K, XI = np.meshgrid(kg, xig)
fig, ax = plt.subplots(figsize=(7.2, 5.5))
cf = ax.contourf(K, XI, Z, levels=np.linspace(max(0.5, Z.min()), min(10, Z.max()), 24))
cs = ax.contour(K, XI, Z, levels=[1, 3, 5], linewidths=1.4)
ax.clabel(cs, fmt={1: "1σ", 3: "3σ", 5: "5σ"})
ax.scatter([2e-6], [5e-6], s=45, marker="o")
ax.annotate("baseline", (2e-6, 5e-6), xytext=(8, 7), textcoords="offset points")
ax.set_xscale("log")
ax.set_yscale("log")
ax.set_xlabel(r"Absolute wave-number prior $\sigma_k/k$")
ax.set_ylabel(r"Healing-length prior $\sigma_\xi/\xi$")
ax.set_title("Calibration-budget map for the benchmark uniform shift")
cbar = fig.colorbar(cf, ax=ax)
cbar.set_label(r"Nominal significance $Z=s/\sigma_s$")
fig.savefig(FIGDIR / "Figure3_calibration_budget_map.png", dpi=350, bbox_inches="tight")
plt.close(fig)

baseline_Z = s / sigma_s(2e-6, 5e-6)
with open(OUTDIR / "08_calibration_budget_map_values.txt", "w") as f:
    f.write(f"Baseline significance: {baseline_Z:.9f}\n")
    f.write(f"Grid significance range: {Z.min():.9f} to {Z.max():.9f}\n")
print("baseline Z =", baseline_Z)
print("wrote", Path("figures") / "Figure3_calibration_budget_map.png")
