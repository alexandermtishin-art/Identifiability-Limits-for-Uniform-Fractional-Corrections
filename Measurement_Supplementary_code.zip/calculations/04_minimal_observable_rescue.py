#!/usr/bin/env python3
"""
the identifiability manuscript, Test 2.3: minimal-observable rescue test.

Test 2.2 established the exact degeneracy
    1 = -(1/2)(d_L + d_xi)
for the standing-mode Bogoliubov ladder.  This script asks what MINIMAL
additional observable breaks that degeneracy.

Candidates:
A) independent absolute box-length calibration L;
B) independent density/healing-length calibration xi (or n, mu);
C) an externally calibrated wave-number scale k (Bragg/recoil spectroscopy);
D) more scans (multiple box sizes or densities) with only relative, not
   absolute, calibration, for the phenomenological GLOBAL-uniform-s model.

The key distinction is between another *relative scan* and an *absolute anchor*.
"""

import numpy as np

HBAR=1.054571817e-34
AMU=1.66053906660e-27
M=87*AMU
A=5.3e-9
N_DENS=1e20
L=5e-6
C_SCR=0.00833

XI=1/np.sqrt(8*np.pi*N_DENS*A)
ETA=(XI/L)**2
TARGET=C_SCR*ETA

def standing_jacobian(J):
    """Parameters [s, ln xi, ln L]."""
    j=np.arange(1,J+1,dtype=float)
    u=(np.pi*j*XI/L)**2/2
    ds=np.ones_like(j)
    dxi=-1/(1+u)
    dL=-(1+2*u)/(1+u)
    return j,u,np.column_stack([ds,dxi,dL])

def bragg_jacobian(J):
    """
    Bragg/recoil ladder at the same nominal k_j values.
    Parameters [s, ln xi, ln kscale].
    k_j is imposed by a calibrated momentum transfer rather than inferred
    from a wall spacing.
    """
    j=np.arange(1,J+1,dtype=float)
    u=(np.pi*j*XI/L)**2/2
    ds=np.ones_like(j)
    dxi=-1/(1+u)
    dk=(1+2*u)/(1+u)
    return j,u,np.column_stack([ds,dxi,dk])

def sigma_s_from_fisher(X,sigma_y,priors):
    """
    priors: dict parameter-index -> fractional 1sigma prior.
    Returns inf if s remains unidentifiable.
    """
    F=(X.T@X)/(sigma_y**2)
    for idx,p in priors.items():
        F[idx,idx]+=1/p**2
    evals,evecs=np.linalg.eigh(F)
    tol=1e-11*np.max(evals)
    null=evecs[:,evals<=tol]
    if null.size and np.any(np.abs(null[0,:])>1e-9):
        return np.inf
    # stable inverse on full rank
    if np.sum(evals>tol)==F.shape[0]:
        cov=np.linalg.inv(F)
    else:
        cov=np.linalg.pinv(F,rcond=1e-13)
    return np.sqrt(max(cov[0,0],0))

def significance(sig):
    return 0.0 if not np.isfinite(sig) else TARGET/sig

J=6
SY=1e-6
print("=== IDENTIFIABILITY MANUSCRIPT TEST 2.3: MINIMAL-OBSERVABLE RESCUE ===")
print(f"working point: xi={XI*1e6:.6f} um, L={L*1e6:.3f} um, eta={ETA:.9e}")
print(f"target constant fractional offset s={TARGET:.9e}")
print(f"baseline: modes j=1..{J}, per-mode relative sigma={SY:.1e}")
print()

# Candidate A: L anchor.
Xs=standing_jacobian(J)[2]
print("A) ABSOLUTE BOX-LENGTH ANCHOR")
for p in [1e-3,1e-4,1e-5,5e-6,2e-6,1e-6,5e-7]:
    sig=sigma_s_from_fisher(Xs,SY,{2:p})
    print(f" sigma_L/L={p:.1e}: sigma(s)={sig:.3e}, target/Sigma={significance(sig):.2f}")
print()

# Candidate B: xi/density/mu anchor.
print("B) ABSOLUTE xi / DENSITY / CHEMICAL-POTENTIAL ANCHOR")
for pxi in [1e-3,1e-4,1e-5,5e-6,2e-6,1e-6,5e-7]:
    sig=sigma_s_from_fisher(Xs,SY,{1:pxi})
    # xi proportional n^-1/2 and mu^-1/2 at fixed a
    pn=2*pxi
    pmu=2*pxi
    print(f" sigma_xi/xi={pxi:.1e} (sigma_n/n≈{pn:.1e}, sigma_mu/mu≈{pmu:.1e}): "
          f"target/Sigma={significance(sig):.2f}")
print()

# Candidate C: calibrated Bragg k scale.
Xb=bragg_jacobian(J)[2]
print("C) CALIBRATED WAVE-NUMBER (BRAGG/RECOIL) ANCHOR")
for pk in [1e-3,1e-4,1e-5,5e-6,2e-6,1e-6,5e-7,1e-7,1e-8]:
    sig=sigma_s_from_fisher(Xb,SY,{2:pk})
    print(f" sigma_k/k={pk:.1e}: sigma(s)={sig:.3e}, target/Sigma={significance(sig):.2f}")
print()

# Find max priors for 5 sigma.
def max_prior_5sigma(X,idx):
    vals=np.logspace(-8,-3,1001)
    good=[]
    for p in vals:
        sig=sigma_s_from_fisher(X,SY,{idx:p})
        if significance(sig)>=5:
            good.append(p)
    return max(good) if good else None

pL=max_prior_5sigma(Xs,2)
pxi=max_prior_5sigma(Xs,1)
pk=max_prior_5sigma(Xb,2)
print("=== 5-SIGMA THRESHOLDS ===")
print(f"L anchor:   sigma_L/L <= {pL:.3e}")
print(f"xi anchor:  sigma_xi/xi <= {pxi:.3e}")
print(f"             equivalent sigma_n/n or sigma_mu/mu <= {2*pxi:.3e}")
print(f"k anchor:   sigma_k/k <= {pk:.3e}")
print()

# Candidate D: show why scans alone do not help.
# Build multiple configurations with relative L ratios and/or xi ratios known,
# but one common absolute L scale and one common absolute xi scale.
def multiconfig_jacobian(J, L_ratios, xi_ratios):
    rows=[]
    for lr,xr in zip(L_ratios,xi_ratios):
        jj=np.arange(1,J+1,dtype=float)
        xi=XI*xr
        ell=L*lr
        u=(np.pi*jj*xi/ell)**2/2
        ds=np.ones_like(jj)
        # derivative wrt COMMON absolute xi scale and COMMON absolute L scale
        dxi=-1/(1+u)
        dL=-(1+2*u)/(1+u)
        rows.append(np.column_stack([ds,dxi,dL]))
    return np.vstack(rows)

print("D) DO MORE RELATIVE SCANS BREAK THE GLOBAL-s DEGENERACY?")
scans=[
    ("3 box sizes, exact relative ratios", [0.7,1.0,1.4], [1,1,1]),
    ("3 densities, exact relative ratios", [1,1,1], [0.7,1.0,1.4]),
    ("crossed L and xi relative scan", [0.7,1.0,1.4,0.8,1.2], [1.2,1.0,0.8,0.7,1.4]),
]
for label,lrs,xrs in scans:
    X=multiconfig_jacobian(4,lrs,xrs)
    rank=np.linalg.matrix_rank(X,tol=1e-12)
    ident=np.max(np.abs(X[:,1]+X[:,2]+2*X[:,0]))
    sig=sigma_s_from_fisher(X,SY,{})
    print(f" {label}: rank={rank}/3, identity residual={ident:.2e}, sigma(s)={sig}")
print()

print("=== MINIMAL-RESCUE INTERPRETATION ===")
print("1) For a configuration-independent global s, more mode indices, box sizes, or densities do NOT break the symmetry")
print("   if they provide only relative changes; the common absolute rescaling survives exactly.")
print("2) An absolute anchor is mandatory.")
print("3) Direct L or density/chemical-potential metrology must reach a few parts in 10^6")
print("   for a 5-sigma benchmark test at the present working point, which is extremely demanding.")
print("4) A calibrated momentum-transfer/recoil scale provides the same mathematical anchor,")
print("   but unlike micron-scale imaging or absolute density calibration, its scale can in principle")
print("   be tied to optical frequency/wavelength metrology.")
print("5) Therefore the highest-information rescue is to replace wall-index-only spectroscopy by")
print("   an exact-dispersion measurement with an externally calibrated k scale (e.g. Bragg/recoil),")
print("   while retaining the box only as the uniform medium.")
print()
