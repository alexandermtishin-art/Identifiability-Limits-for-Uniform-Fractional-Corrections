"""Conditional design calculation. Fractional response, independent rows, unit RMS shapes."""
import numpy as np
x=np.geomspace(.18,1.8,12)
u=x*x/2
one=np.ones(12)
h=1/(1+u)
raw=np.column_stack([h,1/(1+x*x),1/(x*x+.15**2),x*x])
sh=raw/np.sqrt(np.mean(raw**2,axis=0))
base=np.column_stack([one,-h,2-h,one,sh])
priors=np.eye(8)[1:]/np.array([5e-6,2e-6,1e-9,2e-6,2e-6,2e-6,2e-6])[:,None]
for label, order in [('monotonic',np.arange(12)),('interleaved',np.array([0,11,1,10,2,9,3,8,4,7,5,6]))]:
 for drift in (False,True):
  A=base[order]/1e-6
  P=priors
  if drift:
   A=np.column_stack([A,np.linspace(-1,1,12)/1e-6])
   P=np.column_stack([P,np.zeros(7)])
  V=np.linalg.pinv(np.vstack([A,P]))
  err=np.linalg.norm(V[0])
  print(label,drift,err,2.50144e-5/err)
