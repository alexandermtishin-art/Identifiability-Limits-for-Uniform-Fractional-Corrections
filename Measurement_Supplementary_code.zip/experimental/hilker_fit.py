"""Run: python hilker_fit.py HilkerSoundData.zip. Requires numpy, scipy, matplotlib."""
import io
import csv
import sys
from zipfile import ZipFile
import numpy as np
import matplotlib.pyplot as plt
from scipy.optimize import least_squares

def table(z, name):
    lines = z.read(name).decode().splitlines()
    rows = [r for r in lines if r.strip() and not r.startswith('#')]
    return np.loadtxt(io.StringIO('\n'.join(rows[1:])), delimiter=',',ndmin=2)

def response(params, t, phase):
    freq, decay, *ab = params
    a,b = np.array(ab).reshape(2,2)[phase].T
    angle = 2*np.pi*freq*t
    return np.exp(-2*np.pi*decay*t)*(a*np.cos(angle)+b*np.sin(angle))

def estimate(t,phase,v,se,sel):
    def residual(p):
        return (response(p,t[sel],phase[sel])-v[sel])/se[sel]
    fits = [least_squares(residual,[f,10,0,0,0,0],bounds=([0,0,-np.inf,-np.inf,-np.inf,-np.inf],
            [250,200,np.inf,np.inf,np.inf,np.inf])) for f in (15,35,55,90)]
    return min(fits,key=lambda fit:fit.cost).x

with ZipFile(sys.argv[1]) as z:
    samples = table(z,'Figure_4a.csv')
    published = table(z,'Figure_4bc_exp.csv')
fig,axes = plt.subplots(2,3,figsize=(9.0,5.2),gridspec_kw={'width_ratios':[1,1,0.95]})
rows=[]
for axrow,a in zip(axes,np.unique(samples[:,1])):
    t,_,phase,v,se = samples[samples[:,1]==a].T
    t=t/1000
    _,phase = np.unique(phase,return_inverse=True)
    ref, = published[published[:,1]==a]
    p=estimate(t,phase,v,se,np.ones(t.size,dtype=bool))
    cutoff=np.unique(t)[int(len(np.unique(t))*2/3)-1]
    train=t<=cutoff
    early=estimate(t,phase,v,se,train)
    rms=lambda x:np.mean(x*x)**0.5
    pred=rms(response(early,t[~train],phase[~train])-v[~train])
    zero=rms(v[~train])
    speed=0.002*ref[0]*np.hypot(*p[:2])
    unweighted = estimate(t,phase,v,np.ones_like(se),np.ones(t.size,dtype=bool))
    speed_unweighted = 0.002*ref[0]*np.hypot(*unweighted[:2])
    rows.append([a,ref[0],p[0],p[1],ref[13],ref[14],speed,ref[9],ref[10],cutoff*1000,pred,zero,speed_unweighted,unweighted[1]])
    for j,ax in enumerate(axrow[:2]):
        for mask,marker,fc in [(train,'o','#2c6381'),(~train,'o','white')]:
            s=mask & (phase==j)
            ax.errorbar(t[s]*1000,v[s],se[s],fmt=marker,ms=3,mfc=fc,color='#2c6381',lw=.7)
        grid=np.linspace(t.min(),t.max(),300)
        ax.plot(grid*1000,response(early,grid,np.full(grid.size,j)),color='#ab4a2f',lw=1.5)
        ax.axvline(cutoff*1000,color='.5',ls=':',lw=1)
        ax.set_title(rf'$a={int(a)}\,a_0$, phase '+('0' if j==0 else '$\\pi/2$'),fontsize=10)
        ax.spines[['right','top']].set_visible(False)
    comp=axrow[2]
    comp.errorbar(ref[9],1,xerr=ref[10],fmt='s',color='#215386',capsize=3)
    comp.plot(speed,0,'D',color='#ab4a2f')
    comp.set(yticks=[0,1],yticklabels=['This work','Hilker'],ylim=(-.8,1.8),xlim=(2.5,10.7),xlabel='Speed (mm/s)',title=f'Full traces, L = {int(ref[0])} μm')
    comp.title.set_fontsize(10)
    comp.spines[['top','right']].set_visible(False)
    for xval,yval in [(speed,0),(ref[9],1)]:
        comp.annotate(f'{xval:.2f}',(xval,yval),xytext=(0,7),textcoords='offset points',ha='center',fontsize=8)
for ax in axes[-1,:2]:ax.set_xlabel('Hold time (ms)')
for ax in axes[:,0]:ax.set_ylabel('Velocity (mm/s)')
from matplotlib.lines import Line2D
fig.subplots_adjust(left=.085,right=.98,top=.89,bottom=.12,hspace=.65,wspace=.46)
handles=[Line2D([],[],marker='o',ls='',color='#2c6381',label='Hilker: fitted points'),
         Line2D([],[],marker='o',ls='',color='#2c6381',mfc='white',label='Hilker: held-out points'),
         Line2D([],[],color='#ab4a2f',label='This work: fit through 23 ms')]
fig.legend(handles=handles,loc='upper center',ncol=3,frameon=False,fontsize=9)
fig.savefig('Figure7_Hilker.pdf')
fig.savefig('Figure7_Hilker.png',dpi=300)
header=['a_in_a0','L_um','f_Hz','gamma_over_2pi_Hz','published_gamma_over_2pi_Hz','published_gamma_uncert_Hz','c_mm_s','published_c_mm_s','published_c_uncert_mm_s','cutoff_ms','heldout_rmse_mm_s','zero_rmse_mm_s','unweighted_speed_mm_s','unweighted_gamma_over_2pi_Hz']
with open('hilker_results.csv','w') as out:
    w=csv.writer(out);w.writerow(header);w.writerows(rows)
for row in rows: print(dict(zip(header,row)))
