"""Reanalyse Fig. 3 of Gotlibovych et al., Phys. Rev. A 89, 061604(R).
Manual readings of marker centres from the published figure, not raw shots.
x in thousands of atoms, y in Hz. Unweighted fits use central values only.
Reference: approximately 975 Hz from the expanded-cloud control in the paper.
"""
from statistics import mean

atoms_thousands = [55.6, 71.8, 86.3, 125.8, 145.2, 156.5, 186.3, 218.5]
frequency_hz = [987.2, 990.5, 993.5, 1000.1, 1003.4, 1008.7, 1013.7, 1021.0]
x_mean = mean(atoms_thousands)
y_mean = mean(frequency_hz)
slope = sum((x - x_mean) * (y - y_mean)
            for x, y in zip(atoms_thousands, frequency_hz)) / sum(
                (x - x_mean)**2 for x in atoms_thousands)
intercept = y_mean - slope * x_mean
reference_hz = 975.0
anchored_slope = sum(x * (y - reference_hz)
                     for x, y in zip(atoms_thousands, frequency_hz)) / sum(
                         x**2 for x in atoms_thousands)
print(f"Free fit: intercept {intercept:.2f} Hz, slope {slope/1000:.3g} Hz/atom")
print(f"Fixed reference: slope {anchored_slope/1000:.3g} Hz/atom")
