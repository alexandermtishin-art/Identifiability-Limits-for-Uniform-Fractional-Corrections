"""Run after lopes.py in the same directory: python figure6.py Repository.zip"""
import csv
import io
import sys
from zipfile import ZipFile

import matplotlib.pyplot as plt
import numpy as np
from scipy.optimize import curve_fit

def gaussian(x, b, a, c, w):
    return b + a * np.exp(-0.5*((x-c)/w)**2)

with open('matched.csv') as f:
    rows = list(csv.DictReader(f))
example = min((r for r in rows if r['panel']=='Fig3a'),key=lambda r:float(r['a_in_a0']))
with ZipFile(sys.argv[1]) as z:
    name = next(n for n in z.namelist() if n.startswith('Repository/Raw data/')
                and example['series'] in n and n.endswith('/'+example['raw_file']))
    lines = z.read(name).decode().splitlines()
ref = float(lines[0].split('=')[-1].split()[0])
f,y = np.loadtxt(io.StringIO('\n'.join(lines[2:]))).T
x = f-ref
levels = np.unique(x)
train = np.isin(x,levels[::2])
def fit(mask):
    xx,yy = x[mask],y[mask]
    best = []
    for j in [np.argmax(yy),np.argmin(yy)]:
        try:
            p,_ = curve_fit(gaussian,xx,yy,p0=(np.median(yy),yy[j]-np.median(yy),xx[j],0.5),
                            maxfev=2500,bounds=([-np.inf,-np.inf,xx.min(),0.02],[np.inf,np.inf,xx.max(),np.ptp(xx)]))
        except RuntimeError:
            continue
        best.append((sum((yy-gaussian(xx,*p))**2),p))
    return min(best,key=lambda t:t[0])[1]
p=fit(train)
rmse=lambda a: np.sqrt(np.mean(a**2))
print(name, train.sum(), (~train).sum(), 'held-out RMSE, constant RMSE, centre Hz:',
      rmse(y[~train]-gaussian(x[~train],*p)),rmse(y[~train]-y[train].mean()),1000*p[2])
fig,axes=plt.subplots(1,2,figsize=(8.4,3.65),layout='constrained')
a,b=axes
a.scatter(x[train],y[train],s=14,color='#788995',label='Lopes: used in fit')
a.scatter(x[~train],y[~train],s=19,facecolors='none',edgecolors='#215386',label='Lopes: held out')
grid=np.linspace(x.min(),x.max(),600)
a.plot(grid,gaussian(grid,*p),color='#ae442a',label='This work: Gaussian fit')
a.axvline(float(example['published_Hz'])/1000,color='#272727',ls=':',label='Lopes: published centre')
a.set(xlabel='Frequency relative to reference (kHz)',ylabel='Centre of mass (pixels)',title='(a) Prediction at held-out frequencies')
a.legend(fontsize=7,loc='best')
for panel,symbol,color in [('Fig3a','o','#215386'),('Fig4a','D','#ae442a')]:
    rr=[r for r in rows if r['panel']==panel]
    b.scatter([float(r['published_Hz']) for r in rr],[float(r['shift_Hz']) for r in rr],s=28,
              marker=symbol,color=color,label=f'Lopes Fig. {panel[3]}({panel[4]}) · {len(rr)} points',zorder=3)
b.plot([-440,270],[-440,270],color='0.4',lw=1,ls='--',label='Equal shifts')
b.set(aspect='equal',xlim=(-440,270),ylim=(-440,270),xlabel='Lopes et al.: published shift (Hz)',ylabel='This work: refitted shift (Hz)',title='(b) Full-spectrum centre estimates')
b.legend(fontsize=7)
for ax in axes:
    ax.spines[['right','top']].set_visible(False)
    ax.title.set_fontsize(10)
fig.savefig('Figure6_Lopes.pdf')
fig.savefig('Figure6_Lopes.png',dpi=300)

# Apply the same fixed split to every archived spectrum.
scores = []
with ZipFile(sys.argv[1]) as z:
    for name in sorted(z.namelist()):
        if not (name.startswith('Repository/Raw data/') and name.endswith('.txt')):
            continue
        lines = z.read(name).decode().splitlines()
        ref = float(lines[0].split('=')[-1].split()[0])
        f,y = np.loadtxt(io.StringIO('\n'.join(lines[2:]))).T
        x = f-ref
        train = np.isin(x,np.unique(x)[::2])
        p = fit(train)
        model = rmse(y[~train]-gaussian(x[~train],*p))
        flat = rmse(y[~train]-y[train].mean())
        scores.append((name,model,flat,model/flat))
with open('heldout.csv','w') as out:
    writer = csv.writer(out)
    writer.writerow(['file','gaussian_rmse_pixels','constant_rmse_pixels','ratio'])
    writer.writerows(scores)
ratios = np.array([row[-1] for row in scores])
print(len(scores), sum(ratios<1), np.median(ratios))
