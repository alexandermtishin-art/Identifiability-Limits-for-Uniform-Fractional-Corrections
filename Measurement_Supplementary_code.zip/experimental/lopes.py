"""Usage: python lopes.py Repository.zip (requires numpy and scipy). Writes fits.csv."""
import csv
import io
import sys
from collections import defaultdict
from pathlib import PurePosixPath
from zipfile import ZipFile

import numpy as np
from scipy.optimize import curve_fit

def gaussian(x, baseline, amplitude, center, width):
    return baseline + amplitude * np.exp(-0.5 * ((x - center) / width)**2)

results = []
with ZipFile(sys.argv[1]) as archive:
    for name in sorted(archive.namelist()):
        if not name.startswith('Repository/Raw data/') or not name.endswith('.txt'):
            continue
        lines = archive.read(name).decode().splitlines()
        assert lines[1].split('\t') == ['ω/2π (kHz)', 'CoM (pixels)']
        info = lines[0].split('\t')
        ref = float(info[-1].split('=')[1].split()[0])
        length = float(info[2].split('=')[1].replace('a0',''))
        freq, y = np.loadtxt(io.StringIO('\n'.join(lines[2:]))).T
        x = freq - ref
        baseline = np.median(y)
        candidates = []
        for extreme in (np.argmax(y), np.argmin(y)):
            for start in (0., x[extreme]):
                params, cov = curve_fit(gaussian, x, y, p0=(baseline,y[extreme]-baseline,start,0.5),
                    bounds=([-np.inf,-np.inf,x.min(),0.02],[np.inf,np.inf,x.max(),np.ptp(x)]),maxfev=10000)
                candidates.append((np.sum((y-gaussian(x,*params))**2),params,cov))
        _, fit, cov = min(candidates,key=lambda item:item[0])
        results.append((PurePosixPath(name).parent.name, name.split('/')[-1],length, len(x),
                        1000*fit[2],1000*np.sqrt(cov[2,2]),1000*fit[3]*np.sqrt(8*np.log(2))))
with open('fits.csv','w') as out:
    writer = csv.writer(out)
    writer.writerow(['series','file','a_in_a0','rows','shift_Hz','formal_se_Hz','FWHM_Hz'])
    writer.writerows(results)
groups = defaultdict(list)
for series, name, length, n, shift, se, width in results:
    groups[series,length].append((shift,se))
rep = [np.array(v) for v in groups.values() if len(v)>1]
print(len(results),len(groups),len(rep),'spectra, settings, repeated settings')
print('Median conditional SE, Hz:',np.median([r[5] for r in results]))
print('Median within-setting sample SD, Hz:',np.median([np.std(v[:,0],ddof=1) for v in rep]))
print('Median FWHM, Hz:',np.median([r[6] for r in results]))
# Direct comparison only where one raw spectrum has the same published
# scattering length (within rounding of the raw-file header, 0.01 a0).
with ZipFile(sys.argv[1]) as archive, open('matched.csv','w') as out:
    writer = csv.writer(out)
    writer.writerow(['panel','series','a_in_a0','raw_file','shift_Hz','published_Hz','difference_Hz'])
    diffs = []
    for panel,series in [('Fig3a','dens1_q1'),('Fig3a','dens2_q3'),('Fig4a','dens3_q3')]:
        path = next(p for p in archive.namelist() if p.startswith('Repository/Figures/')
                    and p.endswith(f'/{panel}_{series}.txt'))
        table = np.loadtxt(io.BytesIO(archive.read(path)), skiprows=2)
        for a, shift, *_ in table:
            matches = [r for r in results if r[0].endswith(series) and abs(a-r[2])<=0.01]
            if len(matches)==1:
                r = matches[0]
                diff = r[4] - 1000*shift
                diffs.append(abs(diff))
                writer.writerow([panel,series,a,r[1],r[4],1000*shift,diff])
    print('Unique matches, median and maximum absolute difference (Hz):',
          len(diffs),np.median(diffs),max(diffs))
