"""Replay the two archived datasets and the digitized published-figure check."""
import argparse
import os
from pathlib import Path
import subprocess
import sys

root = Path(__file__).resolve().parent
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("lopes_zip", type=Path)
parser.add_argument("hilker_zip", type=Path)
args = parser.parse_args()
lopes = args.lopes_zip.resolve(strict=True)
hilker = args.hilker_zip.resolve(strict=True)
out = root / "outputs" / "experimental"
out.mkdir(parents=True, exist_ok=True)
jobs = [("Bragg_published_data_check.py", []), ("lopes.py", [lopes]),
        ("figure6.py", [lopes]), ("hilker_fit.py", [hilker])]
for script, inputs in jobs:
    print(f"Running {script}", flush=True)
    with (out / (Path(script).stem + "_stdout.txt")).open("w") as log:
        subprocess.run([sys.executable, str(root / "experimental" / script), *inputs],
                       cwd=out, stdout=log, stderr=subprocess.STDOUT,
                       env={**os.environ, "MPLBACKEND": "Agg"}, check=True)
