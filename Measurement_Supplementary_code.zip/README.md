# Measurement-model identifiability and calibration limits in Bogoliubov spectroscopy

Numerical design calculations, analysis of published data, and supporting outputs for the manuscript. Python 3.12.14, NumPy 2.3.5, SciPy 1.17.0 and Matplotlib 3.10.8 were used for the archived replay. Install the dependencies in a Python environment before running.

## Replay the model

From the unpacked package directory:

```sh
python -m pip install -r requirements.txt
python run_all.py
```

The runner executes 20 scripts in fresh processes. Each script writes a log to `outputs`. For Fig. 2, script 13 also exports the unnormalized Jacobians (one row per configuration/mode, columns signal, log healing length, log box length). Divide each column by its Euclidean norm before taking the SVD.

| Quantity | Calculation or file |
|---|---|
| Figure 1 | Supplied conceptual schematic; no numerical input. |
| Four-mode truncated fit and exact scale ambiguity | Scripts 01–04. |
| Figure 2 and crossed configurations | Scripts 12–13; three columns. |
| Tables I(a,b) and Figure 3 | Scripts 07–08 and `baseline_uncertainty_budget.py`. |
| Drift and common calibration widths | `drift.py` and `proxy_budget.py`. |
| Table II and Table III | Scripts 05, 09 and 10. Script 11 gives the line-centre Fisher example. |
| Figure 4 | Scripts 15 and `wall_mesh.py`; one-particle wall diagnostic. |
| Figure 5 | `proxy_budget.py`; compares constant subtraction with a healing-length refit. Script 16 generates the separate constant-projection diagnostic. |
| Figures 6 and 7 | Published-data analyses below. |

At 2 ppm common independent distortion widths, the nominal significance ratios are 5.23925 without drift and 4.46110 or 5.22316 with a fitted linear drift for the monotonic or interleaved orders. Their common widths at the nominal five-standard-deviation cutoff are 2.525, 1.270 and 2.485 ppm respectively. These results use a specified noise model for the twelve-point design.

## Replay the published-data analyses

Obtain the two original ZIP files from their respective repositories. Keep them compressed.

* Lopes et al., *Quasiparticle Energy in a Strongly Interacting Homogeneous Bose-Einstein Condensate*, data [10.17863/CAM.9210](https://doi.org/10.17863/CAM.9210). File used: `Repository.zip`. SHA-256: `9efd84181fb896252cbce145450f354368a88fb61cf919ad488a43eaa9b72d30`.
* Hilker et al., *First and Second Sound in a Compressible 3D Bose Fluid*, data [10.17863/CAM.83837](https://doi.org/10.17863/CAM.83837). File used: `HilkerSoundData.zip`. SHA-256: `b216021e7e9c7a264c5f9d27e0651b273e008d248b7ba6e576d4a8df94bc8bb7`.
* The small Gotlibovych comparison uses eight manually read points from Fig. 3 of [Phys. Rev. A 89, 061604(R)](https://doi.org/10.1103/PhysRevA.89.061604). The points are transcribed in `experimental/Bragg_published_data_check.py`.

```sh
python run_experiments.py /path/to/Repository.zip /path/to/HilkerSoundData.zip
```

The runner writes CSV tables, logs and PDF/PNG figures to `outputs/experimental`. The Lopes reduction uses the per-spectrum free-particle reference, Gaussian centre fits and alternating sorted frequency levels to evaluate interpolation. `fits.csv` contains 171 spectra, `matched.csv` all 17 individually matched comparisons, and `heldout.csv` one test per spectrum. The Fig. 4(a) matches differ by 384 and 127 Hz; the published tables use binning. A unique nominal setting does not establish the provenance of a binned point.

For Hilker, the source tables do not supply a common run identifier. Matching by the unique scattering-length row provides a conditional length association. `hilker_results.csv` contains full-fit velocities and damping and the out-of-window errors at both scattering lengths. The reanalyses test specific parts of the extraction procedure; the archives do not verify the nominal acquisition-order gain in the design calculation.

`SHA256SUMS` identifies the distributed files. Rendering metadata and floating-point last digits may vary between platforms during replay.
