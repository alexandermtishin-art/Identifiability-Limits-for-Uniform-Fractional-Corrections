import numpy as np
hbar=1.054571817e-34; amu=1.66053907e-27; a0=5.29177210903e-11
def aho(m,f): return np.sqrt(hbar/(m*2*np.pi*f))

print("=== 1. eta = (xi/R_TF)^2 = (a_ho/R_TF)^4 = (15 N a/a_ho)^(-4/5) ===")
print("   (uses exact TF identity xi(0)*R_TF = a_ho^2)\n")
m87=87*amu; a87=5.3e-9   # Rb-87 background scattering length
for f in [10.,50.,100.,200.]:
    ah=aho(m87,f)
    print(f"  Rb87, f={f:6.1f} Hz : a_ho={ah*1e6:6.3f} um, a/a_ho={a87/ah:.3e}")
    for N in [1e2,1e3,1e4,1e5,1e6]:
        x=15*N*a87/ah; eta=x**(-0.8); R=ah*x**0.2; xi=ah**2/R
        print(f"      N={N:8.0e}  Na/a_ho={N*a87/ah:9.2f}  R_TF={R*1e6:7.2f}um  xi={xi*1e6:7.3f}um  eta={eta:.3e}")
    print()

print("=== 2. N required for a given eta (Rb87) ===")
print("   TF/hydrodynamic validity requires N a/a_ho >> 1 (say >100)")
for f in [10.,100.]:
    ah=aho(m87,f)
    print(f"  f={f} Hz:")
    for eta in [1e-3,1e-2,0.1,0.3,0.5,1.0]:
        x=eta**(-1.25); N=x/(15*a87/ah)
        print(f"      eta={eta:6.3f} -> N={N:10.1f} atoms,  Na/a_ho={N*a87/ah:8.2f}  {'OK' if N*a87/ah>100 else '<-- TF INVALID'}")
    print()

print("=== 3. Feshbach route: K-39, tune a down (broad resonance @402G) ===")
m39=39*amu; ah=aho(m39,100.)
print(f"  K39, f=100Hz, a_ho={ah*1e6:.3f} um")
for aval in [100*a0, 10*a0, 1*a0]:
    print(f"   a={aval/a0:6.1f} a0:")
    for eta in [1e-2,0.1,0.3]:
        x=eta**(-1.25); N=x/(15*aval/ah)
        print(f"      eta={eta:5.2f} -> N={N:12.1f},  Na/a_ho={N*aval/ah:8.2f}  {'OK' if N*aval/ah>100 else '<-- TF INVALID'}")
