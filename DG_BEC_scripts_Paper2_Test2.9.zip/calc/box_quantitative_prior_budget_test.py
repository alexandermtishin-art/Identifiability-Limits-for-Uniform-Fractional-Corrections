import numpy as np
s=2.50144e-5
sigma=1e-6
x=np.geomspace(.18,1.8,12); u=x*x/2
one=np.ones_like(x); dxi=-1/(1+u); dk=(1+2*u)/(1+u)
# nuisance shapes, standardized to unit RMS so coefficient is typical fractional spectral amplitude
raw={
'LHY-like':1/(1+u),
'finite-T-like':1/(1+x*x),
'wall-like':1/(x*x+.15**2),
'drive-like':x*x,
}
sh={k:v/np.sqrt(np.mean(v*v)) for k,v in raw.items()}
# priors on parameter coefficients. xi and k are log-scale fractional priors; f is uniform frequency scale.
# structured nuisance priors are RMS fractional spectral-amplitude priors.
def sigma_s(priors, include_struct=True):
    names=['s','xi','k','f']+list(sh) if include_struct else ['s','xi','k','f']
    cols=[one,dxi,dk,one]
    if include_struct: cols += [sh[k] for k in sh]
    J=np.column_stack(cols)
    F=J.T@J/sigma**2
    # no prior on s; Gaussian priors others
    for i,n in enumerate(names[1:],1):
        p=priors.get(n,np.inf)
        if np.isfinite(p) and p>0: F[i,i]+=1/p**2
    C=np.linalg.inv(F)
    return np.sqrt(C[0,0])

base_struct={'LHY-like':2e-6,'finite-T-like':2e-6,'wall-like':2e-6,'drive-like':2e-6}
# explore k/xi/f equal priors
print('target sigma for 5sigma',s/5)
for p in [1e-7,2e-7,5e-7,1e-6,2e-6,5e-6,1e-5]:
 pr={'xi':p,'k':p,'f':p,**base_struct}
 print(p,sigma_s(pr))
# one-at-a-time tolerances with others tight 1e-9, structured tight 1e-9
from scipy.optimize import brentq
target=s/5
alln=['xi','k','f']+list(sh)
for name in alln:
 def fun(logp):
  p=10**logp
  pr={n:1e-9 for n in alln}; pr[name]=p
  return sigma_s(pr)-target
 try:
  root=brentq(fun,-10,-2)
  print('OAT',name,10**root)
 except Exception as e: print('OAT',name,e,fun(-10),fun(-2))
# realistic-ish anchors: f 1e-9, k 2e-6, xi variable; structured 2e-6
for px in [1e-6,2e-6,5e-6,1e-5,2e-5,5e-5,1e-4]:
 pr={'f':1e-9,'k':2e-6,'xi':px,**base_struct}
 print('xi scan',px,sigma_s(pr),s/sigma_s(pr))
