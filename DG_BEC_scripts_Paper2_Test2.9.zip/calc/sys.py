import numpy as np
hbar=1.054571817e-34; amu=1.66053907e-27; kB=1.380649e-23
m=87*amu; a=5.3e-9
def aho(f): return np.sqrt(hbar/(m*2*np.pi*f))

print("=== KEY IDENTITY ===")
print("eta = (15 N a/a_ho)^(-4/5)  =>  N a/a_ho = (1/15) eta^(-5/4)")
print("The TF/hydrodynamic validity parameter is a PURE FUNCTION of eta.")
print("No choice of species, trap freq, or Feshbach a can decouple them.\n")
for eta in [1e-4,1e-3,1e-2,0.05,0.1,0.5,1.0]:
    print(f"   eta={eta:7.4f}  ->  N a/a_ho = {(1/15)*eta**-1.25:10.2f}   xi/R={np.sqrt(eta):.3f}")

print("\n=== SIGNAL vs KNOWN SYSTEMATICS, breathing mode, Rb87 ===")
print("Case: f=100 Hz spherical, N=1e5 (the 'standard BEC' in the manuscript)")
f=100.; ah=aho(f); N=1e5
x=15*N*a/ah; R=ah*x**0.2; eta=x**(-0.8)
# peak TF density
n0 = (hbar**2/(2*m))*0/1  # placeholder
mu = 0.5*m*(2*np.pi*f)**2*R**2
g = 4*np.pi*hbar**2*a/m
n0 = mu/g
wB = np.sqrt(5)*2*np.pi*f            # TF monopole, spherical
print(f"   a_ho={ah*1e6:.3f}um  R_TF={R*1e6:.2f}um  xi={ah**2/R*1e6:.3f}um  eta={eta:.3e}")
print(f"   n_peak={n0*1e-6:.3e} cm^-3   mu/h={mu/(2*np.pi*hbar):.1f} Hz   mu/kB={mu/kB*1e9:.1f} nK")
print(f"   omega_B/2pi = sqrt(5)*f = {wB/(2*np.pi):.2f} Hz")
print()
gp = np.sqrt(n0*a**3)
print(f"   [S] DG signal, if delta_w/w ~ eta        : {eta:.2e}  -> {eta*wB/(2*np.pi)*1e3:9.3f} mHz")
print(f"       manuscript quotes                    :               1.500 mHz  (=> implied prefactor {1.5e-3/(eta*wB/(2*np.pi)):.3f})")
print(f"   [B1] beyond-TF quantum pressure ~ eta    : {eta:.2e}  -> {eta*wB/(2*np.pi)*1e3:9.3f} mHz   <-- SAME SCALING")
print(f"   [B2] LHY beyond-mean-field ~ sqrt(n a^3) : {gp:.2e}  -> {gp*wB/(2*np.pi)*1e3:9.3f} mHz")
print(f"   [B3] thermal, T/Tc=0.5 (measured, ~1e-2) : {1e-2:.2e}  -> {1e-2*wB/(2*np.pi)*1e3:9.1f} mHz")
print(f"   ratio B2/S = {gp/eta:.1f}x     ratio B3/S = {1e-2/eta:.0f}x     ratio B1/S = 1  (degenerate)")

print("\n=== MEASUREMENT PRECISION BUDGET ===")
T_life=[1.,5.,20.]
for T in T_life:
    dfF=1/(2*np.pi*T)
    print(f"   condensate lifetime/observation T={T:4.1f}s -> Fourier limit df={dfF*1e3:7.1f} mHz per shot")
    for snr in [5,20]:
        for target in [1.5e-3, eta*wB/(2*np.pi)]:
            Nsh=(dfF/(snr*target))**2
            print(f"        SNR={snr:3d}, target={target*1e3:7.2f} mHz -> N_shots={Nsh:12.1f}  ({Nsh*30/3600:.1f} h at 30s/shot)")
