import numpy as np, sympy as sp

print("="*70)
print("MODEL: V(r) = A r^2 + b r^4,  A = m w0^2/2,  b = -A/w_0^2  (Gaussian beam)")
print("dimensionless u = b R^2 / A = -(R/w_0)^2")
print("="*70)

# ---------- 1. SYMBOLIC: TF cloud in V = A r^2 + b r^4 ----------
r,R,A,b,mu,g = sp.symbols('r R A b mu g', positive=True)
mu_e = A*R**2 + b*R**4                      # edge condition n(R)=0
dens  = (mu_e - A*r**2 - b*r**4)/g
Ng    = sp.integrate(4*sp.pi*r**2*dens, (r,0,R))
num   = sp.integrate(4*sp.pi*r**4*dens, (r,0,R))
r2    = sp.simplify(num/Ng)
print("\n<r^2> exact (TF, quartic trap):")
print("   ", sp.simplify(r2))
u = sp.symbols('u')                          # u = b R^2 / A
r2_u = sp.simplify(r2.subs(b, u*A/R**2))
print("   = R^2 *", sp.simplify(r2_u/R**2))
print("   series in u:", sp.series(sp.simplify(r2_u/R**2), u, 0, 2))

print("\nNormalisation  N g =", sp.simplify(Ng.subs(b, u*A/R**2)))

# ---------- 2. SYMBOLIC: <r^2> as function of A at fixed b, N ----------
# R fixed by  N g = (8 pi/15)(A R^5/g-free) [1 + (10/7) u]
# solve perturbatively:  R = R0 [1 - (2/7) u0],  u0 = b R0^2 / A
u0, R0 = sp.symbols('u0 R0', positive=True)
Rp   = R0*(1 - sp.Rational(2,7)*u0)
r2ser= sp.Rational(3,7)*Rp**2*(1 + sp.Rational(8,63)*(u0))     # u ≈ u0 to O(u)
r2ser= sp.expand(sp.series(r2ser, u0, 0, 2).removeO())
print("\n<r^2> = (3/7) R0^2 [1 + c u0] with c =",
      sp.simplify(sp.expand(r2ser/(sp.Rational(3,7)*R0**2)).coeff(u0)))

# ---------- 3. Sum rule  w_M^2 = -2<r^2> / (d<r^2>/dw0^2) ----------
Asym,k,beta = sp.symbols('A k beta', positive=True)
# R0^2 = k A^{-2/5};  u0 = beta k A^{-7/5}
r2A = sp.Rational(3,7)*k*Asym**sp.Rational(-2,5)*(1 - sp.Rational(4,9)*beta*k*Asym**sp.Rational(-7,5))
dr2 = sp.diff(r2A, Asym)
wM2 = sp.simplify(-4*r2A/dr2)                       # = (4/m)*... ; m folded into A=m w0^2/2
ratio = sp.simplify(wM2/(4*Asym))                   # should be 5/2 (1 + (14/9) u0)
ser = sp.series(sp.simplify(ratio), beta, 0, 2).removeO()
print("\nw_M^2 / (4A) =", sp.simplify(ser), "   [4A/m = 2 w0^2]")
c_mono = sp.simplify(sp.expand(ser/sp.Rational(5,2) - 1)/(beta*k*Asym**sp.Rational(-7,5)))
print("=> w_M^2 = 5 w0^2 [1 +", sp.nsimplify(sp.simplify(c_mono)), "u0 ]")
print("=> (dw/w)_B =", sp.nsimplify(sp.simplify(c_mono)/2), "* u0")
