import numpy as np
hbar=1.054571817e-34; amu=1.66053907e-27
m=87*amu; a=5.3e-9; f=100.
ah=np.sqrt(hbar/(m*2*np.pi*f)); N=1e5
x=15*N*a/ah; R=ah*x**0.2; eta=x**(-0.8); xi=ah**2/R
r2=2*R**2/7.0                      # <r_perp^2> for TF profile
dw=2*hbar/(m*r2)                   # Zambelli-Stringari m=+/-2 quadrupole splitting, 1 vortex
wq=np.sqrt(2)*2*np.pi*f
print("=== IDEA 20: vortex-enhanced readout, Rb87 N=1e5 f=100Hz ===")
print(f"  R_TF={R*1e6:.2f}um  xi={xi*1e6:.3f}um  eta={eta:.3e}")
print(f"  known m=+-2 quadrupole splitting from ONE vortex: {dw/(2*np.pi)*1e3:.0f} mHz  ({dw/wq:.2e} relative)")
print(f"  DG shift if ~eta*omega_B                        : {eta*np.sqrt(5)*f*1e3:.0f} mHz")
print(f"  DG shift at manuscript's quoted value           : 1.5 mHz")
print(f"  -> standard-GP vortex signature is {dw/(2*np.pi)/1.5e-3:.0f}x larger than the DG target.")
print(f"     The vortex helps only if GP+vortex theory is known to better than {1.5e-3/(np.sqrt(5)*f):.1e} relative.")
print()
print("=== current state of the art, BEC collective-mode theory-vs-experiment ===")
print("  agreement typically 1e-3 .. 1e-2 relative (thermal + LHY + anharmonicity budget)")
print(f"  required for DG at 1.5 mHz on {np.sqrt(5)*f:.0f} Hz: {1.5e-3/(np.sqrt(5)*f):.1e} relative")
print(f"  gap: {1e-3/(1.5e-3/(np.sqrt(5)*f)):.0f}x  to  {1e-2/(1.5e-3/(np.sqrt(5)*f)):.0f}x")
