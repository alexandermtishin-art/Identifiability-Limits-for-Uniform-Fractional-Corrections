import numpy as np
hbar=1.054571817e-34; amu=1.66053907e-27; a0=5.29177210903e-11; kB=1.380649e-23
m=87*amu; a=5.3e-9
def xi(n,aa=a): return 1/np.sqrt(8*np.pi*n*aa)
def cs(n,aa=a): return np.sqrt(4*np.pi*hbar**2*aa*n/m**2)

print("=== BOX GEOMETRY: eta = 1/(8 pi n a L^2), diluteness = n a^3  (INDEPENDENT) ===")
print(" n[cm^-3]     L[um]   xi[um]   eta        n a^3      c[mm/s]  f_1=c/2L [Hz]")
for n_cm in [1e12,1e13,1e14]:
    n=n_cm*1e6
    for L in [2e-6,3e-6,5e-6,10e-6,30e-6]:
        e=(xi(n)/L)**2; c=cs(n)
        print(f" {n_cm:.0e}   {L*1e6:6.1f}  {xi(n)*1e6:7.3f}  {e:.3e}  {n*a**3:.2e}  {c*1e3:7.3f}  {c/(2*L):8.1f}")
    print()

print("=== compare: harmonic trap LOCK  Na/a_ho = eta^-1.25/15 ===")
for e in [1e-3,1e-2,0.1]:
    print(f"  eta={e:6.3f}: harmonic requires Na/a_ho={(1/15)*e**-1.25:8.2f}; box requires only n a L^2 = {1/(8*np.pi*e):.3e} m^-1")

print("\n=== MODE-INDEX SIGNATURE ===")
print("Bogoliubov: hbar w = sqrt(eps(eps+2gn)) => w = c k (1 + k^2 xi^2/4 + ...)")
print("standing modes k_j = pi j / L  =>  (dw/w)_QP = (pi^2/4) j^2 eta")
print("screening term of form kappa(1-eta) with L = system scale => j-INDEPENDENT")
n=1e19; L=3e-6; e=(xi(n)/L)**2
print(f"\nexample: n=1e13 cm^-3, L=3 um -> eta={e:.4f}, xi={xi(n)*1e6:.3f} um, c={cs(n)*1e3:.3f} mm/s")
print(" j |  f_j [Hz] | (dw/w)_QP = 2.467 j^2 eta | absolute QP shift [Hz]")
for j in [1,2,3,4,5]:
    f=cs(n)*j/(2*L); qp=(np.pi**2/4)*j**2*e
    print(f" {j} | {f:9.2f} | {qp:.4e}              | {qp*f:9.4f}")
print("\n a screening term with c_scr = 1e-2 would add a CONSTANT 1e-2*eta = %.3e to every j"%(1e-2*e))
print(" -> fit (dw/w)_j = A j^2 + B ; A = 2.467 eta (GP, known), B = c_scr eta (new)")

print("\n=== RESONANT / STATISTICAL BUDGET in box, target rel. resolution ===")
for tgt in [6.7e-6,1e-5,1e-4]:
    print(f" target={tgt:.1e}:")
    for Q in [1e2,1e3,1e4]:
        for S in [10,30]:
            Ns=(1/(Q*S*tgt))**2
            print(f"    Q={Q:.0e} S={S:2d} -> N_shots={Ns:10.1f}  ({Ns*30/3600:7.2f} h)")
