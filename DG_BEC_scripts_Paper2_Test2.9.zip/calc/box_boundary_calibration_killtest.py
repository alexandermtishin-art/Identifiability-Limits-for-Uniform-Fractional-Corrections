#!/usr/bin/env python3
"""
Paper 2, Test 2.2: box-boundary/calibration identifiability kill-test.

Exact uniform-gas Bogoliubov mode frequency:
    omega_j = c k_j sqrt(1 + k_j^2 xi^2/2),
with
    c = hbar/(sqrt(2) m xi),
    k_j = pi j / L.

Let s be a mode-independent fractional screening offset:
    omega_j -> (1+s) omega_j.

The exact logarithmic derivatives are
    d ln omega_j / d ln xi = -1/(1+u_j)
    d ln omega_j / d ln L  = -(1+2u_j)/(1+u_j)
where u_j = k_j^2 xi^2/2.

Crucial identity:
    d_L + d_xi = -2 * 1,
so the constant screening vector is EXACTLY in the nuisance span
of simultaneous uncertainty in xi and L.

Thus a mode-index ladder alone cannot identify a uniform fractional screening
offset if both the density/healing-length scale and effective box length are
allowed to float freely.

The script verifies the rank identity numerically and adds Gaussian priors
on ln L and ln xi to quantify the external calibration needed.
"""

import numpy as np

HBAR=1.054571817e-34
AMU=1.66053906660e-27
M=87*AMU
A=5.3e-9
N_DENS=1e20
L=5e-6
C_SCR=0.00833

XI=1/np.sqrt(8*np.pi*N_DENS*A)
ETA=(XI/L)**2
TARGET=C_SCR*ETA

def jacobian(J):
    j=np.arange(1,J+1,dtype=float)
    u=(np.pi*j*XI/L)**2/2
    dxi=-1/(1+u)
    dL=-(1+2*u)/(1+u)
    ds=np.ones_like(j)
    return j,u,np.column_stack([ds,dxi,dL])

def residual_fraction(J):
    j,u,X=jacobian(J)
    s=X[:,0]
    Z=X[:,1:]
    Q,_=np.linalg.qr(Z)
    sr=s-Q@(Q.T@s)
    return np.linalg.norm(sr)/np.linalg.norm(s), np.linalg.norm(sr)

def fisher_sigma_s(J,sigma_y,prior_xi=None,prior_L=None):
    """
    Linearized log-frequency model y = s*1 + dxi*dlnxi + dL*dlnL.
    Per-mode independent Gaussian sigma_y.
    prior_xi/prior_L are 1-sigma fractional priors on xi and L.
    """
    _,_,X=jacobian(J)
    F=(X.T@X)/(sigma_y**2)
    if prior_xi is not None:
        F[1,1]+=1/prior_xi**2
    if prior_L is not None:
        F[2,2]+=1/prior_L**2
    rank=np.linalg.matrix_rank(F, tol=1e-10*np.max(np.abs(F)))
    # If the Fisher matrix is rank-deficient and the null space has a nonzero
    # screening component, s is unidentifiable and its variance is infinite.
    if rank < F.shape[0]:
        evals,evecs=np.linalg.eigh(F)
        tol=1e-10*np.max(evals)
        null=evecs[:,evals<=tol]
        if null.size and np.any(np.abs(null[0,:]) > 1e-10):
            return np.inf, rank
    cov=np.linalg.inv(F) if rank==F.shape[0] else np.linalg.pinv(F,rcond=1e-15)
    return np.sqrt(max(cov[0,0],0.0)), rank

print("=== PAPER 2 TEST 2.2: BOUNDARY/CALIBRATION IDENTIFIABILITY ===")
print(f"xi={XI*1e6:.6f} um, L={L*1e6:.3f} um, eta={ETA:.9e}")
print(f"target screening offset s=c_scr*eta={TARGET:.9e}")
print()

for J in [2,3,4,5,6,8,10]:
    j,u,X=jacobian(J)
    identity=np.max(np.abs(X[:,1]+X[:,2]+2*X[:,0]))
    frac,norm=residual_fraction(J)
    rank=np.linalg.matrix_rank(X, tol=1e-12)
    print(f"j=1..{J:2d}: rank(signal,xi,L)={rank}/3, "
          f"max identity residual={identity:.3e}, screening residual fraction={frac:.3e}")

print("\nANALYTIC IDENTITY:")
print("d ln omega/d ln L + d ln omega/d ln xi = -2")
print("=> 1 = -(1/2)(d_L + d_xi)")
print("=> a uniform screening offset is exactly degenerate with a joint rescaling of L and xi.")

print("\n=== EXTERNAL CALIBRATION REQUIREMENTS ===")
print("Assume per-mode relative frequency sigma_y=1e-6 and modes j=1..6.")
J=6
sy=1e-6
cases=[
    (None,None),
    (1e-2,None),(1e-3,None),(1e-4,None),(1e-5,None),
    (None,1e-2),(None,1e-3),(None,1e-4),(None,1e-5),
    (1e-3,1e-3),(1e-4,1e-4),(1e-5,1e-5),
    (1e-4,1e-3),(1e-3,1e-4),
]
print("prior_xi   prior_L    sigma(s)      target/sigma")
for pxi,pL in cases:
    sig,rank=fisher_sigma_s(J,sy,pxi,pL)
    print(f"{str(pxi):>8}  {str(pL):>8}  {sig: .3e}      {TARGET/sig: .2f}")

print("\n=== REQUIRED ONE-SIDED CALIBRATION FOR 5 SIGMA ===")
for which in ["L","xi"]:
    vals=np.logspace(-7,-2,501)
    ok=[]
    for p in vals:
        sig,_=fisher_sigma_s(J,sy, prior_xi=p if which=="xi" else None,
                             prior_L=p if which=="L" else None)
        if TARGET/sig>=5:
            ok.append(p)
    if ok:
        print(f"if only {which} is externally calibrated, 5sigma requires sigma_{which}/{which} <= {max(ok):.2e}")
    else:
        print(f"if only {which} is externally calibrated, 5sigma not reached in scanned prior range")

print("\n=== EFFECTIVE WALL LENGTH ===")
print("Any wall-penetration/extrapolation correction that enters only through")
print("L_eff = L + delta_L is mathematically the same nuisance direction d_L.")
print("Therefore the exact degeneracy applies to geometric-length calibration AND")
print("to first-order finite-wall boundary shifts that act as an effective box-length change.")

print("\nFINAL TEST-2.2 VERDICT:")
print("1) MODE-INDEX SELF-CALIBRATION ALONE FAILS if both xi (density scale) and effective L float.")
print("2) This is an exact differential degeneracy, not a numerical near-collinearity.")
print("3) The Paper 2 route survives only if at least one absolute scale (L_eff or xi/density)")
print("   is independently calibrated strongly enough, or if an additional observable breaks the rescaling symmetry.")
print("4) Boundary penetration is especially dangerous because, to first order, it is an L_eff nuisance.")
