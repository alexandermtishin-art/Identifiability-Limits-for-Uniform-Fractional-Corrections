import numpy as np
hbar=1.054571817e-34; amu=1.66053907e-27
m=87*amu; a=5.3e-9; f=100.; N=1e5
ah=np.sqrt(hbar/(m*2*np.pi*f)); x=15*N*a/ah; R=ah*x**0.2; eta=x**(-0.8)
wB=np.sqrt(5)*f; target=1.5e-3/wB
print(f"eta={eta:.3e}   target relative resolution = {target:.2e}\n")

print("=== A. Statistical budget with a resonant (high-Q) collective mode ===")
for Q in [1e2,1e3,1e4]:
    for snr in [10,30]:
        Nsh=(1.0/(Q*snr*target))**2
        print(f"  Q={Q:6.0e} SNR={snr:3d} -> N_shots={Nsh:10.1f}  ({Nsh*30/3600:7.2f} h @30s/shot)")
print("  (linewidth/omega = 1/Q; splitting the line by SNR*sqrt(N_shots))\n")

print("=== B. Systematic budget: what stability is actually required ===")
# omega_B/omega_trap is N-independent at leading TF order; corrections enter at O(eta)
dlneta_dlnN=-0.8
for c in [0.1,1.0]:
    dNN=target/abs(c*eta*dlneta_dlnN)
    print(f"  prefactor c={c:4.1f}: atom-number stability required dN/N < {dNN*100:6.2f} %")
print("     (state of the art with feedback: 0.1-1 % ; typical: 1-5 %)  -> ACHIEVABLE")
# trap frequency: omega propto sqrt(P) for optical dipole trap
print(f"  trap-frequency stability required: dw/w < {target:.1e}  -> optical power dP/P < {2*target:.1e}")
print("     (state of the art intensity stabilisation: 1e-6 .. 1e-5)   -> MARGINAL, achievable\n")

print("=== C. Historical precision-improvement rate ===")
print("  Cs beam clock 1955: 1e-10 ; optical lattice clock 2022: 1e-18")
print(f"  -> {8/67:.3f} decades per year = 1 order per {67/8:.1f} years")
print(f"  gap to close here: 150x .. 1500x = {np.log10(150):.1f} .. {np.log10(1500):.1f} decades")
print(f"  -> extrapolated time: {np.log10(150)*67/8:.0f} .. {np.log10(1500)*67/8:.0f} years")
