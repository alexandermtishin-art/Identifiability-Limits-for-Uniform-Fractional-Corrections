import numpy as np
hbar=1.054571817e-34; amu=1.66053907e-27; kB=1.380649e-23; a0=5.29177210903e-11
m=87*amu; a=5.3e-9
def aho(f,mm=m): return np.sqrt(hbar/(mm*2*np.pi*f))

print("### PAPER 1, TABLE I ###")
for eta in [1e-4,1e-3,1e-2,5e-2,0.1,0.5,1.0]:
    print(f"{eta:8.4f} | {(1/15)*eta**-1.25:9.2f} | {np.sqrt(eta):.3f}")

print("\n### PAPER 1, TABLE II  (Rb87, f=100Hz, N=1e5) ###")
f=100.;N=1e5;ah=aho(f);x=15*N*a/ah;R=ah*x**0.2;eta=x**(-0.8);xi=ah**2/R
mu=0.5*m*(2*np.pi*f)**2*R**2; g=4*np.pi*hbar**2*a/m; n0=mu/g; wB=np.sqrt(5)*f
print(f"a_ho={ah*1e6:.3f} R={R*1e6:.3f} xi={xi*1e6:.4f} eta={eta:.3e} n0={n0*1e-6:.3e} mu/h={mu/(2*np.pi*hbar):.1f}Hz wB={wB:.2f}Hz")
print(f"sqrt(n0 a^3)={np.sqrt(n0*a**3):.3e}   n0a^3={n0*a**3:.3e}")
for lbl,rel in [("DG at eta",eta),("DG at 1.5 mHz",1.5e-3/wB),("finite-size (Braaten-Pearson) ~eta",eta),
                ("LHY (Pitaevskii-Stringari)",np.sqrt(n0*a**3)),("thermal T/Tc=0.5",1e-2)]:
    print(f"  {lbl:38s} rel={rel:.3e}  abs={rel*wB*1e3:10.2f} mHz")

print("\n### PAPER 1, TABLE III: differential protocol requirements ###")
tgt=1.5e-3/wB
print(f"target relative resolution = {tgt:.2e}")
print(f"  atom number  dN/N < {tgt/(0.8*eta)*100:.2f} %   (c=1)")
print(f"  trap freq    dw/w < {tgt:.1e}   -> dP/P < {2*tgt:.1e}")
print(f"  temperature  d(T/Tc) < {tgt/3e-2:.1e}  (assuming dw/w ~ 3e-2 per unit T/Tc)")
for T in [1.,5.,20.]:
    print(f"  T_obs={T:4.1f}s Fourier {1/(2*np.pi*T)/wB:.2e} rel; N_shots(SNR=20)={(1/(2*np.pi*T)/(20*tgt*wB))**2:8.1f}")

print("\n### PAPER 2: resonant enhancement ###")
for Q in [1e2,1e3,1e4]:
    for snr in [10,30]:
        print(f"  Q={Q:.0e} SNR={snr:2d} -> N_shots={ (1.0/(Q*snr*tgt))**2:10.2f}  t={(1.0/(Q*snr*tgt))**2*30/3600:8.3f} h")
print("  box trap: uniform density, xi uniform; eta_box = (xi/L)^2 directly tunable via n and a")
for L in [10e-6,30e-6,50e-6]:
    for n in [1e19,1e20,1e21]:
        xi_b=1/np.sqrt(8*np.pi*n*a); print(f"   L={L*1e6:4.0f}um n={n*1e-6:.1e}cm^-3 xi={xi_b*1e6:6.3f}um eta={(xi_b/L)**2:.3e} n a^3={n*a**3:.2e}")

print("\n### PAPER 3: linear vs exponential suppression ###")
for al2 in [4,8,11,20]:
    print(f"  cat |alpha|^2={al2:3d}: bit-flip suppression ~ exp(2|a|^2) = {np.exp(2*al2):.3e}")
for etam in [1e-3,1e-2,0.1,0.5]:
    print(f"  perturbative screening eta_max={etam:6.3f}: max suppression 1/(1-eta) = {1/(1-etam):.4f}")
print(f"  ratio needed to match |alpha|^2=8 : {np.exp(16)*(1-0.01):.3e}")
print(f"  equivalent: would need eta_max = 1 - exp(-16) = {1-np.exp(-16):.15f}  (i.e. 1 - 1.1e-7)")
