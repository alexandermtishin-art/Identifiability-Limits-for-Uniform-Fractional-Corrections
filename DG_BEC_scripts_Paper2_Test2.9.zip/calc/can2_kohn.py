"""Anharmonic coefficients: numerical verification of the monopole 7/9,
and derivation of the Kohn-mode coefficient 3/7.  Produces c_an = 22/63."""
import numpy as np, sympy as sp
from scipy.optimize import fsolve

# ---- 1. numerical check of (dw/w)_B = (7/9) u0 --------------------------
def r2_of_A(A, b, Ng, Rguess):
    f = lambda R: 8*np.pi*A*R[0]**5*(10*(b*R[0]**2/A)+7)/105 - Ng
    R = fsolve(f, [Rguess])[0]
    u = b*R**2/A
    return R**2*(14*u+9)/(3*(10*u+7))

print("monopole coefficient, analytic 7/9 = %.8f" % (7/9))
Ng = 1.0
for eps in [-1e-4, -1e-3, -1e-2, -3e-2]:
    A = 1.0
    R0 = (105*Ng/(8*np.pi*A*7))**0.2
    b = eps*A/R0**2
    h = 1e-7
    d = (r2_of_A(A+h, b, Ng, R0) - r2_of_A(A-h, b, Ng, R0))/(2*h)
    w = -4*r2_of_A(A, b, Ng, R0)/d/(4*A)
    num = 0.5*(w/2.5 - 1)
    print(f"  u0={eps:+.5f}: numeric {num:+.8e}  analytic {7/9*eps:+.8e}"
          f"  ratio {num/(7/9*eps):.5f}")

# ---- 2. Kohn mode: expansion about the centre of mass -------------------
X, x, w0, m, om, x2, x4 = sp.symbols('X x w_0 m omega x2 x4', positive=True)
V = sp.Rational(1, 2)*m*om**2*(X+x)**2*(1 - (X+x)**2/w0**2)
e = sp.expand(V).subs(x**4, x4).subs(x**3, 0).subs(x**2, x2).subs(x, 0)
e = sp.expand(e)
print("\nKohn mode:")
print("  coeff of X^2 :", sp.simplify(e.coeff(X, 2)))
print("  coeff of X^4 :", sp.simplify(e.coeff(X, 4)))
print("  => w_D^2 = w0^2 (1 - 6<x^2>/w_0^2);  TF: <x^2> = R^2/7")
print("  => (dw/w)_D = -(3/7)(R/w_0)^2  and Duffing -3 A_osc^2/(4 w_0^2)")

# ---- 3. the residual in the ratio --------------------------------------
cB, cD = sp.Rational(7, 9), sp.Rational(3, 7)
cR = cB - cD
print(f"\nc_an (ratio) = 7/9 - 3/7 = {cR} = {float(cR):.5f}")
print(f"suppression relative to breathing alone: {float(cB/cR):.2f}x")

R, tgt = 6.399e-6, 6.708e-6
for c, lab in [(1.0, 'c_an = 1 (naive)'), (float(cB), 'breathing alone'),
               (float(cR), 'ratio')]:
    print(f"  {lab:18s}: w_0 > {R*np.sqrt(c/tgt)*1e3:.3f} mm")
