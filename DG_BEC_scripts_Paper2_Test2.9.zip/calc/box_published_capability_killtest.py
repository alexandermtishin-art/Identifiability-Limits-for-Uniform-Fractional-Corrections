#!/usr/bin/env python3
"""
Paper 2, Test 2.5: published-capability kill-test.

This is deliberately conservative: it compares the Paper-2 benchmark shift
and required line-center precision against numerical performance explicitly
reported in representative published Bragg experiments. It does NOT infer
unreported modern capabilities.

Published anchor used quantitatively:
Gotlibovych et al., PRA 89, 061604(R) (2014):
  homogeneous 87Rb optical-box BEC;
  35 ms Bragg pulse;
  resonance near 1 kHz;
  interaction-energy / resonance-shift precision = 2 Hz
  (equivalent to k_B * 100 pK).

Paper-2 Test 2.4:
  benchmark shifts = 4.75--52.62 mHz for the first eight nominal momenta;
  required per-point relative center precision 1e-6 =
  0.190--2.104 mHz.

We report ratios only. A linewidth-to-center-precision ratio is NOT used as a
precision claim.
"""

published_center_precision_hz=2.0
pulse_s=0.035
target_shift_mhz=[4.7472,9.7001,15.0504,20.9654,27.5832,35.0131,43.3385,52.6223]
required_center_mhz=[0.1898,0.3878,0.6017,0.8381,1.1027,1.3997,1.7325,2.1037]

print("=== PAPER 2 TEST 2.5: PUBLISHED-CAPABILITY KILL-TEST ===")
print("Published quantitative anchor: Gotlibovych et al. PRA 89, 061604(R) (2014)")
print(f"reported resonance-shift precision: {published_center_precision_hz:.1f} Hz")
print(f"Bragg pulse duration: {pulse_s*1e3:.0f} ms")
print()
print("j  benchmark shift (mHz)  required center sigma (mHz)  2-Hz / target  2-Hz / required")
for i,(t,r) in enumerate(zip(target_shift_mhz,required_center_mhz),1):
    print(f"{i:2d} {t:18.4f} {r:27.4f} {published_center_precision_hz*1000/t:13.1f} {published_center_precision_hz*1000/r:16.1f}")

print()
print("BEST-CASE RATIOS WITHIN j=1..8:")
print(f"Published 2-Hz precision / largest benchmark shift = {published_center_precision_hz*1000/max(target_shift_mhz):.1f}x")
print(f"Published 2-Hz precision / loosest required center sigma = {published_center_precision_hz*1000/max(required_center_mhz):.1f}x")
print(f"Published 2-Hz precision / tightest required center sigma = {published_center_precision_hz*1000/min(required_center_mhz):.1f}x")
print()
print("FOURIER SCALE:")
print(f"1/tau for 35 ms = {1/pulse_s:.1f} Hz (raw transform scale; not a line-center uncertainty).")
print()
print("2017 homogeneous-39K Bragg work used a 2-ms pulse and reported <=~10% systematic")
print("errors in interaction frequency shifts for its strongly interacting, particle-like regime.")
print("This establishes platform maturity but does not demonstrate millihertz center metrology.")
print()
print("FINAL TEST-2.5 VERDICT:")
print("1) The experimental PLATFORM is established: homogeneous optical-box BEC + Bragg spectroscopy.")
print("2) The required Paper-2 metrology is NOT demonstrated by the representative published benchmarks checked.")
print("3) Relative to the explicitly reported 2-Hz shift precision in the 2014 homogeneous-box experiment,")
print("   the present benchmark signal is ~38--421 times smaller across j=1..8.")
print("4) The 1e-6 per-point center requirement is ~951--10537 times tighter than 2 Hz.")
print("5) Therefore Paper 2 should NOT claim present experimental readiness.")
print("6) The scientifically defensible center is an identifiability/no-go + metrological-requirements paper,")
print("   with calibrated-k Bragg spectroscopy presented as a possible rescue architecture rather than a ready protocol.")
