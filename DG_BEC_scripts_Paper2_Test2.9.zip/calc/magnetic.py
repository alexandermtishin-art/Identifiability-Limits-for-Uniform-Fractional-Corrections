import numpy as np
muB=9.2740100783e-24; amu=1.66053907e-27; m=87*amu
mu=muB            # |F=2,m_F=2>: g_F m_F = 1
R=6.399e-6; tgt=6.708e-6; c_an=22/63
G=1e-4            # 1 Gauss in Tesla

print("### IOFFE-PRITCHARD RADIAL DIRECTION ###")
print("|B(rho)| = sqrt(B0^2 + B'^2 rho^2) = B0[1 + (B'rho/B0)^2/2 - (B'rho/B0)^4/8 + ...]")
print("U = mu|B| => 1/2 m w^2 = mu B'^2/(2 B0)   and quartic coeff = -mu B'^4/(8 B0^3)")
print("Writing U = 1/2 m w^2 rho^2 (1 - rho^2/w_eff^2):")
print("   w_eff = 2 B0 / B'      and, eliminating B',   w_eff = 2 sqrt(mu B0 /(m w0^2))")
print("   => w_eff grows only as sqrt(B0); it is NOT set by coil geometry.\n")

f=100.; w0=2*np.pi*f
print(f"Rb-87, radial omega_0/2pi = {f:.0f} Hz:")
print("   B0[G]   B'[G/cm]   w_eff        c_an(R/w_eff)^2   /target   verdict")
for B0G in [0.5,1,3,10,30,100,200]:
    B0=B0G*G
    Bp=np.sqrt(m*w0**2*B0/mu)              # T/m
    weff=2*B0/Bp
    v=c_an*(R/weff)**2
    verdict = 'meets target' if v<tgt else ('marginal' if v<10*tgt else 'insufficient')
    print(f"   {B0G:6.1f}  {Bp/G*1e-2:9.1f}   {weff*1e6:7.1f} um  {v:.3e}       {v/tgt:8.2f}  {verdict}")

print("\n   requirement w_eff > R*sqrt(c_an/target):")
wneed=R*np.sqrt(c_an/tgt)
B0need=(wneed/2)**2*m*w0**2/mu
print(f"     w_eff > {wneed*1e3:.3f} mm  ->  B0 > {B0need/G:.1f} G,  B' = {np.sqrt(m*w0**2*B0need/mu)/G*1e-2:.0f} G/cm")

print("\n### AXIAL (CURVATURE) DIRECTION ###")
print("Axial confinement comes from B''; anharmonicity is set by the coil scale d ~ 1 cm.")
for d in [5e-3,1e-2,3e-2]:
    print(f"   d={d*1e3:4.0f} mm -> c_an(R/d)^2 = {c_an*(R/d)**2:.2e}  ({c_an*(R/d)**2/tgt:.2e} x target)")
print("   -> the axial direction is harmonic to far beyond requirement; only radial binds.")

print("\n### THE REAL ADVANTAGE: w_eff IS AN EXPERIMENTAL KNOB ###")
print("At fixed omega_0, B0 and B' can be varied together (B' = sqrt(m w0^2 B0/mu)),")
print("so w_eff = 2 sqrt(mu B0/(m w0^2)) is tunable IN SITU by the bias field alone.")
print("The anharmonic shift then becomes MEASURABLE, not merely computable:")
print("   measure (w_B/w_D) at several B0, fit against 1/w_eff^2, extrapolate 1/w_eff^2 -> 0.\n")
print("   B0[G]   w_eff[um]   1/w_eff^2 [mm^-2]   predicted shift")
for B0G in [3,10,30,100]:
    B0=B0G*G; Bp=np.sqrt(m*w0**2*B0/mu); weff=2*B0/Bp
    print(f"   {B0G:5.0f}   {weff*1e6:8.1f}    {1e-6/weff**2:14.2f}      {c_an*(R/weff)**2:.3e}")

print("\n### COMPARISON OF THE TWO ROUTES ###")
print(" optical : w_0 fixed by beam; power ~ w_0^4 at fixed omega_0; 300 um costs 1.3e3 x power")
print(" magnetic: w_eff ~ sqrt(B0);  no power penalty on the laser, cost is gradient B' ~ sqrt(B0)")
for B0G,lab in [(10,'modest'),(100,'demanding'),(200,'hard')]:
    B0=B0G*G; Bp=np.sqrt(m*w0**2*B0/mu)
    print(f"    B0={B0G:4.0f} G ({lab:9s}): B'={Bp/G*1e-2:6.0f} G/cm, w_eff={2*B0/Bp*1e6:7.0f} um")
