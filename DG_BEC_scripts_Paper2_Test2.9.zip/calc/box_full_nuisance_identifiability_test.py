#!/usr/bin/env python3
"""
Paper 2, Test 2.7: full nuisance-space identifiability stress test.

Question
--------
After the calibrated-k rescue, can a mode-independent fractional signal s still be
distinguished when physically plausible structured nuisance directions are admitted?

This is deliberately a SHAPE/JACOBIAN test.  It is not a precision many-body model.
The nuisance basis is chosen to span conservative spectral shapes associated with:
  - healing-length / mean-field scale,
  - absolute wave-number calibration,
  - LHY-like beyond-mean-field correction,
  - finite-temperature low-k distortion,
  - wall/finite-size response,
  - drive/line-shape distortion.

The global frequency-scale direction is excluded from the rescue fit because it is
analytically exactly degenerate with s; the manuscript already requires an absolute
frequency reference.

For each nuisance basis we compute:
  rank([nuisances, signal]),
  the fraction of the signal orthogonal to nuisance space,
  condition number,
  and the 1-sigma uncertainty on s for 1e-6 relative noise per point.
"""

import numpy as np

xi=0.274e-6
# representative externally imposed k points: k*xi from 0.18 to 1.8
x=np.geomspace(0.18,1.8,12)                 # x = k xi
u=x*x/2
one=np.ones_like(x)

# Exact Bogoliubov logarithmic derivatives for calibrated k.
d_xi=-1/(1+u)
d_k=(1+2*u)/(1+u)

# Conservative nuisance SHAPES. Amplitudes are fitted coefficients, so only shape matters.
# LHY-like: leading correction is stronger in phonon regime and rolls toward particle regime.
lhy=1/(1+u)
# thermal low-k shape: smooth infrared-weighted distortion.
thermal=1/(1+x*x)
# finite-size/wall shape: strongest at low k; regularized to avoid singular endpoint.
wall=1/(x*x+0.15**2)
# drive/line-shape: smooth curvature versus k, centered to avoid trivial constant component.
drive=x*x

basis=[
 ("xi",d_xi),
 ("k-scale",d_k),
 ("LHY-like",lhy),
 ("finite-T-like",thermal),
 ("wall/finite-size",wall),
 ("drive/lineshape",drive),
]

def normalized(v):
    v=np.asarray(v,float)
    n=np.linalg.norm(v)
    return v/n if n else v

def metrics(cols):
    X=np.column_stack(cols) if cols else np.empty((len(one),0))
    if X.shape[1]:
        Q=np.linalg.qr(X,mode="reduced")[0]
        resid=one-Q@(Q.T@one)
    else:
        resid=one.copy()
    orth=np.linalg.norm(resid)/np.linalg.norm(one)
    M=np.column_stack(cols+[one])
    rank=np.linalg.matrix_rank(M,tol=1e-11)
    cond=np.linalg.cond(M)
    sigma_rel=1e-6
    cov=np.linalg.pinv(M.T@M)*sigma_rel**2
    sig_s=np.sqrt(cov[-1,-1])
    return rank,M.shape[1],orth,cond,sig_s

print("=== PAPER 2 TEST 2.7: FULL NUISANCE-SPACE IDENTIFIABILITY ===")
print("12 calibrated-k points, k*xi =",np.array2string(x,precision=3))
print("Absolute global frequency scale is NOT floated: analytically it is exactly degenerate with s.")
print()
sets=[
 ("xi only",["xi"]),
 ("xi + k-scale",["xi","k-scale"]),
 ("+ LHY-like",["xi","k-scale","LHY-like"]),
 ("+ finite-T-like",["xi","k-scale","LHY-like","finite-T-like"]),
 ("+ wall",["xi","k-scale","LHY-like","finite-T-like","wall/finite-size"]),
 ("+ drive",["xi","k-scale","LHY-like","finite-T-like","wall/finite-size","drive/lineshape"]),
]
D=dict(basis)
for name,names in sets:
    vals=[D[n] for n in names]
    rank,ncol,orth,cond,sig=metrics(vals)
    print(f"{name:22s}: rank {rank}/{ncol}; signal orthogonal fraction={orth:.3e}; "
          f"cond={cond:.3e}; sigma_s@1e-6={sig:.3e}")

print()
print("PAIRWISE CORRELATIONS WITH UNIFORM SIGNAL")
for n,v in basis:
    c=np.dot(normalized(v),normalized(one))
    print(f"{n:18s}: corr={c:+.8f}")

# Exact analytic warning: d_k - d_xi = 2 for calibrated k.
print()
print("EXACT IDENTITY CHECK FOR CALIBRATED k")
err=np.max(np.abs(d_k-d_xi-2*one))
print("max |d_k - d_xi - 2| =",err)
print("Therefore if BOTH xi and the absolute k scale are allowed to float freely,")
print("the uniform signal is again exactly degenerate: 1 = (d_k - d_xi)/2.")
print()
print("TEST-2.7 VERDICT")
print("The calibrated-k rescue is sufficient only if the absolute k scale is externally constrained.")
print("If k-scale is floated freely together with xi, the signal dies exactly, before adding LHY/T/wall/drive.")
print("With an external k prior, structured nuisance shapes can be fitted, but their conditioning and priors")
print("must be propagated quantitatively. The strongest theorem is therefore a TWO-ANCHOR requirement:")
print("absolute wave-number reference + absolute frequency reference.")
