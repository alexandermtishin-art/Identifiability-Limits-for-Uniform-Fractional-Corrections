#!/usr/bin/env python3
"""
Paper 2, Test 2.1: exact-Bogoliubov-dispersion kill-test.

Tests the central Aj^2+B claim at the current working point:
87Rb, n=1e14 cm^-3, L=5 um.

Definitions used by the manuscript:
    xi = 1/sqrt(8*pi*n*a)
    eta = (xi/L)^2
    k_j = pi*j/L
    c = sqrt(g*n/m)

Exact uniform-gas Bogoliubov dispersion:
    omega_j = c*k_j*sqrt(1 + k_j^2*xi^2/2)

Therefore the exact relative correction to the phonon line c*k_j is
    r_j = sqrt(1 + (pi^2*j^2*eta)/2) - 1.

The manuscript's truncated model keeps only
    r_j ~= (pi^2/4)*j^2*eta.

This script asks:
(1) How large is the truncation residual compared with the target screening
    intercept c_scr*eta?
(2) If exact standard data with NO screening are fit to A*j^2+B, how large a
    spurious B is produced?
(3) If the exact dispersion is used instead, how identifiable is a uniform
    multiplicative screening offset once the density/healing-length scale is
    allowed to float?
"""
import numpy as np

HBAR=1.054571817e-34
AMU=1.66053906660e-27
M=87*AMU
A=5.3e-9
N_DENS=1e20       # 1e14 cm^-3
L=5e-6
C_SCR=0.00833

XI=1/np.sqrt(8*np.pi*N_DENS*A)
ETA=(XI/L)**2
G=4*np.pi*HBAR**2*A/M
C=np.sqrt(G*N_DENS/M)
TARGET=C_SCR*ETA

def exact_relative(j):
    z=np.pi**2*j**2*ETA
    return np.sqrt(1+z/2)-1

def quadratic_relative(j):
    return (np.pi**2/4)*j**2*ETA

print("=== PAPER 2 TEST 2.1: EXACT BOGOLIUBOV DISPERSION ===")
print(f"working point: 87Rb, n=1e14 cm^-3, L=5 um")
print(f"xi={XI*1e6:.6f} um")
print(f"eta={ETA:.9e}")
print(f"sound speed={C*1e3:.6f} mm/s")
print(f"target c_scr={C_SCR:.5f}")
print(f"target relative intercept c_scr*eta={TARGET:.9e}")
print()

js=np.arange(1,5,dtype=float)
rex=np.array([exact_relative(j) for j in js])
r2=np.array([quadratic_relative(j) for j in js])
res=rex-r2

print("j   exact_rel       Aj^2 term       omitted exact-Aj^2     omitted/target")
for j,a,b,d in zip(js,rex,r2,res):
    print(f"{int(j):d}  {a: .9e}  {b: .9e}  {d: .9e}       {d/TARGET: .3f}")

# Fit exact null data to the manuscript's A*j^2+B model.
X=np.column_stack([js**2,np.ones_like(js)])
Afit,Bfit=np.linalg.lstsq(X,rex,rcond=None)[0]
A0=(np.pi**2/4)*ETA
print()
print("=== FALSE-INTERCEPT TEST: exact standard data, no screening ===")
print(f"leading-order A0=(pi^2/4)eta = {A0:.9e}")
print(f"fit A = {Afit:.9e}")
print(f"fit B = {Bfit:.9e}")
print(f"B / target = {Bfit/TARGET:.3f}")
print("Verdict: A*j^2+B is not a safe precision model at this working point.")

# Exact-model identifiability.
# Frequencies scale as (1+s) * [hbar/(sqrt(2)m xi)] k sqrt(1+k^2 xi^2/2),
# with s=c_scr*eta.  If xi (density scale) is unknown, the log-frequency
# derivative wrt ln xi is -1/(1+u_j), u_j=k_j^2 xi^2/2.
# Project the constant screening direction onto the orthogonal complement
# of that nuisance direction.
z=np.pi**2*js**2*ETA
u=z/2
dlog_dlnxi=-1/(1+u)
signal=np.ones_like(js)
signal_res=signal-dlog_dlnxi*np.dot(dlog_dlnxi,signal)/np.dot(dlog_dlnxi,dlog_dlnxi)
frac=np.linalg.norm(signal_res)/np.linalg.norm(signal)
norm=np.linalg.norm(signal_res)

print()
print("=== EXACT-MODEL IDENTIFIABILITY WITH FLOATING DENSITY/xi SCALE ===")
print(f"screening-vector residual fraction = {frac:.6f}")
print(f"||identifiable screening direction|| = {norm:.6f}")
print(f"overlap with xi nuisance = {np.dot(signal,dlog_dlnxi)/(np.linalg.norm(signal)*np.linalg.norm(dlog_dlnxi)):.6f}")
for sy in [1e-5,5e-6,2e-6,1e-6,5e-7]:
    sig_s=sy/norm
    print(f"per-mode relative sigma={sy:.1e}: sigma(screening offset)={sig_s:.3e}, target/Sigma={TARGET/sig_s:.2f}")

print()
print("=== MODE-COUNT LEVER ===")
for J in [2,3,4,5,6,8,10]:
    jj=np.arange(1,J+1,dtype=float)
    zz=np.pi**2*jj**2*ETA
    uu=zz/2
    dq=-1/(1+uu)
    one=np.ones_like(jj)
    rr=one-dq*np.dot(dq,one)/np.dot(dq,dq)
    f=np.linalg.norm(rr)/np.linalg.norm(one)
    nn=np.linalg.norm(rr)
    sig1=TARGET/(1e-6/nn)
    print(f"j=1..{J:2d}: residual fraction={f:.4f}, target significance at sigma_y=1e-6 = {sig1:.2f} sigma")

print()
print("FINAL TEST-2.1 VERDICT:")
print("1) The original linearized Aj^2+B central fit FAILS at the quoted working point.")
print("2) Exact Bogoliubov subtraction rescues the logical possibility of a constant screening term.")
print("3) But with modes j=1..4 the constant screening direction is 99.73% aligned with the")
print("   floating density/healing-length nuisance; only 7.36% of its norm is independently visible.")
print("4) Therefore Paper 2 must be reformulated around exact-dispersion self-calibration and")
print("   realistic nuisance identifiability, not around the truncated Aj^2+B regression.")
