# Calculation and manuscript-generation scripts

A. M. Tishin — screening-type corrections in the collective spectrum of a
Bose–Einstein condensate. Everything here regenerates the numbers and the
three manuscripts from scratch.

## Requirements

```
python3   numpy scipy sympy
node      docx        (npm i docx)
```

Optional, for rendering the `.docx` to PDF for visual checking:
LibreOffice (`soffice`) and Poppler (`pdftoppm`, `pdftotext`).

---

## calc/ — the physics

Run any of these directly; each prints a self-contained table.

| script | what it computes | key output |
|---|---|---|
| `eta.py` | η against the Thomas–Fermi validity parameter | `Na/a_ho = η^(−5/4)/15`; species/trap independence verified for ⁸⁷Rb and ³⁹K |
| `sys.py` | signal against known systematics, breathing mode | η = 8.05×10⁻⁴; LHY 870×, thermal 1490× the 1.5 mHz target |
| `vortex.py` | vortex quadrupole splitting as a readout channel | 19.9 Hz splitting, 1.3×10⁴ × larger than the target |
| `feas.py` | statistical and stability budget | 25 shots at Q=10³, S=30; δN/N < 1 % |
| `box.py` | uniform-potential decoupling of η from na³ | η = (8πnaL²)⁻¹, independent of na³ |
| `wp.py` | box working point and mode ladder | ⁸⁷Rb, n=10¹⁴ cm⁻³, L=5 μm; f_j = 188, 377, 565, 754 Hz |
| `tables.py` | consolidated tables for papers 1 and 2 | Tables I–III of paper 1 |
| `can.py` | symbolic monopole anharmonic coefficient | `(δω/ω)_B = −(7/9)(R_TF/w₀)²` |
| `can2_kohn.py` | numerical check of 7/9 + Kohn-mode coefficient | `c_an = 7/9 − 3/7 = 22/63 = 0.3492` |
| `magnetic.py` | Ioffe–Pritchard radial anharmonicity | `w_eff = 2(μB₀/mω₀²)^(1/2)`; 1 G → 255 μm, 100 G → 2.55 mm |

### Results that are load-bearing

- **`eta.py`** — the identity `Na/a_ho = η^(−5/4)/15` is exact and kills the
  ξ → L limit: η = 1 sits at Na/a_ho ≈ 0.07, i.e. ~10 atoms. No species,
  trap frequency or Feshbach tuning evades it; a and a_ho cancel.
- **`box.py`** — in a box, η and na³ are independent. η = 1.9×10⁻² at
  na³ = 1.5×10⁻⁵ is reachable; no harmonic trap can produce that pair.
- **`wp.py`** — quantum pressure gives (π²/4)j²η, quadratic in mode index;
  a system-scale screening term is j-independent. Fit `A j² + B` separates
  them. The quartic Bogoliubov term exceeds the target intercept already at
  j = 1 (by 1.14×) and by 292× at j = 4 — it must be carried from j = 1.
- **`can2_kohn.py`** — the ratio ω_B/ω_D suppresses anharmonicity by 2.86×
  as well as removing trap calibration. Both modes sample the same quartic
  potential with different weights: 7/9 and 3/7.
- **`magnetic.py`** — the radial anharmonic length of an Ioffe–Pritchard
  trap contains no coil geometry. A conventional 1 G bias gives 255 μm, no
  better than a large-waist optical trap. The real advantage is that w_eff
  is tunable in situ by B₀, making the anharmonic term measurable rather
  than computable.

---

## manuscripts/ — the papers

```
node paper1.js    # validity bound, degeneracy, ratio observable, anharmonicity
node paper2.js    # box geometry, mode-index discrimination
node paper3.js    # no-go for perturbative screening in error exclusion
```

Each writes a `.docx` to `../out/`. Create that directory first.

`common.js` holds the formatting layer. Inline markup used throughout the
manuscript sources:

```
_x_     italic
~ab~    true subscript
^ab^    true superscript
*b*     bold
\_      literal underscore
```

The parser recurses, so nested markup works: `*ceiling is _η_ ≈ 10^−2^*`
renders with bold, italic eta and a true superscript.

### Two checks worth running before every rebuild

Unbalanced markup delimiters silently swallow the rest of a paragraph into
a subscript. This has happened twice:

```bash
python3 - <<'EOF'
import re
for p in ['paper1.js','paper2.js','paper3.js']:
    bad = 0
    src = open(p, encoding='utf-8').read()
    for m in re.finditer(r'c\.push\((?:P|H1|H2|CENTER|BULLET|CAPTION|TITLE|EQ)\("((?:[^"\\]|\\.)*)"', src):
        for ch in '_~^*':
            if m.group(1).count(ch) % 2:
                bad += 1
                print(p, 'UNBALANCED', repr(ch), m.group(1)[:70])
    print(p, '->', bad)
EOF
```

Reference numbering must follow first appearance:

```bash
pdftotext paper.pdf - | sed '/^References$/,$d' \
  | grep -oE '\[[0-9]+(,[0-9]+)*\]' | tr -d '[]' | tr ',' '\n' \
  | awk '!seen[$0]++' | tr '\n' ' '
```

The output must be strictly increasing with no gaps. A gap means an
uncited reference; a descending step means a citation inserted out of order.

---

## Open items

- `can.py` / `can2_kohn.py` use the isotropic model V = Ar² + br⁴. A real
  single-beam trap has different radial and axial anharmonicity; the two
  coefficients should be recomputed for the actual geometry. The structure
  — partial cancellation with a residual of order a third — is not expected
  to change, but this has not been verified.
- The finite-size coefficient c_FS for the monopole, with and without a
  vortex, is not computed anywhere here. It requires a Bogoliubov–de Gennes
  solution at better than 10⁻⁶ relative accuracy and is the prerequisite
  for the differential protocol of paper 1, Sec. VII.
- The screening prefactor 8×10⁻³ used in paper 1 Table II and paper 2
  Table II is back-derived from the quoted 1.5 mHz. It must be replaced by
  the value following from the source equation before submission.


### Paper 2 exact-dispersion kill-test

`box_exact_dispersion_killtest.py` replaces the truncated phonon expansion by the exact
uniform-gas Bogoliubov dispersion at the current Paper 2 working point. The original
`A j^2 + B` precision regression does **not** survive: fitting exact zero-screening
Bogoliubov data for `j=1..4` to that truncated form produces a spurious intercept
about 39.5 times larger than the benchmark screening intercept. The logical
mode-index idea is not killed, because the exact dispersion has curvature that can
self-calibrate the healing-length/density scale, but the screening direction is highly
correlated with that scale for the first four modes. Paper 2 should therefore use the
exact dispersion and a full nuisance-space identifiability test rather than a truncated
quadratic fit.


### Paper 2 boundary/calibration kill-test

`box_boundary_calibration_killtest.py` tests the exact Bogoliubov mode ladder against
simultaneous uncertainty in the healing-length/density scale and the effective box
length.  For
`omega_j = c k_j sqrt(1+k_j^2 xi^2/2)`, with `c proportional to xi^-1` and
`k_j=pi j/L`, the logarithmic derivatives satisfy the exact identity

`d ln omega/d ln L + d ln omega/d ln xi = -2`.

Therefore a mode-independent fractional screening offset lies exactly in the span of
the `xi` and `L` nuisance directions.  A mode-index ladder by itself cannot identify
screening if both absolute scales are allowed to float.  First-order finite-wall
penetration that acts only as an effective-length shift is part of the same degeneracy.
With both scales unconstrained the screening variance is formally infinite. Paper 2
must therefore include an independent calibration of at least one absolute scale, or
introduce an additional observable that breaks this rescaling symmetry.


### Paper 2 minimal-observable rescue test

`box_minimal_observable_rescue_test.py` asks what additional observable breaks the exact
`(L, xi, screening)` degeneracy found in Test 2.2.  Adding more standing-wave mode indices,
more box sizes, or more densities does **not** help if those scans determine only relative
changes: the common absolute rescaling symmetry remains exact.  A true absolute anchor is
required.

At the current working point and with six modes measured at `1e-6` relative precision, a
5-sigma benchmark test requires roughly few-parts-in-`1e6` absolute calibration of `L` or
`xi` (equivalently absolute density/chemical potential).  The mathematically equivalent
alternative is an externally calibrated wave-number scale.  This suggests a qualitatively
different rescue: use the uniform box as the medium, but probe the exact Bogoliubov dispersion
at externally calibrated momenta (Bragg/recoil spectroscopy) rather than relying only on
wall-defined standing-mode indices.  Optical momentum calibration can, in principle, provide
an absolute scale much more naturally than micron-scale box imaging or absolute density
metrology.


### Paper 2 Bragg/recoil realism kill-test

`box_bragg_realism_killtest.py` stress-tests the calibrated-momentum rescue with
measurement-level nuisance directions.  The exact-dispersion route remains identifiable
provided both the momentum scale and the frequency/timebase scale are absolutely anchored.
A completely free global frequency scale is exactly degenerate with a mode-independent
screening fraction.  With a `k` prior of order `2e-6`, a much tighter frequency/timebase
reference, an additive detuning-zero nuisance, and a conservative free density-inhomogeneity
shape nuisance, a sufficiently broad set of calibrated momentum points can retain sensitivity.
The dominant practical challenge becomes line-center metrology rather than algebraic rank:
the benchmark shifts are at the tens-of-millihertz scale and demand sub-mHz-to-few-mHz
center determination depending on momentum.  This motivates an explicit literature check
for prior Bragg/recoil Bogoliubov spectroscopy in uniform boxes and for demonstrated
frequency/momentum precision.


### Paper 2 published-capability kill-test

`box_published_capability_killtest.py` compares the metrological requirements from Test 2.4
with explicit published performance numbers rather than with an assumed future apparatus.
The 2014 homogeneous-87Rb optical-box Bragg experiment of Gotlibovych *et al.* reported
2-Hz precision for interaction-induced resonance shifts using 35-ms Bragg pulses.  Against
that published benchmark, the present 4.75--52.6 mHz target shifts are roughly 38--421 times
smaller, while the aggressive `1e-6` per-point line-center requirements are roughly
`9.5e2--1.05e4` times tighter.  Later homogeneous Bragg work demonstrates a mature platform
and tunable momentum transfer, but the papers checked here do not demonstrate millihertz
line-center metrology.  Paper 2 should therefore be framed around the exact identifiability
no-go and quantitative metrological requirements; calibrated-k Bragg/recoil spectroscopy is
a rescue architecture, not a demonstrated ready-to-run experiment.


### Paper 2 quantum/statistical feasibility test

`box_quantum_statistical_limit_test.py` compares the sub-mHz-to-few-mHz center
requirements with an ideal standard-quantum-limit phase-estimation benchmark,
`sigma_f >= 1/(2*pi*T*sqrt(N_tot))`.  The calculation is deliberately used only
as a lower-bound/resource test; it does not claim that direct Bragg spectroscopy
saturates the bound.  The required sensitivity is not prohibited by quantum
projection noise: at fixed 35-ms interrogation the hardest point is statistically
expensive, but the required atom number falls quadratically with longer coherent
interrogation time.  This separates fundamental possibility from demonstrated
technical capability.  The present gap is dominated by coherence, line-shape,
momentum/frequency calibration, boundary and density systematics rather than by
a known nonzero quantum floor.


### Paper 2 Test 2.7 — full nuisance-space identifiability

`box_full_nuisance_identifiability_test.py` stress-tests the calibrated-k architecture against
healing-length, wave-number-scale, LHY-like, finite-temperature-like, wall/finite-size, and
drive/line-shape nuisance directions.  The decisive result is analytic and exact:
for externally addressed k, `d_lnk - d_lnxi = 2`, so `1 = (d_lnk - d_lnxi)/2`.  Thus the uniform signal is exactly lost
again if both xi and the absolute k scale are floated.  The rescue therefore requires an
external prior/reference on the absolute wave-number scale, in addition to the already-required
absolute frequency reference.  Structured standard-physics nuisances then become a conditioning
problem rather than an exact symmetry, subject to model validation.

### Paper 2 Test 2.8 — Bragg line-center Fisher benchmark

`box_bragg_fisher_crlb_test.py` computes a line-center Cramer-Rao benchmark for a symmetric
Gaussian weak-Bragg response with amplitude, background, width and center fitted jointly.
The test demonstrates that a Hz-scale raw linewidth does not create a Hz-scale line-center floor:
sub-mHz center estimation is permitted by the Fisher information at sufficiently high effective
SNR/repetition.  The result is explicitly a lower-bound benchmark and does not include drift,
correlated atom-number noise, nonlinear response, finite-temperature asymmetry, or calibration
systematics.


### Paper 2 Test 2.9 — quantitative prior budget

`box_quantitative_prior_budget_test.py` propagates Gaussian external priors through the calibrated-wave-number Fisher/Jacobian model. For the benchmark s=2.50144e-5, 12 points spanning k xi=0.18–1.8, and 1e-6 relative per-point noise, the baseline prior set (sigma_k/k=2e-6, sigma_xi/xi=5e-6, tight global frequency reference, and 2e-6 RMS priors on four structured nuisance shapes) gives sigma_s=4.77e-6 or 5.24 sigma. Holding the other baseline assumptions fixed, the approximate 5-sigma boundaries are sigma_k/k=2.25e-6, sigma_xi/xi=5.81e-6, sigma_f/f=1.49e-6, and 2.52e-6 when all four structured spectral-nuisance priors are relaxed together. These are protocol-dependent design requirements, not universal constants.
