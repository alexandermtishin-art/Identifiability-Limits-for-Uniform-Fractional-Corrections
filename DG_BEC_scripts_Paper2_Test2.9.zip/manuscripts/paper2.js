const fs = require('fs');
const { Packer, P, H1, H2, TITLE, CENTER, EQ, BULLET, TBL, CAPTION, RULE, REF, buildDoc } = require('./common');

const c = [];

c.push(TITLE("Uniform Confinement Decouples the Screening Parameter from Diluteness: Mode-Index Discrimination of Screening-Type Corrections in a Box-Trapped Bose Gas"));
c.push(CENTER("A. M. Tishin", { extra: { bold: true } }));
c.push(CENTER("_Faculty of Physics, M. V. Lomonosov Moscow State University, Moscow 119991, Russia_", { size: 22 }));
c.push(CENTER("ORCID: 0000-0003-2252-7279", { size: 22, after: 260 }));

c.push(H1("Abstract"));
c.push(P("Proposals in which macroscopic coherence suppresses an effective coupling as _κ_~eff~ = _κ_~0~(1 − _η_), with _η_ = (_ξ_/_L_)^2^ built from the healing length and a coherence scale, face two obstacles in a harmonically trapped condensate: the Thomas–Fermi identity _ξ_(0)_R_~TF~ = _a_~ho~^2^ locks _η_ to the validity parameter of the hydrodynamic description, and the leading finite-size correction carries the same power of _η_, making the two contributions collinear in every accessible direction of parameter space. We show that both obstacles are properties of harmonic confinement rather than of Bose–Einstein condensation, and that uniform (box) confinement removes them. In a box the healing length is fixed by density and scattering length while the confinement scale is fixed by the walls, giving _η_ = (8_πnaL_^2^)^−1^ in which the diluteness parameter _na_^3^ does not appear; the two are independent, and _η_ = 1.9 × 10^−2^ is reachable at _na_^3^ = 1.5 × 10^−5^, a combination inaccessible to any harmonic trap. We then establish the central result. Expanding the Bogoliubov dispersion for the standing sound modes _k_~_j_~ = _πj_/_L_ of a box condensate gives a quantum-pressure correction (_δω_/_ω_)~QP~ = (_π_^2^/4)_j_^2^_η_, quadratic in the mode index, whereas a screening term of the form above, whose length scale is the system size and not the mode wavelength, contributes a mode-index-independent offset _c_~scr~_η_. A fit of the measured relative shifts to _Aj_^2^ + _B_ therefore separates the two: the slope reproduces the known Gross–Pitaevskii coefficient _π_^2^/4 and provides an internal calibration, while the intercept isolates the hypothesized term. The mode-index scan further discriminates between structurally different mechanisms, since a wavelength-local screening would itself scale as _j_^2^ and be reabsorbed into the slope. At the working point ^87^Rb, _n_ = 10^14^ cm^−3^, _L_ = 5 μm, we find _η_ = 3.0 × 10^−3^, sound speed 1.88 mm s^−1^, a mode ladder at 188, 377, 565, 754 Hz, a quantum-pressure correction rising from 0.74 % to 12 %, and a target intercept of 2.4 × 10^−5^ — a factor 3.6 less demanding than the corresponding harmonic-trap requirement. Two realizations suffice at quality factor 10^3^ and signal-to-noise 30. We give the resource budget, the geometric extension to a two-region cell, and the assumptions that must be discharged."));

c.push(P("*Keywords:* uniform Bose gas; optical box trap; Bogoliubov dispersion; sound modes; quantum pressure; healing length; precision spectroscopy.", { after: 60 }));
c.push(P("*PACS:* 03.75.Kk, 67.85.De, 67.85.Bc, 03.75.Nt"));

c.push(RULE());

/* --------------------------------------------------------------------- I */
c.push(H1("I. Introduction"));
c.push(P("A recurring structural proposal holds that macroscopic quantum coherence suppresses some effective coupling over the healing length, written phenomenologically as"));
c.push(EQ("_κ_~eff~ = _κ_~0~(1 − _η_),   _η_ = _ξ_^2^/_L_^2^,", "(1)"));
c.push(P("with _L_ a macroscopic coherence scale. The natural experimental channel is the collective-mode spectrum, which is the most precisely predicted observable of a dilute Bose gas [1,2,3]."));
c.push(P("In a companion analysis we established two constraints for harmonic confinement. First, the Thomas–Fermi identity _ξ_(0)_R_~TF~ = _a_~ho~^2^ gives _η_ = (15_Na_/_a_~ho~)^−4/5^, so that _η_ and the validity parameter of the hydrodynamic description are the same number and the limit _η_ → 1 lies at _Na_/_a_~ho~ ≈ 0.07, deep in the ideal-gas regime. Second, since _η_ = (_a_~ho~/_R_~TF~)^4^, a screening term linear in _η_ has exactly the scaling of the leading finite-size correction of Gross–Pitaevskii theory [4,5]; the two are collinear in _N_, _a_, _ω_~0~ and species, and differ only in a prefactor."));
c.push(P("Both results are consequences of a specific feature of harmonic confinement: the density profile and the confinement length are determined by the same two parameters, _ω_~0~ and _N_. There is no reason for this coupling to survive in a different geometry, and it does not. The availability of optical box potentials [6,7,8] therefore changes the problem qualitatively rather than incrementally. This paper works out what changes."));
c.push(P("Section III establishes the decoupling identity for a box. Section IV contains the central result: a mode-index signature that lifts the degeneracy which no harmonic-trap measurement can lift. Sections V–VI give the working point and the resource budget; Section VII the geometric extension; Section VIII the assumptions."));

/* -------------------------------------------------------------------- II */
c.push(H1("II. Setup"));
c.push(P("We consider _N_ bosons of mass _m_ and scattering length _a_ > 0 confined in a uniform potential of characteristic linear dimension _L_ with hard walls, at density _n_ = _N_/_V_. The chemical potential is _μ_ = _gn_ with _g_ = 4_πħ_^2^_a_/_m_; the healing length and Bogoliubov sound speed are"));
c.push(EQ("_ξ_ = (8_πna_)^−1/2^,   _c_ = (_gn_/_m_)^1/2^ = (4_πħ_^2^_an_/_m_^2^)^1/2^.", "(2)"));
c.push(P("The Bogoliubov dispersion of the uniform gas is"));
c.push(EQ("(_ħω_)^2^ = _ε_~_k_~(_ε_~_k_~ + 2_gn_),   _ε_~_k_~ = _ħ_^2^_k_^2^/2_m_,", "(3)"));
c.push(P("which in the phonon regime _kξ_ ≪ 1 expands as"));
c.push(EQ("_ω_(_k_) = _ck_ [1 + _k_^2^_ξ_^2^/4 + _O_(_k_^4^_ξ_^4^)].", "(4)"));
c.push(P("For a box with hard-wall (Dirichlet) boundary conditions the allowed standing modes along one axis are _k_~_j_~ = _πj_/_L_, _j_ = 1, 2, 3, …, giving an evenly spaced ladder _f_~_j_~ = _jc_/2_L_ at leading order. It is this ladder, and specifically its deviation from even spacing, that carries the information. Sound propagation in a condensate at the corresponding speed was established experimentally in Ref. [9]; the identities used here are standard [10]."));

/* ------------------------------------------------------------------- III */
c.push(H1("III. Proposition 1: uniform confinement decouples _η_ from diluteness"));
c.push(H2("A. Statement"));
c.push(P("*Proposition 1.* For a uniform Bose gas in a box of linear size _L_,"));
c.push(EQ("_η_ = (_ξ_/_L_)^2^ = (8_πnaL_^2^)^−1^,", "(5)"));
c.push(P("in which the diluteness parameter _na_^3^ does not appear. The pair (_η_, _na_^3^) can be assigned independently by choosing (_n_, _L_) at fixed _a_, or (_n_, _a_) at fixed _L_, the latter through a Feshbach resonance [11]. Q.E.D."));
c.push(P("The contrast with harmonic confinement is not quantitative but structural. There, _η_ = (15_Na_/_a_~ho~)^−4/5^ contains no free length: the confinement scale _R_~TF~ is itself a function of _N_, _a_ and _ω_~0~, so raising _η_ necessarily lowers _Na_/_a_~ho~ and destroys the Thomas–Fermi regime. Here _L_ is an independent experimental parameter set by the projected light pattern, and _n_ is set by loading; the diluteness constraint _na_^3^ ≪ 1 constrains _n_ alone."));

c.push(H2("B. Accessible range"));
c.push(TBL(
  ["_n_ (cm^−3^)", "_L_ (μm)", "_ξ_ (μm)", "_η_", "_na_^3^", "_c_ (mm s^−1^)", "_f_~1~ (Hz)"],
  [
    ["10^12^", "10", "2.740", "7.51 × 10^−2^", "1.5 × 10^−7^", "0.188", "9.4"],
    ["10^13^", "3", "0.866", "8.34 × 10^−2^", "1.5 × 10^−6^", "0.596", "99.3"],
    ["10^13^", "5", "0.866", "3.00 × 10^−2^", "1.5 × 10^−6^", "0.596", "59.6"],
    ["10^14^", "2", "0.274", "1.88 × 10^−2^", "1.5 × 10^−5^", "1.884", "471.0"],
    ["10^14^", "3", "0.274", "8.34 × 10^−3^", "1.5 × 10^−5^", "1.884", "314.0"],
    ["10^14^", "5", "0.274", "3.00 × 10^−3^", "1.5 × 10^−5^", "1.884", "188.4"],
    ["10^14^", "10", "0.274", "7.51 × 10^−4^", "1.5 × 10^−5^", "1.884", "94.2"],
  ],
  [1300, 900, 1000, 1500, 1300, 1300, 1000]));
c.push(CAPTION("*TABLE I.* Accessible working points for ^87^Rb (_a_ = 5.3 nm) in a uniform potential. The last four rows share a fixed diluteness _na_^3^ = 1.5 × 10^−5^ while _η_ varies by a factor 25 — a lever that does not exist in a harmonic trap, where Eq. (6) of the companion analysis fixes _η_ ≈ 8 × 10^−4^ at that diluteness with no remaining freedom."));
c.push(P("Uniform samples of the required quality are now routine [12]. The rows at _η_ ≈ 10^−1^ are listed for completeness but should be treated with caution: at such values the expansion (4) is no longer a small correction for the higher modes (Sec. IV.C), and the phonon description of the low-lying spectrum degrades. The useful window for a controlled measurement is _η_ ∈ [10^−3^, 2 × 10^−2^]."));

/* -------------------------------------------------------------------- IV */
c.push(H1("IV. Proposition 2: the mode index separates the two contributions"));
c.push(H2("A. Statement"));
c.push(P("*Proposition 2.* For the standing modes _k_~_j_~ = _πj_/_L_ of a box condensate, the quantum-pressure correction implied by Eq. (4) is"));
c.push(EQ("(_δω_/_ω_)~QP~ = _k_~_j_~^2^_ξ_^2^/4 = (_π_^2^/4) _j_^2^ _η_ ≈ 2.4674 _j_^2^ _η_,", "(6)"));
c.push(P("quadratic in the mode index, whereas a screening term of the form (1) whose length scale _L_ is the system size — not the mode wavelength — contributes"));
c.push(EQ("(_δω_/_ω_)~scr~ = _c_~scr~ _η_,   independent of _j_.", "(7)"));
c.push(P("Hence the measured relative shifts obey"));
c.push(EQ("(_δω_/_ω_)~_j_~ = _Aj_^2^ + _B_,   _A_ = (_π_^2^/4)_η_,   _B_ = _c_~scr~_η_,", "(8)"));
c.push(P("and a fit over _j_ separates the slope from the intercept. Q.E.D."));

c.push(H2("B. Why this is the escape from the harmonic-trap degeneracy"));
c.push(P("In the harmonic trap both contributions were proportional to _η_ with no further structure, and every experimental lever (_N_, _a_, _ω_~0~, species) multiplied both by the same factor. Here the mode index is a lever that acts on one term and not the other, for a reason that is not accidental: the quantum-pressure correction is local in the excitation wavelength, while a coherence-screening term of the stated form is global in the system size. The two contributions differ in what they are functions of, and the mode ladder resolves precisely that difference."));
c.push(P("Three further properties make Eq. (8) attractive as an experimental design."));
c.push(BULLET("*The slope is a calibration, not a nuisance.* _A_ = (_π_^2^/4)_η_ contains no free parameter: _π_^2^/4 is fixed by Bogoliubov theory and _η_ is known from _n_, _a_ and _L_. Recovering it from the fit validates the density calibration, the box size, and the mode assignment simultaneously. A measurement that fails to reproduce the slope has a systematic problem and should not be interpreted further."));
c.push(BULLET("*The intercept is protected against a large class of systematics.* Any effect that enters through the sound speed — density calibration error, residual box inhomogeneity, atom-number drift — rescales _ω_~_j_~ ∝ _j_ uniformly and cancels in the relative shifts. Effects entering as a uniform relative offset would appear in _B_, and are the systematics that must be controlled; effects entering with _j_-dependence other than _j_^2^ are separable by extending the fit."));
c.push(BULLET("*The fit tests the structure of the mechanism, not only its presence.* If the hypothesized screening were wavelength-local, i.e. _L_ → _k_~_j_~^−1^, then Eq. (7) would itself become ∝ _j_^2^ and would be absorbed into a shifted slope _A_ = (_π_^2^/4 + _c_~scr~′)_η_. Observing a slope that departs from _π_^2^/4 while the intercept vanishes is therefore a distinct and equally informative outcome. The mode-index scan discriminates between two structurally different mechanisms rather than merely bounding one."));

c.push(H2("C. Range of validity of the expansion"));
c.push(P("Equation (6) is the first term of an expansion in _k_~_j_~^2^_ξ_^2^, so its use requires _j_^2^_η_ ≪ 1. At _η_ = 3 × 10^−3^ the correction is 0.74 % at _j_ = 1 and 12 % at _j_ = 4, and the next order in Eq. (3) must be retained beyond _j_ ≈ 4. At _η_ = 8 × 10^−2^ the correction already exceeds unity at _j_ = 2 and the expansion is useless. This is the quantitative reason for restricting the working window to _η_ ≲ 2 × 10^−2^, and it should be understood as the box-geometry analogue of the Thomas–Fermi validity bound of the harmonic case: the same physics reappears, but as a bound on _j_^2^_η_ rather than on _η_ alone, which is a far weaker restriction because _j_ is under experimental control."));

/* --------------------------------------------------------------------- V */
c.push(H1("V. Working point"));
c.push(P("We adopt ^87^Rb at _n_ = 10^14^ cm^−3^ in a box of _L_ = 5 μm. Equations (2) and (5) give _ξ_ = 0.274 μm, _η_ = 3.00 × 10^−3^, _na_^3^ = 1.49 × 10^−5^, _c_ = 1.884 mm s^−1^, _μ_/_h_ = 774 Hz and _μ_/_k_~B~ = 37.1 nK. Table II gives the mode ladder and the two contributions, with the screening prefactor set to _c_~scr~ = 8 × 10^−3^, the value implied by the millihertz-scale shifts quoted in the proposals; the hydrodynamic relations used are standard [13]."));
c.push(TBL(
  ["_j_", "_f_~_j_~ (Hz)", "(_δω_/_ω_)~QP~", "QP shift (Hz)", "(_δω_/_ω_)~scr~", "Screening shift (mHz)"],
  [
    ["1", "188.39", "7.41 × 10^−3^", "1.396", "2.40 × 10^−5^", "4.53"],
    ["2", "376.77", "2.96 × 10^−2^", "11.17", "2.40 × 10^−5^", "9.05"],
    ["3", "565.16", "6.67 × 10^−2^", "37.69", "2.40 × 10^−5^", "13.58"],
    ["4", "753.55", "1.19 × 10^−1^", "89.33", "2.40 × 10^−5^", "18.10"],
    ["5", "941.93", "1.85 × 10^−1^", "174.5", "2.40 × 10^−5^", "22.63"],
  ],
  [700, 1500, 1900, 1700, 1900, 2200]));
c.push(CAPTION("*TABLE II.* Mode ladder at the working point ^87^Rb, _n_ = 10^14^ cm^−3^, _L_ = 5 μm, _η_ = 3.00 × 10^−3^. The quantum-pressure column grows as _j_^2^ and is the calibration; the screening column is constant in relative terms and grows only through _f_~_j_~ in absolute terms. Rows _j_ ≥ 5 require the next order of Eq. (3) and are shown for orientation."));
c.push(P("The quantity to be measured is the intercept _B_ = 2.40 × 10^−5^. This is a factor 3.6 larger than the corresponding harmonic-trap requirement of 6.7 × 10^−6^, so the box geometry is not only structurally better conditioned but also quantitatively less demanding."));

/* -------------------------------------------------------------------- VI */
c.push(H1("VI. Resource budget"));
c.push(P("The frequency resolution per realization is governed by the effective quality factor _Q_~eff~ = _ω_/_Γ_ of the mode, with _Γ_ the damping rate. In a uniform gas at low temperature the relevant mechanisms are Beliaev and Landau damping [14]; measured collective-mode quality factors in trapped and uniform samples fall in the range 10^2^–10^3^, with the upper end attained deep in the condensed regime [15]. Sound and second-sound spectroscopy in uniform Bose and Fermi samples [8,16] provides the closest methodological precedent. Table III gives the required number of realizations."));
c.push(TBL(
  ["_Q_~eff~", "_S_ = 10", "_S_ = 30", "Wall-clock at 30 s per shot"],
  [
    ["10^2^", "1.7 × 10^3^ shots", "193 shots", "14.4 h / 1.6 h"],
    ["10^3^", "17 shots", "2 shots", "8.7 min / 1 min"],
    ["10^4^", "< 1 shot", "< 1 shot", "single realization"],
  ],
  [1400, 2400, 2400, 2800]));
c.push(CAPTION("*TABLE III.* Realizations required to resolve the intercept _B_ = 2.4 × 10^−5^ at the working point, as a function of the effective quality factor and per-shot signal-to-noise ratio _S_, from _δω_/_ω_ ≈ (_Q_~eff~ _S_ _N_~sh~^1/2^)^−1^."));
c.push(P("Counting statistics are therefore comfortable across the plausible range. As in the harmonic case, the binding constraints are systematic. The specific list for the box geometry is shorter than for the harmonic trap, which is the practical payoff of the intercept construction."));
c.push(BULLET("*Box flatness.* Residual curvature of the potential shifts the mode ladder away from even spacing and can masquerade as a _j_-dependent term. This is the dominant systematic and must be characterized independently, for instance by measuring the ladder at two densities where _η_ differs but the residual potential does not."));
c.push(BULLET("*Density calibration.* Enters _η_ directly and hence both _A_ and _B_, so the ratio _B_/_A_ = 4_c_~scr~/_π_^2^ is free of it and is the appropriate quantity to report at fixed density. It is not free of contributions that act on the sound speed rather than on _η_; those are treated in Sec. IX."));
c.push(BULLET("*Thermal fraction.* Shifts and damps the modes. Unlike the harmonic case, the correction is expected to be _j_-dependent, and its functional form is available from finite-temperature Bogoliubov theory; it should be included in the fit rather than treated as a common mode, along the lines of Ref. [17]."));
c.push(BULLET("*Mode assignment.* Misassignment of _j_ is catastrophic for a _j_^2^ fit. Assignment should be verified by direct imaging of the density modulation, not inferred from frequency alone."));

/* ------------------------------------------------------------------- VII */
c.push(H1("VII. Geometric extension: the two-region cell"));
c.push(P("Proposition 1 makes _η_ a function of position once _n_ or the local confinement is made position dependent. This opens a construction that has no harmonic-trap analogue: a cell partitioned into two regions with different _η_, sharing a common boundary."));
c.push(P("The simplest version is a box of length _L_ divided into a region of density _n_~1~ and a region of density _n_~2~, maintained by a projected potential step. The sound speeds differ, _c_~_i_~ = (_gn_~_i_~/_m_)^1/2^, and the boundary partially reflects sound with an amplitude reflection coefficient _r_ = (_c_~2~ − _c_~1~)/(_c_~2~ + _c_~1~) at normal incidence in the long-wavelength limit. A region bounded by two such steps is a resonator for the phonon field, and the discrete ladder of Sec. II is its mode spectrum."));
c.push(P("We emphasize what this does and does not provide. It does not create a new excitation, and it does not amplify a screening term: the resonator confines the ordinary Bogoliubov phonon, whose properties are standard. What it provides is a longer coherent observation window, hence a larger _Q_~eff~, hence a smaller _δω_/_ω_ per realization at fixed shot count — the entry in Table III shifts by the factor by which _Q_~eff~ increases. This is the honest content of the resonator idea, and it is a real gain: the difference between _Q_~eff~ = 10^2^ and _Q_~eff~ = 10^3^ is the difference between fourteen hours and nine minutes of integration."));
c.push(P("A second use of the two-region cell is differential. If _η_~1~ ≠ _η_~2~ while temperature, atom source and optical calibration are shared, the difference of intercepts _B_~1~ − _B_~2~ = _c_~scr~(_η_~1~ − _η_~2~) removes any offset common to the two regions. We regard this as the natural second-generation experiment, to be attempted only after the single-region fit of Eq. (8) has demonstrated that the slope is recovered at the expected value."));

/* ------------------------------------------------------------------ VIII */
c.push(H1("VIII. Assumptions and limitations"));
c.push(H2("A. On the form of the screening term"));
c.push(P("Proposition 2 assumes that _L_ in Eq. (1) is the system size. This is the reading under which Eq. (1) has its stated motivation — suppression over the region of macroscopic coherence — but it is an assumption, and Sec. IV.B.3 explains how the measurement itself tests it. If instead the mechanism is local in the excitation wavelength, the signature moves from the intercept to the slope. If it is neither, the _j_-dependence will be some third function and the fit of Eq. (8) will show structured residuals; that too is informative."));

c.push(H2("B. On the boundary conditions"));
c.push(P("We have used Dirichlet conditions, giving _k_~_j_~ = _πj_/_L_. Real optical boxes have walls of finite steepness, and the effective _L_ acquires a weak density dependence through the penetration of the condensate into the wall. This shifts the ladder and must be calibrated; it is the leading contribution to the box-flatness systematic of Sec. VI."));

c.push(H2("C. The price of uniform confinement: no Kohn mode"));
c.push(P("Uniform confinement removes the two obstacles of the harmonic trap, but it removes something else as well, and the loss should be stated as plainly as the gain. In a harmonic trap the centre-of-mass coordinate decouples exactly from the internal dynamics, so the dipole mode oscillates at precisely the trap frequency independently of atom number, interaction and temperature. This is Kohn's theorem [18,19], and it makes the dipole mode a frequency reference protected by a theorem rather than by an instrument: the ratio _ω_~B~/_ω_~D~ measured on the same atoms in the same realization is immune to any error or drift in the confinement, to all orders."));
c.push(P("A box has no such mode. The centre-of-mass coordinate of a gas in a flat-bottomed potential with hard walls does not execute a harmonic oscillation at all, and there is consequently no protected frequency standard internal to the sample. Frequency calibration in the box geometry must come from the clock, from the projected light pattern, and from the measured density — none of which is protected by a conservation law."));
c.push(P("The two remedies are therefore mutually exclusive at the level of the apparatus, and Table IV records the position."));
c.push(TBL(
  ["Geometry", "Kohn frequency reference", "Degeneracy with finite-size term", "Internal calibration used"],
  [
    ["Harmonic trap", "yes, exact", "present, unliftable", "the Kohn mode itself"],
    ["Uniform box", "absent", "lifted by the mode index", "the mode-index slope _A_"],
  ],
  [2100, 2500, 2600, 2400]));
c.push(CAPTION("*TABLE IV.* Complementarity of the two geometries. Neither supplies both properties; each provides a different internal calibration in place of the one it lacks."));
c.push(P("What makes the box geometry nevertheless viable is that Proposition 2 supplies its own replacement. The slope _A_ = (_π_^2^/4)_η_ is fixed by Bogoliubov theory with no adjustable parameter, so recovering it from the fit validates the frequency scale, the density calibration, the box size and the mode assignment simultaneously — which is exactly the function the Kohn mode performs in the harmonic trap, discharged by a different mechanism. Reporting the ratio _B_/_A_ rather than _B_ makes the substitution explicit for calibrations that enter through _η_. It does not remove contributions that shift the sound speed itself; those are treated in Sec. IX."));
c.push(P("We therefore regard the two experiments as complementary rather than competing. A null result in one does not subsume a null result in the other, and the systematics that limit them are disjoint: trap anharmonicity in the harmonic case, box flatness and mode assignment here."));

c.push(H2("D. What is not claimed"));
c.push(P("We do not claim that a screening term of the form (1) exists. We claim that if it exists with the stated structure, a box geometry admits a measurement that a harmonic trap does not, and we specify that measurement together with its calibration and its failure modes. A null result — slope recovered at _π_^2^/4, intercept consistent with zero at 10^−5^ — bounds _c_~scr~ below 3 × 10^−3^ and is a publishable constraint independent of any view on the underlying proposal."));

c.push(H2("E. Open items"));
c.push(BULLET("The fourth-order term of the Bogoliubov expansion must be carried from _j_ = 1 onward, not only for high modes. As shown in Appendix A, at the working point it already exceeds the target intercept at _j_ = 1 and does so by a factor 290 at _j_ = 4; fitting _Aj_^2^ + _B_ to data spanning _j_ = 1 to 4 would bias the intercept by orders of magnitude more than the effect sought. The coefficient is fixed by theory and adds no free parameter, but the fit must be constrained accordingly."));
c.push(BULLET("The finite-temperature _j_-dependence of the mode frequencies in a uniform gas should be computed at the accuracy of the intercept, 10^−5^, before the measurement is attempted. This is a self-contained calculation."));
c.push(BULLET("The Lee–Huang–Yang correction to the equation of state [20,21] shifts the sound speed and therefore contaminates the intercept. This is not a minor item and is treated separately in Sec. IX; the density scan described there is part of the protocol, not an optional refinement."));

/* -------------------------------------------------------------------- IX */
c.push(H1("IX. The intercept is not clean: the Lee–Huang–Yang term and the density scan"));
c.push(P("Proposition 2 separates the quantum-pressure correction from everything independent of the mode index. It does not separate the terms inside that second group, and one of them is large. The Lee–Huang–Yang correction modifies the equation of state, _μ_ = _gn_[1 + (32/3_π_^1/2^)(_na_^3^)^1/2^ + …], and hence the sound speed through _c_^2^ = (_n_/_m_)∂_μ_/∂_n_ [20,21]. A change in _c_ rescales every mode by the same relative amount, since _ω_~_j_~ = _ck_~_j_~ with _k_~_j_~ fixed by the box geometry. The Lee–Huang–Yang term is therefore mode-index-independent and lands in the intercept _B_, alongside the quantity to be extracted. Reporting _B_/_A_ does not remove it, because _A_ is unaffected."));
c.push(P("The contamination is not small. Table V compares the two contributions at fixed _L_ = 5 μm."));
c.push(TBL(
  ["_n_ (cm^−3^)", "_η_", "(_na_^3^)^1/2^", "_c_~scr~_η_ at _c_~scr~ = 8 × 10^−3^", "LHY / screening"],
  [
    ["3 × 10^13^", "1.00 × 10^−2^", "2.11 × 10^−3^", "8.01 × 10^−5^", "26"],
    ["10^14^", "3.00 × 10^−3^", "3.86 × 10^−3^", "2.40 × 10^−5^", "161"],
    ["3 × 10^14^", "1.00 × 10^−3^", "6.68 × 10^−3^", "8.01 × 10^−6^", "835"],
    ["10^15^", "3.00 × 10^−4^", "1.22 × 10^−2^", "2.40 × 10^−6^", "5079"],
  ],
  [1500, 1700, 1700, 2500, 1600]));
c.push(CAPTION("*TABLE V.* Lee–Huang–Yang contribution against the screening contribution to the intercept _B_, at fixed box size _L_ = 5 μm, with the Lee–Huang–Yang term taken with a prefactor of order unity. At the working point of Sec. V the contamination exceeds the sought effect by more than two orders of magnitude."));
c.push(P("The remedy is a second knob, and it works because the density scalings differ. The screening parameter falls as _η_ = (8_πnaL_^2^)^−1^ ∝ _n_^−1^, while the Lee–Huang–Yang term rises as (_na_^3^)^1/2^ ∝ _n_^+1/2^. The exponents differ by 3/2, so a density scan at fixed box size separates them without ambiguity: over a factor 33 in density the screening term falls by 33 while the Lee–Huang–Yang term rises by 5.8, giving a relative lever arm of 190. The full fit function is"));
c.push(EQ("(_δω_/_ω_)~_j_~ = (_π_^2^/4)_j_^2^_η_ − (_π_^4^/32)_j_^4^_η_^2^ + _c_~LHY~(_na_^3^)^1/2^ + _c_~scr~_η_,", "(9)"));
c.push(P("in which the first two coefficients are fixed by Bogoliubov theory and the third by Lee–Huang–Yang, leaving _c_~scr~ as the only free parameter once the ladder has been measured at several _j_ and several _n_. The two scans are orthogonal: the mode index resolves what is local in the excitation wavelength, the density resolves what is local in the interparticle spacing."));
c.push(P("Two consequences. The experiment is harder than Sec. VI alone suggested, because the intercept must be resolved at densities low enough for the screening term to emerge above the Lee–Huang–Yang background, which pushes toward _n_ ≈ 3 × 10^13^ cm^−3^ and hence toward longer integration. It is also worth more: a measurement resolving the intercept across a factor 33 in density determines the Lee–Huang–Yang coefficient of a uniform Bose gas from its collective spectrum, a quantity of independent interest that has not been obtained this way. As elsewhere in this paper, the deliverable that does not depend on the screening proposal is the one that justifies the apparatus time."));
c.push(H1("X. Conclusion"));
c.push(P("We have shown that the two obstacles which block a harmonic-trap test of screening-type corrections of the form _κ_~eff~ = _κ_~0~(1 − _η_) are artefacts of harmonic confinement, and that uniform confinement removes both."));
c.push(P("The first obstacle was that _η_ and the Thomas–Fermi validity parameter are the same quantity, so that raising the screening parameter destroys the description that predicts its effect. In a box, _η_ = (8_πnaL_^2^)^−1^ contains no reference to the diluteness parameter _na_^3^; density and box size are independent experimental variables, and _η_ = 1.9 × 10^−2^ is available at _na_^3^ = 1.5 × 10^−5^ — a combination that no harmonic trap of any species, frequency or scattering length can produce."));
c.push(P("The second obstacle was an exact degeneracy in scaling between the hypothesized term and the leading correction of Gross–Pitaevskii theory. In a box the degeneracy is lifted by the mode index. The quantum-pressure correction to the standing sound modes is (_π_^2^/4)_j_^2^_η_, quadratic in _j_ because it is local in the excitation wavelength; a screening term whose scale is the system size is independent of _j_. Fitting the measured relative shifts to _Aj_^2^ + _B_ therefore delivers, in a single dataset, an internal calibration in the slope and the hypothesized effect in the intercept. We regard this separation as the central result of the paper, and we note that it converts the problem from a measurement of an absolute coefficient — which is what the harmonic trap forces, and which is not defensible at the required accuracy — into the measurement of a functional form, which is."));
c.push(P("At the working point ^87^Rb, _n_ = 10^14^ cm^−3^, _L_ = 5 μm, the target intercept is 2.4 × 10^−5^, a factor 3.6 less demanding than the harmonic-trap requirement, and two realizations suffice at _Q_~eff~ = 10^3^ and signal-to-noise 30. The binding constraints are box flatness, mode assignment, and the Lee–Huang–Yang contamination of the intercept treated in Sec. IX, rather than counting statistics."));
c.push(P("We have also identified a contamination that the mode-index separation does not address. The Lee–Huang–Yang correction acts on the sound speed and therefore shifts every mode by the same relative amount, so it enters the intercept alongside the term being sought and exceeds it by two orders of magnitude at the working point. Separation is recovered by a second knob: the screening term scales as _n_^−1^ and the Lee–Huang–Yang term as _n_^+1/2^, so a density scan at fixed box size resolves them with a lever arm of 190 over a factor 33 in density. The measurement therefore requires two scans rather than one — in mode index and in density — and returns the Lee–Huang–Yang coefficient as a by-product."));
c.push(P("We have also stated the price. Uniform confinement has no Kohn mode, and therefore no frequency reference protected by a theorem, whereas the harmonic trap possesses one exactly and forfeits the mode-index lever. The two remedies are mutually exclusive at the level of the apparatus, and the correct reading is that the two experiments are complementary: each supplies a different internal calibration in place of the one it lacks, and their limiting systematics — trap anharmonicity on one side, box flatness and mode assignment on the other — are disjoint. In the box the calibration is the slope itself, which is why we recommend reporting _B_/_A_ rather than _B_."));
c.push(P("Beyond the specific proposal that motivated it, the measurement described here would determine the quantum-pressure coefficient of the sound-mode ladder of a uniform Bose gas against the Bogoliubov prediction at the 10^−5^ level. That coefficient is not adjustable, has been available since 1947, and has never been tested at this accuracy. As in the harmonic case, we consider that this second deliverable — which is independent of whether any screening term exists — is what makes the experiment worth proposing to a group with an optical box apparatus."));

c.push(H1("Acknowledgments"));
c.push(P("The author thanks colleagues at the Faculty of Physics, M. V. Lomonosov Moscow State University for discussions."));

c.push(H1("Competing interests"));
c.push(P("The author declares no competing interests."));

c.push(H1("Data availability"));
c.push(P("Tables I–V are produced by direct evaluation of Eqs. (2), (5), (6) and (8); the evaluation script will be deposited in a public repository on publication. No experimental data were produced or analysed."));

c.push(H1("References"));
const refs = [
  "N. N. Bogoliubov, On the theory of superfluidity, J. Phys. (USSR) *11*, 23 (1947).",
  "S. Stringari, Collective excitations of a trapped Bose-condensed gas, Phys. Rev. Lett. *77*, 2360 (1996). DOI: 10.1103/PhysRevLett.77.2360",
  "F. Dalfovo, S. Giorgini, L. P. Pitaevskii and S. Stringari, Theory of Bose-Einstein condensation in trapped gases, Rev. Mod. Phys. *71*, 463 (1999). DOI: 10.1103/RevModPhys.71.463",
  "E. Braaten and J. Pearson, Semiclassical corrections to the oscillation frequencies of a trapped Bose-Einstein condensate, Phys. Rev. Lett. *82*, 255 (1999). DOI: 10.1103/PhysRevLett.82.255",
  "F. Dalfovo, C. Minniti, S. Stringari and L. Pitaevskii, Nonlinear dynamics of a Bose condensed gas, Phys. Lett. A *227*, 259 (1997). DOI: 10.1016/S0375-9601(97)00069-8",
  "A. L. Gaunt, T. F. Schmidutz, I. Gotlibovych, R. P. Smith and Z. Hadzibabic, Bose-Einstein condensation of atoms in a uniform potential, Phys. Rev. Lett. *110*, 200406 (2013). DOI: 10.1103/PhysRevLett.110.200406",
  "N. Navon, R. P. Smith and Z. Hadzibabic, Quantum gases in optical boxes, Nat. Phys. *17*, 1334 (2021). DOI: 10.1038/s41567-021-01403-z",
  "T. A. Hilker, L. H. Dogra, C. Eigen, J. A. P. Glidden, R. P. Smith and Z. Hadzibabic, First and second sound in a compressible 3D Bose fluid, Phys. Rev. Lett. *128*, 223601 (2022). DOI: 10.1103/PhysRevLett.128.223601",
  "M. R. Andrews, D. M. Kurn, H.-J. Miesner, D. S. Durfee, C. G. Townsend, S. Inouye and W. Ketterle, Propagation of sound in a Bose-Einstein condensate, Phys. Rev. Lett. *79*, 553 (1997). DOI: 10.1103/PhysRevLett.79.553",
  "C. J. Pethick and H. Smith, _Bose-Einstein Condensation in Dilute Gases_, 2nd ed. (Cambridge University Press, Cambridge, 2008).",
  "C. Chin, R. Grimm, P. Julienne and E. Tiesinga, Feshbach resonances in ultracold gases, Rev. Mod. Phys. *82*, 1225 (2010). DOI: 10.1103/RevModPhys.82.1225",
  "N. Navon, A. L. Gaunt, R. P. Smith and Z. Hadzibabic, Critical dynamics of spontaneous symmetry breaking in a homogeneous Bose gas, Science *347*, 167 (2015). DOI: 10.1126/science.1258676",
  "L. P. Pitaevskii and S. Stringari, _Bose-Einstein Condensation and Superfluidity_ (Oxford University Press, Oxford, 2016).",
  "P. O. Fedichev, G. V. Shlyapnikov and J. T. M. Walraven, Damping of low-energy excitations of a trapped Bose-Einstein condensate at finite temperatures, Phys. Rev. Lett. *80*, 2269 (1998). DOI: 10.1103/PhysRevLett.80.2269",
  "D. M. Stamper-Kurn, H.-J. Miesner, S. Inouye, M. R. Andrews and W. Ketterle, Collisionless and hydrodynamic excitations of a Bose-Einstein condensate, Phys. Rev. Lett. *81*, 500 (1998). DOI: 10.1103/PhysRevLett.81.500",
  "B. Mukherjee, Z. Yan, P. B. Patel, Z. Hadzibabic, T. Yefsah, J. Struck and M. W. Zwierlein, Homogeneous atomic Fermi gases, Phys. Rev. Lett. *118*, 123401 (2017). DOI: 10.1103/PhysRevLett.118.123401",
  "C. Menotti and S. Stringari, Collective oscillations of a one-dimensional trapped Bose-Einstein gas, Phys. Rev. A *66*, 043610 (2002). DOI: 10.1103/PhysRevA.66.043610",
  "W. Kohn, Cyclotron resonance and de Haas-van Alphen oscillations of an interacting electron gas, Phys. Rev. *123*, 1242 (1961). DOI: 10.1103/PhysRev.123.1242",
  "J. F. Dobson, Harmonic-potential theorem: implications for approximate many-body theories, Phys. Rev. Lett. *73*, 2244 (1994). DOI: 10.1103/PhysRevLett.73.2244",
  "T. D. Lee, K. Huang and C. N. Yang, Eigenvalues and eigenfunctions of a Bose system of hard spheres and its low-temperature properties, Phys. Rev. *106*, 1135 (1957). DOI: 10.1103/PhysRev.106.1135",
  "L. Pitaevskii and S. Stringari, Elementary excitations in trapped Bose-Einstein condensed gases beyond the mean-field approximation, Phys. Rev. Lett. *81*, 4541 (1998). DOI: 10.1103/PhysRevLett.81.4541",
];
refs.forEach((r, i) => c.push(REF(i + 1, r)));

c.push(H1("Appendix A: expansion of the Bogoliubov dispersion"));
c.push(P("From Eq. (3), (_ħω_)^2^ = _ε_~_k_~^2^ + 2_gnε_~_k_~. Writing _ħω_ = (2_gnε_~_k_~)^1/2^(1 + _ε_~_k_~/2_gn_)^1/2^ and using (2_gnε_~_k_~)^1/2^ = _ħck_ gives _ω_ = _ck_(1 + _ε_~_k_~/2_gn_)^1/2^. Expanding the square root, _ω_ = _ck_[1 + _ε_~_k_~/(4_gn_) + …]. With _ε_~_k_~ = _ħ_^2^_k_^2^/2_m_ and _ξ_^2^ = _ħ_^2^/(2_mgn_) one has _ε_~_k_~/(4_gn_) = _ħ_^2^_k_^2^/(8_mgn_) = _k_^2^_ξ_^2^/4, which is Eq. (4). Substituting _k_~_j_~ = _πj_/_L_ and _η_ = (_ξ_/_L_)^2^ gives Eq. (6)."));
c.push(P("The next order follows from the same expansion: _ω_ = _ck_[1 + _k_^2^_ξ_^2^/4 − _k_^4^_ξ_^4^/32 + …], so the fit function extended to fourth order is"));
c.push(EQ("(_δω_/_ω_)~_j_~ = (_π_^2^/4)_j_^2^_η_ − (_π_^4^/32)_j_^4^_η_^2^ + _B_.", "(A1)"));
c.push(P("We draw attention to the magnitude of the quartic term, which is easy to dismiss and must not be. At the working point _η_ = 3.00 × 10^−3^ it is only 3.7 × 10^−3^ of the quadratic term at _j_ = 1, but in absolute terms it equals 2.74 × 10^−5^, which is 1.14 times the target intercept _B_ = 2.40 × 10^−5^. At _j_ = 2 it reaches 4.39 × 10^−4^, eighteen times the intercept, and at _j_ = 4 it is 7.03 × 10^−3^, some 290 times the intercept. Table A1 records these values."));
c.push(TBL(
  ["_j_", "Quadratic term", "Quartic term", "Quartic / quadratic", "Quartic / _B_"],
  [
    ["1", "7.41 × 10^−3^", "2.74 × 10^−5^", "3.7 × 10^−3^", "1.14"],
    ["2", "2.96 × 10^−2^", "4.39 × 10^−4^", "1.5 × 10^−2^", "18.3"],
    ["3", "6.67 × 10^−2^", "2.22 × 10^−3^", "3.3 × 10^−2^", "92.6"],
    ["4", "1.19 × 10^−1^", "7.03 × 10^−3^", "5.9 × 10^−2^", "292.5"],
  ],
  [800, 2100, 2100, 2100, 1700]));
c.push(CAPTION("*TABLE A1.* Second- and fourth-order terms of Eq. (A1) at the working point _η_ = 3.00 × 10^−3^, compared with the target intercept _B_ = 2.40 × 10^−5^. The quartic term exceeds the intercept at every mode index, including _j_ = 1."));
c.push(P("The consequence for the design is unambiguous: the quartic term must be carried from _j_ = 1 onward, not introduced for high modes as an afterthought. A two-parameter fit of the form _Aj_^2^ + _B_ applied to data spanning _j_ = 1 to 4 would absorb the unmodelled _j_^4^ dependence partly into the slope and partly into the intercept, and the induced bias in _B_ would exceed the effect being sought by more than two orders of magnitude. This does not weaken Proposition 2 — the quartic coefficient is fixed by Bogoliubov theory and by the independently known _η_, so it introduces no additional free parameter — but it converts the analysis from a linear regression in _j_^2^ into a constrained one-parameter fit in which only _B_ is free. We record this explicitly because it is the kind of omission that is invisible in the scaling argument and fatal in the data analysis."));

const doc = buildDoc("Tishin — Uniform confinement and mode-index discrimination", c);
Packer.toBuffer(doc).then(b => {
  fs.writeFileSync('./out/Paper2_Box_Geometry_Mode_Index.docx', b);
  console.log('paper 2 written');
});
