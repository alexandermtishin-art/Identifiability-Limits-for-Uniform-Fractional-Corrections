const fs = require('fs');
const { Packer, P, H1, H2, TITLE, CENTER, EQ, BULLET, TBL, CAPTION, RULE, REF, buildDoc } = require('./common');

const c = [];

c.push(TITLE("Necessary Conditions for Passive Error Exclusion by a Geometric Suppression Mechanism: A No-Go Result for Perturbative Screening"));
c.push(CENTER("A. M. Tishin", { extra: { bold: true } }));
c.push(CENTER("_Faculty of Physics, M. V. Lomonosov Moscow State University, Moscow 119991, Russia_", { size: 22 }));
c.push(CENTER("ORCID: 0000-0003-2252-7279", { size: 22, after: 260 }));

c.push(H1("Abstract"));
c.push(P("Bosonic cat qubits realize a paradigm distinct from error correction: an entire error class is rendered dynamically inaccessible rather than detected and repaired, with bit-flip rates suppressed exponentially in the mean photon number. This has motivated proposals that a geometric or coherence-based suppression mechanism might implement the same paradigm through a different physical route. We formalize the requirement and show that a large and natural class of such mechanisms cannot meet it. Defining a suppression mechanism as a map from a control parameter to a rate ratio _R_ = _Γ_~0~/_Γ_, we prove that any mechanism of perturbative form _R_ = (1 − _η_)^−1^ with a domain-of-validity bound _η_ ≤ _η_~max~ < 1 satisfies _R_ ≤ (1 − _η_~max~)^−1^, a bound that is finite and, for the physically defensible ceiling _η_~max~ = 10^−2^, equal to 1.0101. The benchmark set by a cat qubit at mean photon number 8 is _R_ ≈ 8.9 × 10^6^; matching it in a single cell would require _η_~max~ = 1 − 1.1 × 10^−7^, and matching it by concatenating independent cells would require 1592 of them at _η_~max~ = 10^−2^. The obstruction is not the size of the suppression but its analytic structure: a bounded control parameter entering polynomially can only produce a bounded ratio, whereas competitive protection requires a ratio that diverges within the physical range. We then state four necessary conditions — non-analyticity in the control parameter, a discrete sector label protected by a gap, preservation of the protection under the operating gate set, and dominance of the suppressed channel in the total error budget — and quantify each. The gap condition requires 6.7 GHz at 20 mK for a rate ratio of 10^7^; the dominance condition bounds the achievable end-to-end improvement by (1 − _p_)^−1^ where _p_ is the suppressed fraction of the error budget, so that suppressing 90 % of errors perfectly yields at most a factor of ten. We conclude that the error-exclusion application of coherence-screening proposals is not merely unproven but structurally excluded in the perturbative regime, and that any viable version must first establish a topological or otherwise non-analytic mechanism — a distinct existence question that we identify as logically prior."));

c.push(P("*Keywords:* quantum error correction; error exclusion; bosonic codes; cat qubits; biased noise; no-go theorem; passive protection.", { after: 60 }));
c.push(P("*PACS:* 03.67.Pp, 03.67.Lx, 42.50.Pq, 85.25.-j"));

c.push(RULE());

/* --------------------------------------------------------------------- I */
c.push(H1("I. Introduction"));
c.push(P("The dominant architecture for fault-tolerant quantum computation detects errors and repairs them. An alternative, realized in bosonic cat qubits, does not: the encoded manifold is stabilized so that an entire class of errors becomes dynamically inaccessible, and the corresponding rate is suppressed exponentially in the mean photon number |_α_|^2^ [1–3]. Experimental bit-flip times have advanced from microseconds to a hundred seconds [4], to 0.3 s under active control [5], and beyond ten seconds with a full gate set preserved [6]; the paradigm has moved from proposal to engineering, and concatenated architectures built on it are now demonstrated [7]."));
c.push(P("This success has attracted proposals of a different physical origin. Several frameworks postulate that macroscopic coherence suppresses an effective coupling in the form"));
c.push(EQ("_κ_~eff~ = _κ_~0~(1 − _η_),   0 ≤ _η_ < 1,", "(1)"));
c.push(P("with _η_ built from a ratio of length scales, and it has been suggested that such a mechanism might furnish passive protection of a computational subspace: transitions into leakage or error sectors would be suppressed by the geometry of accessible states rather than corrected after the fact. The appeal is clear. If the mechanism existed, it would not need to build an industry around itself; the architecture, the threshold theory, the biased-noise gate sets and the fabrication base already exist and were paid for by others."));
c.push(P("This paper asks whether the appeal survives quantification. We do not evaluate any microscopic derivation of Eq. (1); we ask what a mechanism of that form could deliver even if it were correct in every detail. The answer is sharp and negative, and the reason is structural rather than numerical: a bounded control parameter entering an expression polynomially yields a bounded suppression, while the paradigm requires an unbounded one. Section III proves this. Section IV converts the failure into four necessary conditions that any candidate mechanism must satisfy, each stated with a number attached. Section V discusses which mechanism classes remain admissible and identifies the existence question that is logically prior to any architectural discussion."));
c.push(P("We regard the result as constructive rather than dismissive. A no-go theorem that identifies the exact property whose absence causes the failure is a specification for what to look for next, and we state it in that form."));

/* -------------------------------------------------------------------- II */
c.push(H1("II. Formalization"));
c.push(H2("A. Suppression mechanisms"));
c.push(P("*Definition 1.* A _suppression mechanism_ is a pair (_λ_, _R_) consisting of a control parameter _λ_ ranging over a physically admissible interval _Λ_ = [0, _λ_~max~] and a _rate ratio_"));
c.push(EQ("_R_(_λ_) = _Γ_~0~ / _Γ_(_λ_) ≥ 1,", "(2)"));
c.push(P("where _Γ_(_λ_) is the rate of the error channel to be excluded and _Γ_~0~ = _Γ_(0) is its unsuppressed value. The mechanism is _competitive_ at level _R_~*~ if the supremum of _R_(_λ_) over _λ_ ∈ _Λ_ is at least _R_~*~."));
c.push(P("The restriction of _λ_ to a bounded interval is not a technical convenience. Every physical mechanism has a domain outside which the derivation that produced it fails, and the bound _λ_~max~ is that domain. In the case of Eq. (1) applied to a trapped Bose–Einstein condensate the bound is severe and can be computed exactly: the Thomas–Fermi identity forces _η_ = (15_Na_/_a_~ho~)^−4/5^, so that _η_ and the validity parameter of the hydrodynamic description are the same quantity, and the largest internally consistent value is _η_~max~ ≈ 10^−2^. We take this as the reference figure and treat _η_~max~ as a free parameter throughout, so that the argument does not depend on it."));

c.push(H2("B. The two classes"));
c.push(P("*Definition 2.* A mechanism is of _perturbative class_ if _R_(_λ_) is analytic on _Λ_ and bounded there. It is of _non-analytic class_ if _R_(_λ_) → ∞ as _λ_ → _λ_~*~ for some _λ_~*~ ∈ _Λ_, or if _R_ grows exponentially in a parameter that is itself unbounded within _Λ_."));
c.push(P("The cat qubit is of non-analytic class in the second sense: _R_ ≈ exp(2|_α_|^2^) with |_α_|^2^ limited by engineering considerations rather than by a domain-of-validity bound, so that the accessible range of ln _R_ is large. A screening mechanism of the form (1) is of perturbative class by construction."));

/* ------------------------------------------------------------------- III */
c.push(H1("III. The no-go result"));
c.push(H2("A. Statement and proof"));
c.push(P("*Theorem 1.* Let a mechanism act by replacing a coupling _κ_~0~ with _κ_~eff~ = _κ_~0~(1 − _η_) and let the error rate be linear in the coupling, _Γ_ ∝ _κ_~eff~. Then"));
c.push(EQ("_R_(_η_) = (1 − _η_)^−1^ ≤ (1 − _η_~max~)^−1^,", "(3)"));
c.push(P("for all admissible _η_ ≤ _η_~max~ < 1. The bound is attained only at the boundary of the domain of validity. Q.E.D."));
c.push(P("The proof is immediate; the content is in the interpretation. Table I evaluates Eq. (3) against the cat-qubit benchmark."));
c.push(TBL(
  ["_η_~max~", "_R_~max~ = (1 − _η_~max~)^−1^", "ln _R_~max~", "Cells to reach ln _R_ = 16"],
  [
    ["10^−3^", "1.00100", "1.00 × 10^−3^", "15 992"],
    ["10^−2^", "1.01010", "1.01 × 10^−2^", "1 592"],
    ["10^−1^", "1.11111", "1.05 × 10^−1^", "152"],
    ["0.5", "2.00000", "0.693", "23"],
    ["0.9", "10.0000", "2.303", "7"],
  ],
  [1600, 2600, 1900, 2600]));
c.push(CAPTION("*TABLE I.* Maximum rate ratio attainable by a perturbative screening mechanism as a function of its domain-of-validity ceiling, and the number of independent concatenated cells required to reach the benchmark ln _R_ = 16. The physically defensible ceiling for a trapped condensate is _η_~max~ ≈ 10^−2^ (second row)."));
c.push(TBL(
  ["Mechanism", "Control parameter", "_R_", "ln _R_"],
  [
    ["Cat qubit", "|_α_|^2^ = 4", "2.98 × 10^3^", "8.0"],
    ["Cat qubit", "|_α_|^2^ = 8", "8.89 × 10^6^", "16.0"],
    ["Cat qubit", "|_α_|^2^ = 11", "3.59 × 10^9^", "22.0"],
    ["Cat qubit", "|_α_|^2^ = 20", "2.35 × 10^17^", "40.0"],
    ["Perturbative screening", "_η_~max~ = 10^−2^", "1.0101", "0.0101"],
  ],
  [3000, 2200, 2000, 1500]));
c.push(CAPTION("*TABLE II.* Benchmark comparison. The cat-qubit entries use the standard exponential scaling _R_ ≈ exp(2|_α_|^2^) of Refs. [1–3]; experimental realizations at the quoted photon numbers are reported in Refs. [4–6]. The gap in ln _R_ between the last row and the second is a factor of 1584."));

c.push(H2("B. Corollaries"));
c.push(P("*Corollary 1 (single-cell impossibility).* To reach _R_ = exp(16) in a single cell, a mechanism of the form (1) would require"));
c.push(EQ("_η_~max~ = 1 − e^−16^ = 1 − 1.125 × 10^−7^.", "(4)"));
c.push(P("For a condensate this is not a demanding requirement; it is an impossible one, since _η_ → 1 corresponds to _Na_/_a_~ho~ ≈ 0.07, i.e. of order ten atoms, at which point neither the Thomas–Fermi profile nor the hydrodynamic description that generated Eq. (1) exists."));
c.push(P("*Corollary 2 (concatenation does not rescue).* If _M_ independent cells act multiplicatively, _R_~tot~ = (1 − _η_)^−_M_^, so reaching ln _R_ = 16 requires _M_ = 16/|ln(1 − _η_~max~)|. At _η_~max~ = 10^−2^ this is _M_ = 1592 cells to match one cat qubit at |_α_|^2^ = 8. The comparison is not close, and it worsens as the benchmark advances: matching |_α_|^2^ = 11 requires 2189 cells and |_α_|^2^ = 20 requires 3980."));
c.push(P("*Corollary 3 (the obstruction is structural).* Theorem 1 and its corollaries do not depend on the value of _η_~max~ except logarithmically. Improving the ceiling from 10^−2^ to 10^−1^ — an order of magnitude, and beyond anything the underlying physics permits — reduces the required cell count only from 1592 to 152. No conceivable improvement within the perturbative class closes a gap that is exponential on one side and polynomial on the other."));

c.push(H2("C. What the theorem does not say"));
c.push(P("Theorem 1 is not a statement that mechanisms of the form (1) are physically absent, nor that they are uninteresting. A rate ratio of 1.01 is a per-cent effect, which in metrology is large and in fundamental physics may be decisive. The theorem states only that such a ratio is not a route to passive error exclusion, because the paradigm's benchmark is set seven orders of magnitude away. Confusing a measurable effect with a useful one is the error the theorem is designed to prevent."));
c.push(P("Nor does the theorem apply to mechanisms whose suppression is non-linear in _η_, or which act on the exponent of a rate rather than on a prefactor. Distinguishing these cases requires the microscopic derivation and cannot be settled from the phenomenological form alone. Section IV is written so as to apply to any candidate, whatever its origin."));

/* -------------------------------------------------------------------- IV */
c.push(H1("IV. Four necessary conditions"));
c.push(P("We now state what a geometric mechanism must satisfy to be a candidate. The conditions are necessary, not sufficient; each is quantified so that a candidate can be tested against it before any architecture is discussed."));

c.push(H2("C1. Non-analyticity in the control parameter"));
c.push(P("The rate ratio must diverge, or grow exponentially in an unbounded parameter, within the physically admissible range. Equivalently, _R_ must not be expressible as a convergent power series in a bounded control parameter with bounded coefficients. This is precisely the property Theorem 1 shows to be absent from Eq. (1)."));
c.push(P("The operational test is a scan: measure or compute _R_ as the control parameter is varied over its admissible range and check whether ln _R_ grows without bound. A mechanism that saturates within its domain fails C1 regardless of how large the saturation value is."));
c.push(P("We note that even the cat qubit satisfies C1 only approximately. Saturation of the exponential bit-flip suppression at large photon number has been reported and analysed [8], and it is a reminder that C1 is a statement about the idealized mechanism which real implementations approach and then depart from. A candidate that fails C1 at the level of its idealization has no prospect of passing it in the laboratory."));

c.push(H2("C2. A discrete sector label protected by a gap"));
c.push(P("Suppression that is continuous in the state variables can be undone continuously. Competitive protection requires that the protected sectors be labelled by a quantity that cannot change continuously — a winding number, a parity, a topological charge — and that the label be protected by an energetic or dissipative gap Δ large compared with both the thermal scale and the bandwidth of the control drives."));
c.push(P("The requirement is quantitative. If the residual rate is thermally activated, _R_ = exp(Δ/_k_~B~_T_), then Table III gives the gap needed."));
c.push(TBL(
  ["Target _R_", "Δ/_h_ at 10 mK", "Δ/_h_ at 20 mK", "Δ/_h_ at 50 mK"],
  [
    ["10^3^", "1.44 GHz", "2.88 GHz", "7.20 GHz"],
    ["10^6^", "2.88 GHz", "5.76 GHz", "14.4 GHz"],
    ["10^7^", "3.36 GHz", "6.72 GHz", "16.8 GHz"],
    ["10^9^", "4.32 GHz", "8.64 GHz", "21.6 GHz"],
  ],
  [1700, 2200, 2200, 2200]));
c.push(CAPTION("*TABLE III.* Gap required for a thermally activated suppression to reach a given rate ratio, from Δ = _k_~B~_T_ ln _R_. At 20 mK, _k_~B~_T_/_h_ = 417 MHz."));
c.push(P("The scale of the requirement is worth stating plainly: at the standard dilution-refrigerator temperature of 20 mK, matching a cat qubit at |_α_|^2^ = 8 requires a gap of 6.7 GHz, comparable to a transmon transition frequency and far above any energy scale available in a dilute Bose gas, where the chemical potential at the working densities of interest is of order 1 kHz in frequency units. A mechanism whose natural gap is set by _μ_ cannot satisfy C2 in a solid-state architecture, and this is an argument about units rather than about details."));

c.push(H2("C3. Preservation under the operating gate set"));
c.push(P("Protection that is destroyed when the qubit is operated is not protection. The mechanism must commute, at least approximately, with a gate set sufficient for the intended computation; in the cat-qubit case this is the bias-preserving gate set, whose construction was a substantial and separate theoretical achievement [2,9] and whose experimental demonstration [6] was the step that made the paradigm credible."));
c.push(P("The operational test is to write down the generator of each gate and verify that it does not connect protected sectors. A candidate mechanism for which this cannot be done — because the sector structure is not known explicitly — has not yet reached the stage at which C3 can be evaluated, and claims about architecture are premature."));

c.push(H2("C4. Dominance of the suppressed channel"));
c.push(P("Suppressing a channel that is not dominant buys little, and the bound is elementary. If the targeted channel contributes a fraction _p_ of the total error budget and is suppressed perfectly, the end-to-end improvement is"));
c.push(EQ("_R_~tot~ ≤ (1 − _p_)^−1^.", "(5)"));
c.push(TBL(
  ["_p_", "0.5", "0.9", "0.99", "0.999"],
  [["Maximum _R_~tot~", "2", "10", "100", "1000"]],
  [3000, 1500, 1500, 1500, 1500]));
c.push(CAPTION("*TABLE IV.* End-to-end bound of Eq. (5). Perfect suppression of 90 % of the error budget yields at most a factor of ten overall."));
c.push(P("C4 is the condition most often overlooked, because it concerns the system and not the mechanism. It is also the condition under which the cat qubit succeeds for a non-obvious reason: bit-flip errors are not merely suppressed, they are suppressed while the residual phase-flip errors are handled by a concatenated code with a favourable threshold, so that the architecture is designed around the resulting noise bias rather than in spite of it [7,9]. A candidate mechanism must specify not only what it suppresses but what the surviving error structure is and what code exploits it."));

/* --------------------------------------------------------------------- V */
c.push(H1("V. Discussion"));
c.push(H2("A. Which mechanism classes remain"));
c.push(P("Conditions C1 and C2 together are restrictive: the mechanism must be non-analytic in its control parameter and must possess a discrete label with a large gap. In practice this points to topologically protected structures — sectors labelled by an integer winding, separated by an energy barrier that scales with a controllable quantity. Whether a coherence-screening framework of the type that motivates Eq. (1) admits such structures is an open existence question, not an architectural one."));
c.push(P("We state the logical order explicitly, because it is frequently inverted in speculative discussions of this kind. The sequence is: (i) establish that the framework admits a localized defect carrying an integer label; (ii) establish that the label is protected by a gap satisfying C2; (iii) establish metastability of the labelled states on operational timescales; (iv) construct a gate set satisfying C3; (v) identify an architecture satisfying C4. Steps (iv) and (v) are where the discussion usually begins, and they are the last two. Nothing in steps (iv) and (v) can be evaluated before step (i) is settled, and step (i) is a question about the equations of the framework, answerable without any reference to quantum computing."));

c.push(H2("B. On the asymmetry of the wager"));
c.push(P("It should be said in favour of this research direction that its surrounding technology stack is already built. If a mechanism satisfying C1–C4 were found, it would not need to construct an architecture, a threshold theory, a gate set or a fabrication base; all four exist and were developed for the cat qubit. That is an unusually favourable position for a speculative mechanism, and it is the honest argument for keeping the direction on a long-horizon agenda."));
c.push(P("But the argument cuts only after C1 is satisfied, and Theorem 1 shows that the perturbative form does not satisfy it. The favourable stack is a reason to pursue the existence question in step (i), not a reason to discuss steps (iv) and (v) in advance of it."));

c.push(H2("C. Limitations"));
c.push(BULLET("Theorem 1 assumes the error rate is linear in the screened coupling. A mechanism entering the exponent of a rate — for instance by modifying a tunnelling action — would evade it, and identifying which case applies requires the microscopic theory."));
c.push(BULLET("The gap requirement of C2 was computed for thermally activated residual rates. Mechanisms limited by coherent leakage rather than thermal activation obey a different relation, and Table III should be recomputed accordingly."));
c.push(BULLET("The concatenation bound of Corollary 2 assumes independent cells with multiplicative ratios. Correlated cells would do worse, not better; the corollary is therefore an optimistic bound."));
c.push(BULLET("We have benchmarked against the cat qubit because it is the mature realization of the paradigm. Other bosonic codes have different scalings, and a candidate mechanism might be competitive against one and not another; C1–C4 are stated so as not to depend on the choice of benchmark."));

/* -------------------------------------------------------------------- VI */
c.push(H1("VI. Conclusion"));
c.push(P("We have asked whether a coherence-based geometric suppression mechanism of the form _κ_~eff~ = _κ_~0~(1 − _η_) could implement passive error exclusion in the sense realized by bosonic cat qubits, and we have shown that it cannot, for a reason that is structural rather than quantitative."));
c.push(P("Theorem 1 establishes that any such mechanism, having a bounded domain of validity _η_ ≤ _η_~max~, admits a rate ratio no larger than (1 − _η_~max~)^−1^. For the physically defensible ceiling _η_~max~ = 10^−2^ this is 1.0101, against a benchmark of 8.9 × 10^6^ set by a cat qubit at mean photon number 8. Matching the benchmark in one cell would require _η_~max~ = 1 − 1.1 × 10^−7^; matching it by concatenation would require 1592 independent cells. Raising the ceiling by an entire order of magnitude, beyond what the underlying physics permits, reduces that count only to 152. The obstruction is that one side of the comparison is exponential and the other polynomial in a bounded quantity, and no engineering within the perturbative class alters that."));
c.push(P("We have converted the failure into a specification. A candidate mechanism must (C1) be non-analytic in its control parameter, so that ln _R_ grows without bound within the admissible range; (C2) possess a discrete sector label protected by a gap, which for a rate ratio of 10^7^ at 20 mK means 6.7 GHz — a figure that immediately excludes any mechanism whose natural energy scale is the chemical potential of a dilute Bose gas, of order 1 kHz; (C3) survive the operating gate set, which for the cat qubit required the separate construction of bias-preserving gates; and (C4) address a channel that dominates the error budget, since perfect suppression of 90 % of errors yields at most a factor of ten end to end."));
c.push(P("The conditions are ordered, and the ordering is the practical output of this work. Steps concerning architecture, gate sets and code selection cannot be evaluated before the existence of a discrete, gapped, non-analytic sector structure has been established within the framework in question — and that is a question about the framework's own equations, answerable without reference to quantum computation at all. We identify it as the sole prerequisite and recommend that effort be directed there."));
c.push(P("Finally, we record a distinction that Theorem 1 makes precise and that speculative discussion tends to blur. A rate ratio of 1.01 is not a small version of a rate ratio of 10^7^; it belongs to a different functional class and is useful for different purposes. As a modification of a measurable coupling it is a per-cent effect, which is large by the standards of precision measurement and would be a significant result if established. As a mechanism for excluding errors it is not a partial solution but no solution. Both statements are true simultaneously, and keeping them apart is, in our assessment, the main service this analysis can render to the programme it examines."));

c.push(H1("Acknowledgments"));
c.push(P("The author thanks colleagues at the Faculty of Physics, M. V. Lomonosov Moscow State University for discussions."));

c.push(H1("Competing interests"));
c.push(P("The author declares no competing interests."));

c.push(H1("Data availability"));
c.push(P("Tables I–IV are produced by direct evaluation of Eqs. (3)–(5) and of the relation Δ = _k_~B~_T_ ln _R_; the evaluation script will be deposited in a public repository on publication. No experimental data were produced or analysed."));

c.push(H1("References"));
const refs = [
  "M. Mirrahimi, Z. Leghtas, V. V. Albert, S. Touzard, R. J. Schoelkopf, L. Jiang and M. H. Devoret, Dynamically protected cat-qubits: a new paradigm for universal quantum computation, New J. Phys. *16*, 045014 (2014). DOI: 10.1088/1367-2630/16/4/045014",
  "J. Guillaud and M. Mirrahimi, Repetition cat qubits for fault-tolerant quantum computation, Phys. Rev. X *9*, 041053 (2019). DOI: 10.1103/PhysRevX.9.041053",
  "Z. Leghtas, S. Touzard, I. M. Pop, A. Kou, B. Vlastakis, A. Petrenko, K. M. Sliwa, A. Narla, S. Shankar, M. J. Hatridge, M. Reagor, L. Frunzio, R. J. Schoelkopf, M. Mirrahimi and M. H. Devoret, Confining the state of light to a quantum manifold by engineered two-photon loss, Science *347*, 853 (2015). DOI: 10.1126/science.aaa2085",
  "C. Berdou, A. Murani, U. Réglade, W. C. Smith, M. Villiers, J. Palomo, M. Rosticher, A. Denis, P. Morfin, M. Delbecq, T. Kontos, N. Pankratova, F. Rautschke, T. Peronnin, L.-A. Sellem, P. Rouchon, A. Sarlette, M. Mirrahimi, P. Campagne-Ibarcq, S. Jezouin, R. Lescanne and Z. Leghtas, One hundred second bit-flip time in a two-photon dissipative oscillator, PRX Quantum *4*, 020350 (2023). DOI: 10.1103/PRXQuantum.4.020350",
  "A. Marquet, A. Essig, J. Cohen, N. Cottet, A. Murani, E. Albertinale, S. Dupouy, A. Bienfait, T. Peronnin, S. Jezouin, R. Lescanne and B. Huard, Autoparametric resonance extending the bit-flip time of a cat qubit up to 0.3 s, Phys. Rev. X *14*, 021019 (2024). DOI: 10.1103/PhysRevX.14.021019",
  "U. Réglade, A. Bocquet, R. Gautier, J. Cohen, A. Marquet, E. Albertinale, N. Pankratova, M. Hallén, F. Rautschke, L.-A. Sellem, P. Rouchon, A. Sarlette, M. Mirrahimi, P. Campagne-Ibarcq, R. Lescanne, S. Jezouin and Z. Leghtas, Quantum control of a cat qubit with bit-flip times exceeding ten seconds, Nature *629*, 778 (2024). DOI: 10.1038/s41586-024-07294-3",
  "H. Putterman _et al._, Hardware-efficient quantum error correction via concatenated bosonic qubits, Nature *638*, 927 (2025). DOI: 10.1038/s41586-025-08642-7",
  "R. Lescanne, M. Villiers, T. Peronnin, A. Sarlette, M. Delbecq, B. Huard, T. Kontos, M. Mirrahimi and Z. Leghtas, Exponential suppression of bit-flips in a qubit encoded in an oscillator, Nat. Phys. *16*, 509 (2020). DOI: 10.1038/s41567-020-0824-x",
  "C. Chamberland, K. Noh, P. Arrangoiz-Arriola, E. T. Campbell, C. T. Hann, J. Iverson, H. Putterman, T. C. Bohdanowicz, S. T. Flammia, A. Keller, G. Refael, J. Preskill, L. Jiang, A. H. Safavi-Naeini, O. Painter and F. G. S. L. Brandão, Building a fault-tolerant quantum computer using concatenated cat codes, PRX Quantum *3*, 010329 (2022). DOI: 10.1103/PRXQuantum.3.010329",
  "S. Puri, S. Boutin and A. Blais, Engineering the quantum states of light in a Kerr-nonlinear resonator by two-photon driving, npj Quantum Inf. *3*, 18 (2017). DOI: 10.1038/s41534-017-0019-1",
  "A. Grimm, N. E. Frattini, S. Puri, S. O. Mundhada, S. Touzard, M. Mirrahimi, S. M. Girvin, S. Shankar and M. H. Devoret, Stabilization and operation of a Kerr-cat qubit, Nature *584*, 205 (2020). DOI: 10.1038/s41586-020-2587-z",
  "S. Touzard, A. Grimm, Z. Leghtas, S. O. Mundhada, P. Reinhold, C. Axline, M. Reagor, K. Chou, J. Blumoff, K. M. Sliwa, S. Shankar, L. Frunzio, R. J. Schoelkopf, M. Mirrahimi and M. H. Devoret, Coherent oscillations inside a quantum manifold stabilized by dissipation, Phys. Rev. X *8*, 021005 (2018). DOI: 10.1103/PhysRevX.8.021005",
  "P. Aliferis and J. Preskill, Fault-tolerant quantum computation against biased noise, Phys. Rev. A *78*, 052331 (2008). DOI: 10.1103/PhysRevA.78.052331",
  "A. Yu. Kitaev, Fault-tolerant quantum computation by anyons, Ann. Phys. *303*, 2 (2003). DOI: 10.1016/S0003-4916(02)00018-0",
  "B. Douçot and L. B. Ioffe, Physical implementation of protected qubits, Rep. Prog. Phys. *75*, 072001 (2012). DOI: 10.1088/0034-4885/75/7/072001",
  "A. Gyenis, P. S. Mundada, A. Di Paolo, T. M. Hazard, X. You, D. I. Schuster, J. Koch, A. Blais and A. A. Houck, Experimental realization of a protected superconducting circuit derived from the 0–π qubit, PRX Quantum *2*, 010339 (2021). DOI: 10.1103/PRXQuantum.2.010339",
  "V. V. Albert, K. Noh, K. Duivenvoorden, D. J. Young, R. T. Brierley, P. Reinhold, C. Vuillot, L. Li, C. Shen, S. M. Girvin, B. M. Terhal and L. Jiang, Performance and structure of single-mode bosonic codes, Phys. Rev. A *97*, 032346 (2018). DOI: 10.1103/PhysRevA.97.032346",
  "D. Gottesman, A. Kitaev and J. Preskill, Encoding a qubit in an oscillator, Phys. Rev. A *64*, 012310 (2001). DOI: 10.1103/PhysRevA.64.012310",
  "F. M. Le Régent, C. Berdou, Z. Leghtas, J. Guillaud and M. Mirrahimi, High-performance repetition cat code using fast noisy operations, Quantum *7*, 1198 (2023). DOI: 10.22331/q-2023-12-06-1198",
  "R. Gautier, A. Sarlette and M. Mirrahimi, Combined dissipative and Hamiltonian confinement of cat qubits, PRX Quantum *3*, 020339 (2022). DOI: 10.1103/PRXQuantum.3.020339",
  "C. J. Pethick and H. Smith, _Bose-Einstein Condensation in Dilute Gases_, 2nd ed. (Cambridge University Press, Cambridge, 2008).",
];
refs.forEach((r, i) => c.push(REF(i + 1, r)));

c.push(H1("Appendix A: numerical conventions"));
c.push(P("The cat-qubit rate ratio is taken as _R_ = exp(2|_α_|^2^), the standard leading-order scaling of the bit-flip rate with mean photon number in a two-photon dissipatively stabilized oscillator [1,8]. Experimental realizations do not follow this law indefinitely; saturation at large |_α_|^2^ has been reported and analysed [8], and the values in Table II should therefore be read as the idealized benchmark rather than as measured performance. Using measured rather than idealized values would reduce the benchmark somewhat and would not affect any conclusion, since the gap to be closed is of order 10^6^ and the saturation reported is of order 10^1^–10^2^."));
c.push(P("The thermal relation Δ = _k_~B~_T_ ln _R_ used in Table III assumes a residual rate of Arrhenius form with an attempt frequency absorbed into the prefactor. At _T_ = 20 mK, _k_~B~_T_/_h_ = 416.7 MHz, so that ln _R_ = 16.1 corresponds to Δ/_h_ = 6.72 GHz."));
c.push(P("The comparison scale quoted in Sec. IV.C2 for a dilute Bose gas is the chemical potential at the densities relevant to collective-mode spectroscopy: for ^87^Rb at _n_ = 10^14^ cm^−3^, _μ_/_h_ = 774 Hz, i.e. _μ_/_k_~B~ = 37.1 nK. The ratio to the required gap is approximately 10^7^, which is the numerical content of the remark that the exclusion follows from units rather than from details."));

const doc = buildDoc("Tishin — No-go for perturbative screening in error exclusion", c);
Packer.toBuffer(doc).then(b => {
  fs.writeFileSync('./out/Paper3_NoGo_Error_Exclusion.docx', b);
  console.log('paper 3 written');
});
