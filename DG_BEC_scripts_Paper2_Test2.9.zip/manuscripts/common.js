const docx = require('docx');
const {
  Document, Packer, Paragraph, TextRun, HeadingLevel, AlignmentType,
  Table, TableRow, TableCell, WidthType, ShadingType, BorderStyle,
  PositionalTab, PositionalTabAlignment, PositionalTabLeader,
  PageNumber, Header, Footer, convertInchesToTwip
} = docx;

const FONT = "Times New Roman";
const SZ = 24;      // 12 pt
const LINE = 360;   // 1.5 spacing

/*  Inline markup used throughout the manuscripts:
      _x_    italic
      ~ab~   true subscript
      ^ab^   true superscript
      *b*    bold
    Everything else is plain text.                                    */
function parse(text, opts = {}) {
  const base = { font: FONT, size: opts.size || SZ, ...(opts.extra || {}) };
  const runs = [];
  let buf = "";
  let i = 0;
  const flush = (extra) => {
    if (buf.length) { runs.push(new TextRun({ text: buf, ...base, ...(extra || {}) })); buf = ""; }
  };
  while (i < text.length) {
    const c = text[i];
    if (c === "\\") { buf += text[i + 1]; i += 2; continue; }
    if (c === "_" || c === "~" || c === "^" || c === "*") {
      const close = text.indexOf(c, i + 1);
      if (close > i) {
        flush();
        const inner = text.slice(i + 1, close);
        const extra = c === "_" ? { italics: true }
          : c === "~" ? { subScript: true }
            : c === "^" ? { superScript: true }
              : { bold: true };
        // Recurse so that nested markup (e.g. italics inside bold) survives.
        const merged = { ...(opts.extra || {}), ...extra };
        runs.push(...parse(inner, { size: opts.size, extra: merged }));
        i = close + 1;
        continue;
      }
    }
    buf += c; i++;
  }
  flush();
  return runs;
}

const P = (text, opts = {}) => new Paragraph({
  children: parse(text, opts),
  alignment: opts.align || AlignmentType.JUSTIFIED,
  spacing: { line: opts.line || LINE, after: opts.after === undefined ? 120 : opts.after,
             before: opts.before || 0 },
  indent: opts.indent || undefined,
});

const H1 = (text) => new Paragraph({
  children: parse(text, { extra: { bold: true } }),
  heading: HeadingLevel.HEADING_1,
  spacing: { before: 320, after: 160, line: LINE },
});

const H2 = (text) => new Paragraph({
  children: parse(text, { extra: { bold: true } }),
  heading: HeadingLevel.HEADING_2,
  spacing: { before: 260, after: 130, line: LINE },
});

const TITLE = (text) => new Paragraph({
  children: parse(text, { size: 30, extra: { bold: true } }),
  alignment: AlignmentType.CENTER,
  spacing: { after: 240, line: LINE },
});

const CENTER = (text, opts = {}) => new Paragraph({
  children: parse(text, opts),
  alignment: AlignmentType.CENTER,
  spacing: { after: opts.after === undefined ? 120 : opts.after, line: LINE },
});

/* Numbered display equation: centred body, tag pushed to the right margin. */
const EQ = (body, tag) => new Paragraph({
  children: [
    new TextRun({ text: "\t", font: FONT, size: SZ }),
    ...parse(body),
    new TextRun({ text: "\t", font: FONT, size: SZ }),
    ...parse(tag),
  ],
  alignment: AlignmentType.LEFT,
  spacing: { before: 160, after: 160, line: LINE },
  tabStops: [
    { type: "center", position: 4680 },
    { type: "right", position: 9360 },
  ],
});

const BULLET = (text) => new Paragraph({
  children: parse(text),
  alignment: AlignmentType.JUSTIFIED,
  spacing: { after: 90, line: LINE },
  numbering: { reference: "bullets", level: 0 },
});

const NUMBERED = (text) => new Paragraph({
  children: parse(text),
  alignment: AlignmentType.JUSTIFIED,
  spacing: { after: 90, line: LINE },
  numbering: { reference: "numlist", level: 0 },
});

/* Table: header row shaded, DXA widths on table and every cell. */
function TBL(headers, rows, widths) {
  const total = widths.reduce((a, b) => a + b, 0);
  const cell = (txt, w, opts = {}) => new TableCell({
    width: { size: w, type: WidthType.DXA },
    shading: opts.head ? { type: ShadingType.CLEAR, fill: "E8E8E8" } : undefined,
    margins: { top: 60, bottom: 60, left: 90, right: 90 },
    children: [new Paragraph({
      children: parse(txt, { size: 22, extra: opts.head ? { bold: true } : {} }),
      alignment: opts.align || AlignmentType.LEFT,
      spacing: { line: 240, after: 0 },
    })],
  });
  return new Table({
    width: { size: total, type: WidthType.DXA },
    columnWidths: widths,
    rows: [
      new TableRow({
        tableHeader: true,
        children: headers.map((h, k) => cell(h, widths[k], { head: true })),
      }),
      ...rows.map(r => new TableRow({
        children: r.map((c, k) => cell(c, widths[k],
          { align: k === 0 ? AlignmentType.LEFT : AlignmentType.CENTER })),
      })),
    ],
  });
}

const CAPTION = (text) => new Paragraph({
  children: parse(text, { size: 22 }),
  alignment: AlignmentType.JUSTIFIED,
  spacing: { before: 120, after: 220, line: 280 },
});

const RULE = () => new Paragraph({
  children: [new TextRun({ text: "", font: FONT, size: SZ })],
  border: { bottom: { style: BorderStyle.SINGLE, size: 6, color: "999999", space: 6 } },
  spacing: { before: 120, after: 180 },
});

const REF = (n, text) => new Paragraph({
  children: parse(`[${n}]  ` + text, { size: 22 }),
  alignment: AlignmentType.JUSTIFIED,
  spacing: { after: 90, line: 280 },
  indent: { left: 480, hanging: 480 },
});

function buildDoc(runningTitle, children) {
  return new Document({
    styles: {
      default: {
        document: { run: { font: FONT, size: SZ } },
        heading1: { run: { font: FONT, size: 26, bold: true, color: "000000" } },
        heading2: { run: { font: FONT, size: 24, bold: true, italics: true, color: "000000" } },
      },
    },
    numbering: {
      config: [
        { reference: "bullets", levels: [{ level: 0, format: docx.LevelFormat.BULLET, text: "\u2022",
            alignment: AlignmentType.LEFT,
            style: { paragraph: { indent: { left: 460, hanging: 260 } } } }] },
        { reference: "numlist", levels: [{ level: 0, format: docx.LevelFormat.DECIMAL, text: "(%1)",
            alignment: AlignmentType.LEFT,
            style: { paragraph: { indent: { left: 520, hanging: 320 } } } }] },
      ],
    },
    sections: [{
      properties: { page: { margin: { top: 1440, bottom: 1440, left: 1440, right: 1440 } } },
      headers: {
        default: new Header({ children: [new Paragraph({
          children: parse(runningTitle, { size: 20 }),
          alignment: AlignmentType.RIGHT, spacing: { after: 0 } })] }),
      },
      footers: {
        default: new Footer({ children: [new Paragraph({
          alignment: AlignmentType.CENTER,
          children: [new TextRun({ children: [PageNumber.CURRENT], font: FONT, size: 20 })] })] }),
      },
      children,
    }],
  });
}

module.exports = { docx, Packer, P, H1, H2, TITLE, CENTER, EQ, BULLET, NUMBERED,
                   TBL, CAPTION, RULE, REF, buildDoc, parse, FONT, SZ, LINE };
