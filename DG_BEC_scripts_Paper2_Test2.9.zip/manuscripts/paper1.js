const fs = require('fs');
const { Packer, P, H1, H2, TITLE, CENTER, EQ, BULLET, TBL, CAPTION, RULE, REF, buildDoc } = require('./common');

const c = [];

/* ------------------------------------------------------------------ FRONT */
c.push(TITLE("Validity Bound and Finite-Size Degeneracy of Screening-Type Corrections to the Collective Spectrum of a Trapped Bose–Einstein Condensate"));
c.push(CENTER("A. M. Tishin", { extra: { bold: true } }));
c.push(CENTER("_Faculty of Physics, M. V. Lomonosov Moscow State University, Moscow 119991, Russia_", { size: 22 }));
c.push(CENTER("ORCID: 0000-0003-2252-7279", { size: 22, after: 260 }));

c.push(H1("Abstract"));
c.push(P("A class of proposed mechanisms modifies an effective coupling of a Bose–Einstein condensate according to _κ_~eff~ = _κ_~0~(1 − _η_), where _η_ = (_ξ_/_L_)^2^ is built from the healing length _ξ_ and a macroscopic coherence scale _L_. Such mechanisms are naturally tested through the collective-mode spectrum, which is the most precisely measured observable of a trapped condensate. We establish two model-independent constraints on that programme. First, for a harmonically trapped condensate in the Thomas–Fermi regime the exact identity _ξ_(0)_R_~TF~ = _a_~ho~^2^ forces _η_ = (_a_~ho~/_R_~TF~)^4^ = (15_Na_/_a_~ho~)^−4/5^, so that the screening parameter and the Thomas–Fermi validity parameter are the same quantity: _Na_/_a_~ho~ = _η_^−5/4^/15. The strong-screening limit _ξ_ → _L_ therefore lies at _Na_/_a_~ho~ ≈ 0.07, three orders of magnitude outside the regime in which the hydrodynamic equations that generate the prediction are valid; the largest defensible value is _η_ ≈ 10^−2^, already marginal. This bound is independent of atomic species, trap frequency and scattering length, because _a_ and _a_~ho~ cancel identically. Second, the leading finite-size (quantum-pressure) correction to hydrodynamic collective frequencies scales as (_a_~ho~/_R_~TF~)^4^, which is _η_ itself. Any screening term entering at first order in _η_ is therefore exactly degenerate in scaling with a correction already contained in Gross–Pitaevskii theory, and no single-configuration frequency measurement can separate the two: only the dimensionless prefactors differ. We quantify the consequences for ^87^Rb at _N_ = 10^5^ and _ω_~ho~/2_π_ = 100 Hz, where _η_ = 8.0 × 10^−4^ and the beyond-mean-field and thermal backgrounds exceed a 1.5 mHz target shift by factors of 870 and 1490. We then argue that the correct observable is not a frequency but the ratio _ω_~B~/_ω_~D~ of the breathing mode to the dipole mode. By Kohn's theorem the dipole frequency equals the trap frequency exactly, independently of atom number, interaction and temperature, so the ratio carries an internal, physically protected frequency reference measured on the same atoms in the same realization; its Thomas–Fermi value 5^1/2^ is parameter-free. This removes trap-frequency calibration and drift from the error budget identically rather than reducing them, and it promotes trap anharmonicity to the leading systematic. We compute both anharmonic coefficients in closed form for a Thomas–Fermi cloud: the breathing mode shifts by −(7/9)(_R_~TF~/_w_~0~)^2^, obtained from the _m_~1~/_m_~−1~ sum rule and verified numerically to five digits, and the dipole mode by −(3/7)(_R_~TF~/_w_~0~)^2^ from expansion about the centre of mass. The residual in the ratio is therefore _c_~an~ = 7/9 − 3/7 = 22/63, so that the ratio suppresses the anharmonic systematic by a factor 2.86 as well as removing the calibration. Brute-force suppression would demand a waist of 1.46 mm at a power cost scaling as _w_~0~^4^, but because the coefficient is exact the shift is a correction to be subtracted rather than a floor: the binding quantity is its uncertainty, and a 300 μm waist with 1 % beam profiling and 5 % atom-number calibration suffices. An all-optical apparatus is thus not excluded. We also quantify the magnetic alternative, where the naive appeal to coil-scale curvature fails: the radial anharmonic length of an Ioffe–Pritchard trap is _w_~eff~ = 2(_μB_~0~/_mω_~0~^2^)^1/2^, independent of coil geometry, so a conventional 1 G bias gives 255 μm and is no better than a large-waist optical trap. Its true advantage is that _w_~eff~ is tunable in situ by the bias field, which makes the anharmonic term measurable rather than merely computable: recording the ratio across _B_~0~ = 3–100 G and extrapolating in 1/_w_~eff~^2^ spans the target by an order of magnitude on either side without requiring the coefficient to be trusted. A separate Duffing constraint requires the sloshing amplitude to stay below 0.90 μm, a fraction of the oscillator length. Counting statistics remain non-binding at 25 realizations. We close by specifying a differential protocol in which the vortex charge _n_ = 0, 1 is the discriminating variable, and by stating the trade-off that no single geometry resolves: harmonic confinement supplies the Kohn reference but carries the degeneracy, whereas uniform confinement lifts the degeneracy but has no Kohn mode."));

c.push(P("*Keywords:* Bose–Einstein condensate; collective excitations; Kohn theorem; Thomas–Fermi approximation; finite-size corrections; trap anharmonicity; precision spectroscopy; quantized vortices.", { after: 60 }));
c.push(P("*PACS:* 03.75.Kk, 03.75.Lm, 67.85.De, 67.85.Bc"));

c.push(RULE());

/* ------------------------------------------------------------------- I */
c.push(H1("I. Introduction"));
c.push(P("The collective excitation spectrum of a harmonically trapped Bose–Einstein condensate is among the most sharply predicted and most precisely measured quantities in dilute-gas physics. In the Thomas–Fermi (TF) limit the hydrodynamic equations give the closed dispersion law of Stringari [1], _ω_ = _ω_~0~(2_n_^2^ + 2_nl_ + 3_n_ + _l_)^1/2^, whose predictions were confirmed within a few per cent immediately after the first condensates became available [2,3]; see Ref. [4] for a review of the period. The residual disagreement at the per-cent level is itself structured: it decomposes into a finite-size (quantum-pressure) correction [5,6], a beyond-mean-field Lee–Huang–Yang correction [7,8], a non-linearity correction, and a thermal correction [9]. This layered structure is what makes the collective spectrum attractive as a testbed: a hypothesized new term can in principle be inserted into an otherwise well-characterized budget."));
c.push(P("Several proposals share a common structural form. A macroscopically coherent medium is argued to suppress some effective coupling over a length scale set by the condensate healing length, with the suppression written as"));
c.push(EQ("_κ_~eff~ = _κ_~0~(1 − _η_),   _η_ = _ξ_^2^/_L_^2^,", "(1)"));
c.push(P("where _ξ_ is the healing length and _L_ a macroscopic coherence or congruence scale. The formal analogy is with the Meissner effect, _ξ_ playing a role parallel to the London penetration depth, and the strong-screening limit is identified with _ξ_ → _L_. The natural experimental channel is a shift of a collective-mode frequency, and shifts of order a few millihertz have been quoted for standard ^87^Rb parameters."));
c.push(P("This paper does not evaluate any particular microscopic derivation of Eq. (1). It asks a narrower and prior question: given the form of Eq. (1) alone, what can be said about (i) the range of _η_ that is internally consistent, and (ii) the separability of an _O_(_η_) frequency shift from corrections already present in Gross–Pitaevskii (GP) theory? Both answers turn out to be sharp, both are negative for the simplest experimental strategy, and both are constructive in the sense that they identify precisely which measurement geometry survives."));
c.push(P("The results are stated as two propositions. Proposition 1 (Sec. III) is an identity: in a harmonic trap the screening parameter _η_ and the TF validity parameter _Na_/_a_~ho~ are algebraically locked, so that increasing _η_ necessarily destroys the approximation that produced Eq. (1). Proposition 2 (Sec. IV) is a degeneracy: the leading finite-size correction to collective frequencies scales as _η_ exactly, so that a first-order screening term and a known GP term are indistinguishable by scaling and differ only in a numerical prefactor. Sections V–VII convert these into a quantitative error budget and a differential measurement protocol whose discriminating variable is the vortex charge. Section VIII lists the assumptions that must be discharged before the protocol can be regarded as a test."));

/* ------------------------------------------------------------------ II */
c.push(H1("II. Setup and notation"));
c.push(P("We consider _N_ bosons of mass _m_ and _s_-wave scattering length _a_ > 0 in an isotropic harmonic trap of angular frequency _ω_~0~, described at zero temperature by the Gross–Pitaevskii equation"));
c.push(EQ("_iħ_ ∂_Ψ_/∂_t_ = [ −_ħ_^2^∇^2^/2_m_ + _V_~ext~(**r**) + _g_|_Ψ_|^2^ ] _Ψ_,   _g_ = 4_πħ_^2^_a_/_m_.", "(2)"));
c.push(P("We use the oscillator length _a_~ho~ = (_ħ_/_mω_~0~)^1/2^. In the TF limit the kinetic term is neglected and the density profile is the inverted parabola _n_(_r_) = [_μ_ − _V_~ext~(_r_)]/_g_ with"));
c.push(EQ("_R_~TF~ = _a_~ho~ (15_Na_/_a_~ho~)^1/5^,   _μ_ = ½ _mω_~0~^2^_R_~TF~^2^,   _n_(0) = _μ_/_g_.", "(3)"));
c.push(P("The healing length evaluated at the trap centre is"));
c.push(EQ("_ξ_(0) = _ħ_ / (2_mgn_(0))^1/2^ = _ħ_ / (2_mμ_)^1/2^.", "(4)"));
c.push(P("Throughout, _η_ denotes the screening parameter of Eq. (1) with _L_ identified with the condensate radius, _L_ = _R_~TF~; this is the identification made in the proposals under discussion, and Sec. VIII records what changes if a different _L_ is chosen. The monopole (breathing) mode of the isotropic TF condensate has _ω_~B~ = 5^1/2^_ω_~0~, independent of _N_ at leading order — a property we shall use, because it is what makes the mode a candidate precision observable in the first place."));
c.push(P("We shall also make essential use of the dipole (sloshing, or Kohn) mode, the centre-of-mass oscillation of the cloud. For a harmonic external potential and a translationally invariant interaction the centre-of-mass coordinate decouples exactly from the internal dynamics, so that _ω_~D~ = _ω_~0~ exactly, for any _N_, any _a_ and any _T_. This is Kohn's theorem [10], originally derived for cyclotron resonance in an interacting electron gas and extended to trapped gases as the harmonic-potential theorem [11]. Its content for the present purpose is that the dipole mode is a frequency reference immune to precisely those quantities — interaction strength, atom number, temperature — whose variation limits the breathing mode. We return to this in Sec. VI, where it determines the choice of observable."));

/* ------------------------------------------------------------------ III */
c.push(H1("III. Proposition 1: the screening parameter is the Thomas–Fermi validity parameter"));
c.push(H2("A. Statement"));
c.push(P("*Lemma 1.* For a harmonically trapped condensate in the TF regime, _ξ_(0) _R_~TF~ = _a_~ho~^2^ exactly."));
c.push(P("*Proof.* From Eq. (3), _μ_ = ½_mω_~0~^2^_R_~TF~^2^. Substituting into Eq. (4), _ξ_(0)^2^ = _ħ_^2^/(2_mμ_) = _ħ_^2^/(_m_^2^_ω_~0~^2^_R_~TF~^2^) = _a_~ho~^4^/_R_~TF~^2^. Taking the square root gives the claim. Q.E.D."));
c.push(P("*Proposition 1.* With _L_ = _R_~TF~,"));
c.push(EQ("_η_ = (_ξ_(0)/_R_~TF~)^2^ = (_a_~ho~/_R_~TF~)^4^ = (15_Na_/_a_~ho~)^−4/5^,", "(5)"));
c.push(P("and therefore"));
c.push(EQ("_Na_/_a_~ho~ = _η_^−5/4^ / 15.", "(6)"));
c.push(P("*Proof.* Immediate from Lemma 1 and Eq. (3). Q.E.D."));

c.push(H2("B. Consequences"));
c.push(P("Equation (6) is an identity, not an estimate. Its content is that the parameter controlling the proposed screening and the parameter controlling the validity of the Thomas–Fermi approximation are the same number in different clothing. The TF approximation requires _Na_/_a_~ho~ ≫ 1 [12]; the hydrodynamic collective-mode spectrum, which is the observable channel, inherits that requirement. Table I evaluates Eq. (6)."));
c.push(TBL(
  ["_η_", "_Na_/_a_~ho~", "_ξ_/_R_~TF~", "Regime"],
  [
    ["10^−4^", "6.7 × 10^3^", "0.010", "deep TF"],
    ["10^−3^", "3.7 × 10^2^", "0.032", "TF valid"],
    ["10^−2^", "21.1", "0.100", "TF marginal"],
    ["5 × 10^−2^", "2.8", "0.224", "TF invalid"],
    ["10^−1^", "1.19", "0.316", "TF invalid"],
    ["0.5", "0.16", "0.707", "near-ideal gas"],
    ["1.0", "0.07", "1.000", "ideal gas, _N_ ~ 10 atoms"],
  ],
  [1600, 2200, 1800, 3000]));
c.push(CAPTION("*TABLE I.* The screening parameter _η_ against the Thomas–Fermi validity parameter _Na_/_a_~ho~, from Eq. (6). The two columns are not independent: fixing one fixes the other. The regime labels follow the standard requirement _Na_/_a_~ho~ ≫ 1 for the Thomas–Fermi profile and for the hydrodynamic mode spectrum of Ref. [1]."));
c.push(P("Three points follow."));
c.push(BULLET("*The strong-screening limit is not a limit of the theory.* Setting _η_ → 1 requires _Na_/_a_~ho~ ≈ 0.07, i.e. of order ten atoms for ^87^Rb in a 100 Hz trap. In that regime the condensate is in the ideal-gas limit, the TF profile does not exist, the hydrodynamic equations do not apply, and the collective spectrum reverts to the non-interacting values _ω_ = _ω_~0~(2_n_ + _l_), which are protected. Extrapolating Eq. (1) to _η_ → 1 is therefore not merely bold; it evaluates a formula outside the domain on which it was derived."));
c.push(BULLET("*The bound is universal.* Both _a_ and _a_~ho~ cancel from Eq. (6). No choice of atomic species, no Feshbach tuning of _a_ [13], and no choice of trap frequency alters Table I. We verified this explicitly for ^39^K at _a_ = 100_a_~0~, 10_a_~0~ and 1_a_~0~: the atom numbers required for a given _η_ change by orders of magnitude, but the column _Na_/_a_~ho~ is reproduced digit for digit."));
c.push(BULLET("*The defensible ceiling is _η_ ≈ 10^−2^.* At _η_ = 10^−2^ one has _Na_/_a_~ho~ ≈ 21, which is the outer edge of the TF regime; corrections to the mode frequencies are then themselves of order 10 per cent and the linear-response treatment of Eq. (1) is questionable. Claims restricted to _η_ ≲ 10^−2^ are internally consistent; claims that rely on _η_ approaching unity are not."));
c.push(P("We stress that this is a constraint on the harmonic trap specifically. Section VIII.C notes that in a uniform (box) potential _ξ_ and _L_ are set by independent physical quantities and the lock of Eq. (6) is broken; that geometry is analysed separately."));

/* ------------------------------------------------------------------- IV */
c.push(H1("IV. Proposition 2: exact degeneracy with the finite-size correction"));
c.push(H2("A. The known correction"));
c.push(P("The hydrodynamic result of Ref. [1] neglects the quantum-pressure term. Its leading correction was estimated by Stringari using sum rules and computed systematically by Braaten and Pearson [5], and by Dalfovo _et al._ [6] for the non-linear dynamics; for the collective frequencies of a trapped condensate the correction enters as a power of the small parameter _a_~ho~/_R_~TF~, with the leading term of relative order"));
c.push(EQ("(_δω_/_ω_)~FS~ = _c_~FS~ (_a_~ho~/_R_~TF~)^4^ [1 + _O_(ln(_R_~TF~/_a_~ho~))],", "(7)"));
c.push(P("where _c_~FS~ is a mode-dependent number of order unity and the logarithm is present for some mode families. The essential point for what follows is the power, not the prefactor."));

c.push(H2("B. Statement"));
c.push(P("*Proposition 2.* Let a screening mechanism of the form (1) produce a first-order frequency shift (_δω_/_ω_)~scr~ = _c_~scr~ _η_. Then by Proposition 1"));
c.push(EQ("(_δω_/_ω_)~scr~ = _c_~scr~ (_a_~ho~/_R_~TF~)^4^,", "(8)"));
c.push(P("so that the measured shift is"));
c.push(EQ("(_δω_/_ω_)~tot~ = (_c_~FS~ + _c_~scr~)(_a_~ho~/_R_~TF~)^4^ + (higher order).", "(9)"));
c.push(P("The two contributions have identical dependence on _N_, on _a_, on _ω_~0~ and on atomic species. They differ only in the dimensionless prefactor. Q.E.D."));

c.push(H2("C. Consequences"));
c.push(P("*Corollary 1 (no single-configuration test).* No measurement performed on a single harmonic-trap configuration, and no scan of _N_, _a_ or _ω_~0~ within the harmonic-trap family, can separate _c_~scr~ from _c_~FS~. Scanning _N_ changes _η_ as _N_^−4/5^, but it changes both terms by the same factor; the two are collinear in every accessible direction of parameter space."));
c.push(P("*Corollary 2 (what a test requires).* A test of a first-order screening term in a harmonic trap requires either (i) an independent theoretical determination of _c_~FS~ to accuracy better than the claimed _c_~scr~, or (ii) an additional experimental variable on which _c_~FS~ and _c_~scr~ depend differently. Route (i) is a demanding but well-posed numerical problem, since _c_~FS~ is a property of the GP equation alone and can be extracted from high-accuracy Bogoliubov–de Gennes computation. Route (ii) is the subject of Sec. VII."));
c.push(P("This degeneracy is, in our view, the single most consequential structural fact about the programme. It is not a statement that the screening effect is absent. It is a statement that the most natural experimental signature of the effect has been pre-empted by a term that Gross–Pitaevskii theory already predicts, and that any claim of observation must therefore be a claim about a numerical coefficient rather than about a scaling law. Claims about scaling laws are robust; claims about coefficients are not, and are correspondingly harder to defend."));

/* ------------------------------------------------------------------- V */
c.push(H1("V. Quantitative budget for a standard ^87^Rb condensate"));
c.push(P("We evaluate the reference configuration used in the proposals: ^87^Rb, _a_ = 5.3 nm, _N_ = 10^5^, isotropic trap at _ω_~0~/2_π_ = 100 Hz. Equations (3)–(5) give _a_~ho~ = 1.078 μm, _R_~TF~ = 6.399 μm, _ξ_(0) = 0.182 μm, _η_ = 8.05 × 10^−4^, _n_(0) = 2.28 × 10^14^ cm^−3^, _μ_/_h_ = 1.76 kHz, and _n_(0)_a_^3^ = 3.39 × 10^−5^. The breathing mode sits at _ω_~B~/2_π_ = 5^1/2^ × 100 Hz = 223.6 Hz; the identities used are standard [14]. Table II collects the contributions."));
c.push(TBL(
  ["Contribution", "Relative", "Absolute (mHz)", "Ratio to 1.5 mHz"],
  [
    ["Screening at _δω_/_ω_ = _η_", "8.05 × 10^−4^", "180.0", "120"],
    ["Screening at quoted 1.5 mHz", "6.71 × 10^−6^", "1.50", "1"],
    ["Finite size, Eq. (7), _c_~FS~ ~ 1", "8.05 × 10^−4^", "180.0", "120"],
    ["Lee–Huang–Yang, ~ (_n_(0)_a_^3^)^1/2^", "5.82 × 10^−3^", "1302", "870"],
    ["Thermal at _T_/_T_~c~ = 0.5", "~10^−2^", "2236", "1490"],
  ],
  [3400, 1700, 1700, 1800]));
c.push(CAPTION("*TABLE II.* Contributions to the breathing-mode frequency of a ^87^Rb condensate with _N_ = 10^5^ at _ω_~0~/2_π_ = 100 Hz, _ω_~B~/2_π_ = 223.6 Hz. The Lee–Huang–Yang entry uses the scaling of Refs. [7,8] with prefactor of order unity; the thermal entry uses the measured per-cent-level shifts of Ref. [9]. Rows 1 and 3 are the degenerate pair of Proposition 2."));
c.push(P("Two observations. First, the quoted target of 1.5 mHz corresponds to a relative shift of 6.7 × 10^−6^, which is a factor 0.008 of _η_. A manuscript quoting that number should state the prefactor explicitly, because a reader who forms _ηω_~B~ obtains 180 mHz and will read the discrepancy as an error. Second, the target sits a factor 870 below the beyond-mean-field background and a factor 1490 below a realistic thermal background. Since the present agreement between theory and experiment for collective modes is at the 10^−3^–10^−2^ level, the required control is between 150 and 1500 times better than the state of the art."));

/* ------------------------------------------------------------------ VI */
c.push(H1("VI. The observable is a ratio, not a frequency"));
c.push(H2("A. Why the ratio"));
c.push(P("The budget of Table II is written for an absolute frequency, and in that form it understates what is achievable, because it treats the trap frequency as an externally calibrated quantity. It need not be. By Kohn's theorem the dipole mode of the same cloud oscillates at exactly _ω_~0~, and it does so independently of _N_, of _a_ and of _T_ [10,11]. Measuring both modes on the same atoms in the same realization therefore supplies an internal frequency reference that is protected by a theorem rather than by an instrument."));
c.push(P("We accordingly take as the observable"));
c.push(EQ("_ω_~B~/_ω_~D~ = 5^1/2^ [1 + _c_~FS~_η_ + _c_~scr~_η_ + _c_~LHY~(_n_(0)_a_^3^)^1/2^ + _c_~T~ _f_(_T_/_T_~c~) + …],", "(10)"));
c.push(P("whose Thomas–Fermi value 5^1/2^ contains no adjustable parameter. Three properties follow."));
c.push(BULLET("*Trap calibration cancels identically, not approximately.* Any error or drift in _ω_~0~ — from optical power fluctuation, from magnetic-field drift, from an imperfect independent calibration — enters numerator and denominator equally and leaves Eq. (10) untouched. This is a cancellation to all orders, not a first-order suppression, and it removes a line from the budget rather than shrinking it."));
c.push(BULLET("*Interaction and temperature do not cancel.* The dipole mode is immune to them; the breathing mode is not. The Lee–Huang–Yang and thermal contributions therefore survive in Eq. (10) at full size. The ratio is a calibration device, not a background-subtraction device, and it does nothing whatever to the degeneracy of Proposition 2, which is a statement about theory and not about instrumentation."));
c.push(BULLET("*A new systematic is promoted to the top.* Kohn's theorem holds for a harmonic potential. Real potentials are not harmonic, and anharmonicity shifts the sloshing mode by an amount that depends on _N_, _T_ and _a_ [15] — that is, it destroys the very immunity the construction relies on. Having removed the previous leading systematic, we must confront this one, and Sec. VI.C shows that it dictates the choice of apparatus."));

c.push(H2("B. What remains in the statistical budget"));
c.push(P("It is worth establishing which resource is actually scarce, because the intuition that a millihertz shift on a hundred-hertz mode is beyond reach is wrong. The frequency resolution of a single realization is set by the Fourier limit of the observation window _T_~obs~, _δf_ ≈ 1/(2_πT_~obs~), improved by the signal-to-noise ratio _S_ and by averaging over _N_~sh~ realizations:"));
c.push(EQ("_δω_/_ω_ ≈ 1 / (_Q_~eff~ _S_ _N_~sh~^1/2^),   _Q_~eff~ = _ωT_~obs~ or _ω_/_Γ_,", "(11)"));
c.push(P("whichever is smaller, with _Γ_ the damping rate, which at low temperature is set by Beliaev and Landau processes [16] and requires the sample to be deep in the collisionless-hydrodynamic regime characterized in Ref. [17]. Table III evaluates the requirement for the ratio observable."));
c.push(TBL(
  ["Resource", "Requirement for 6.7 × 10^−6^", "Present capability", "Verdict"],
  [
    ["Realizations, _Q_~eff~ = 10^3^, _S_ = 30", "25 shots (≈ 12 min)", "routine", "not binding"],
    ["Realizations, _Q_~eff~ = 10^2^, _S_ = 30", "2.5 × 10^3^ shots (≈ 21 h)", "demanding but feasible", "not binding"],
    ["Trap-frequency stability", "none", "—", "*removed by Eq. (10)*"],
    ["Atom-number reproducibility", "_δN_/_N_ < 1.0 %", "0.1–1 % with feedback", "achievable"],
    ["Trap anharmonicity", "waist > 2.5 mm, or extrapolation", "not met by optical traps", "*binding*"],
    ["Temperature reproducibility", "_δ_(_T_/_T_~c~) < 2 × 10^−4^", "~10^−2^ typical", "*binding*"],
    ["Knowledge of GP background", "_c_~FS~ to < 1 %", "not established", "*binding*"],
  ],
  [3000, 2200, 2200, 1400]));
c.push(CAPTION("*TABLE III.* Resource budget for resolving a relative shift of 6.7 × 10^−6^ in the ratio _ω_~B~/_ω_~D~. The atom-number line uses the fact that _ω_~B~/_ω_~0~ is _N_-independent at leading Thomas–Fermi order, so that _N_ enters only through _η_ ∝ _N_^−4/5^, giving _δN_/_N_ < (5/4)(_δω_/_ω_)~target~/_η_. Compared with an absolute-frequency measurement, the trap-stability line is removed identically and the anharmonicity line takes its place."));

c.push(H2("C. Trap anharmonicity, and why the apparatus must be magnetic"));
c.push(P("A Gaussian optical dipole trap of waist _w_~0~ has, on expansion of the beam profile,"));
c.push(EQ("_V_(_r_) = ½_mω_~0~^2^_r_^2^ (1 − _r_^2^/_w_~0~^2^) + _O_(_r_^6^).", "(12)"));
c.push(P("Both coefficients can be computed in closed form for a Thomas–Fermi cloud, and we do so in Appendix B. Writing _u_~0~ = −(_R_~TF~/_w_~0~)^2^, the monopole frequency follows from the _m_~1~/_m_~−1~ sum rule applied to the operator Σ_r_~_i_~^2^, which is legitimate here because the perturbation conjugate to that operator changes only the harmonic coefficient and leaves the quartic term fixed. The result is"));
c.push(EQ("(_δω_/_ω_)~B~ = −(7/9)(_R_~TF~/_w_~0~)^2^,", "(13)"));
c.push(P("verified against a direct numerical evaluation of the Thomas–Fermi profile in the quartic trap, which reproduces the coefficient to five digits at _u_~0~ = −10^−4^ and to better than 0.6 % at _u_~0~ = −10^−2^. The dipole mode is obtained by expanding the potential about the centre-of-mass coordinate: the terms linear and cubic in the internal coordinates average to zero for a symmetric cloud, and the surviving quadratic term gives _ω_~D~^2^ = _ω_~0~^2^[1 − 6⟨_x_^2^⟩/_w_~0~^2^]. With ⟨_x_^2^⟩ = ⟨_r_^2^⟩/3 = _R_~TF~^2^/7 for the Thomas–Fermi profile,"));
c.push(EQ("(_δω_/_ω_)~D~ = −(3/7)(_R_~TF~/_w_~0~)^2^ − 3_A_~osc~^2^/4_w_~0~^2^,", "(14)"));
c.push(P("the second term being the Duffing shift at sloshing amplitude _A_~osc~. The two static coefficients differ, so the anharmonicity does not cancel in the ratio — but it partially cancels, and the residual coefficient is"));
c.push(EQ("_c_~an~ = 7/9 − 3/7 = 22/63 = 0.3492…", "(15)"));
c.push(P("This is a genuine, if modest, protection: the ratio suppresses the anharmonic systematic by a factor 63/22 = 2.86 relative to the breathing frequency taken alone, for the same structural reason that it suppresses trap calibration — the two modes sample the same anharmonic potential, merely with different weights. Table IV evaluates the residual at the reference configuration, where _R_~TF~ = 6.40 μm."));
c.push(TBL(
  ["_w_~0~", "(_R_~TF~/_w_~0~)^2^", "_c_~an~(_R_~TF~/_w_~0~)^2^", "Ratio to target", "Relative optical power"],
  [
    ["50 μm", "1.64 × 10^−2^", "5.72 × 10^−3^", "853", "1"],
    ["100 μm", "4.09 × 10^−3^", "1.43 × 10^−3^", "213", "16"],
    ["300 μm", "4.55 × 10^−4^", "1.59 × 10^−4^", "23.7", "1.3 × 10^3^"],
    ["1 mm", "4.09 × 10^−5^", "1.43 × 10^−5^", "2.1", "1.6 × 10^5^"],
    ["1.5 mm", "1.82 × 10^−5^", "6.36 × 10^−6^", "0.95", "8.1 × 10^5^"],
    ["3 mm", "4.55 × 10^−6^", "1.59 × 10^−6^", "0.24", "1.3 × 10^7^"],
  ],
  [1100, 1900, 2100, 1500, 2100]));
c.push(CAPTION("*TABLE IV.* Residual anharmonic contribution to the ratio _ω_~B~/_ω_~D~ for a Gaussian optical dipole trap of waist _w_~0~ at the reference configuration (^87^Rb, _N_ = 10^5^, _ω_~0~/2_π_ = 100 Hz, _R_~TF~ = 6.40 μm), using the computed coefficient _c_~an~ = 22/63 of Eq. (15). The fourth column compares to the target relative resolution 6.7 × 10^−6^. The last column gives the optical power required relative to a 50 μm trap: at fixed _ω_~0~ the trap depth scales as _w_~0~^2^ and the power as _w_~0~^4^, which is the practical limit on this axis."));
c.push(P("Brute-force suppression requires _w_~0~ > _R_~TF~(_c_~an~/6.7 × 10^−6^)^1/2^ = 1.46 mm — an improvement on the 2.47 mm that the naive choice _c_~an~ = 1 would have given, but not a decisive one. At fixed trap frequency the required optical power scales as _w_~0~^4^, so a 1.5 mm waist costs some 8 × 10^5^ times the power of a conventional 50 μm trap, which closes that route."));
c.push(P("The computed coefficient, however, changes the character of the constraint. Because Eqs. (13)–(15) are exact for a Thomas–Fermi cloud in a quartic trap, the anharmonic term is a correction to be subtracted rather than a floor to be suppressed, and the binding quantity is its *uncertainty*. Since the shift scales as _R_~TF~^2^/_w_~0~^2^ and _R_~TF~ ∝ _N_^1/5^, the fractional error propagates as 2_δw_~0~/_w_~0~ + (2/5)_δN_/_N_. Table V translates this into requirements."));
c.push(TBL(
  ["_w_~0~", "Shift must be known to", "_δw_~0~/_w_~0~", "_δN_/_N_", "Verdict"],
  [
    ["50 μm", "0.12 %", "0.03 %", "0.15 %", "out of reach"],
    ["100 μm", "0.47 %", "0.12 %", "0.59 %", "very demanding"],
    ["300 μm", "4.2 %", "1.1 %", "5.3 %", "*feasible*"],
    ["600 μm", "17 %", "4.2 %", "21 %", "comfortable"],
  ],
  [1200, 2400, 1800, 1600, 1800]));
c.push(CAPTION("*TABLE V.* Knowledge required of the anharmonic shift for its residual uncertainty to fall below the target, and the corresponding tolerances on waist and atom number. The 300 μm row is the practical optimum: a 1 % waist calibration is routine beam profiling and a 5 % atom-number calibration is undemanding, at a power cost of some 1.3 × 10^3^ relative to a conventional trap — large but not prohibitive with a fibre-laser source."));
c.push(P("The corrected conclusion is therefore weaker than the one _c_~an~ = 1 suggested, and more useful. An all-optical apparatus is not excluded; it requires a waist of roughly 300 μm together with an independent characterization of the beam profile at the per-cent level, and it pays for this in optical power rather than in principle."));
c.push(H2("D. The magnetic route, quantified"));
c.push(P("It is tempting to assert that a magnetic trap solves the problem because its curvature is set by coil geometry on the centimetre scale. For the axial direction of an Ioffe–Pritchard trap this is correct and the margin is enormous: with a coil scale _d_ = 1 cm the residual is _c_~an~(_R_~TF~/_d_)^2^ = 1.4 × 10^−7^, some fifty times below target. For the radial direction it is false, and the relevant length is much shorter than the apparatus."));
c.push(P("Expanding the modulus of the Ioffe–Pritchard field, |**B**(_ρ_)| = (_B_~0~^2^ + _B_′^2^_ρ_^2^)^1/2^ = _B_~0~[1 + (_B_′_ρ_/_B_~0~)^2^/2 − (_B_′_ρ_/_B_~0~)^4^/8 + …], and taking _U_ = _μ_|**B**| with _μ_ the effective magnetic moment, the quadratic and quartic coefficients give ½_mω_~0~^2^ = _μB_′^2^/2_B_~0~ and −_μB_′^4^/8_B_~0~^3^. Writing the result in the form of Eq. (12) identifies an effective anharmonic length"));
c.push(EQ("_w_~eff~ = 2_B_~0~/_B_′ = 2(_μB_~0~/_mω_~0~^2^)^1/2^,", "(16)"));
c.push(P("in which the coil geometry does not appear at all. The scale is set by the bias field, and it grows only as _B_~0~^1/2^. Table VI evaluates it for ^87^Rb in |_F_ = 2, _m_~_F_~ = 2⟩ at a radial frequency of 100 Hz, the configuration in which the early collective-mode measurements were performed [2,18]."));
c.push(TBL(
  ["_B_~0~ (G)", "_B_′ (G cm^−1^)", "_w_~eff~", "_c_~an~(_R_~TF~/_w_~eff~)^2^", "Ratio to target"],
  [
    ["1", "78", "255 μm", "2.20 × 10^−4^", "32.8"],
    ["3", "136", "442 μm", "7.33 × 10^−5^", "10.9"],
    ["10", "248", "807 μm", "2.20 × 10^−5^", "3.28"],
    ["30", "430", "1.40 mm", "7.33 × 10^−6^", "1.09"],
    ["100", "784", "2.55 mm", "2.20 × 10^−6^", "0.33"],
  ],
  [1200, 1900, 1400, 2200, 1700]));
c.push(CAPTION("*TABLE VI.* Radial anharmonicity of an Ioffe–Pritchard trap for ^87^Rb at _ω_~0~/2_π_ = 100 Hz, from Eq. (16). The gradient is fixed by the frequency requirement, _B_′ = (_mω_~0~^2^_B_~0~/_μ_)^1/2^. A conventional low-bias trap at _B_~0~ = 1 G is *worse* than a 300 μm optical trap; the brute-force requirement _w_~eff~ > 1.46 mm is met at _B_~0~ > 33 G, which costs a gradient of 449 G cm^−1^."));
c.push(P("Two consequences follow, and neither is what the naive argument predicted. First, a conventional tightly confining magnetic trap operated at a bias of one or two gauss has _w_~eff~ ≈ 250 μm and is therefore *no better* than a large-waist optical trap; the magnetic apparatus confers no automatic advantage. Second, the advantage it does confer is of a different kind. Because _w_~eff~ depends on _B_~0~ and the confinement frequency can be held fixed by adjusting _B_′ simultaneously, the anharmonic length is an in-situ experimental parameter, tunable over an order of magnitude by a bias coil at no cost in laser power. The optical waist is not: it is fixed once the beam is installed, and changing it means rebuilding the trap."));
c.push(P("This converts the anharmonic term from a computable correction into a *measurable* one, which is a stronger position. Recording _ω_~B~/_ω_~D~ at several bias fields and fitting against 1/_w_~eff~^2^ gives a straight line whose intercept is the anharmonicity-free value, without requiring _c_~an~ to be trusted, without requiring the trap profile to be characterized, and without the isotropic idealization of Appendix B. The predicted lever arm is generous: between _B_~0~ = 3 G and 100 G the residual falls from 7.33 × 10^−5^ to 2.20 × 10^−6^, a factor 33, spanning the target by more than an order of magnitude on each side. We regard this extrapolation, rather than brute-force suppression, as the correct use of a magnetic apparatus, and it is the single strongest argument for choosing one."));
c.push(P("The Duffing term imposes a separate and easily overlooked constraint. Requiring 3_A_~osc~^2^/4_w_~0~^2^ below the target gives _A_~osc~ < 0.90 μm at _w_~0~ = 300 μm and _A_~osc~ < 0.30 μm at 100 μm. Since _a_~ho~ = 1.08 μm at the reference configuration, the sloshing amplitude must be a fraction of the oscillator length, which is a demanding but not unprecedented signal-to-noise requirement on the centre-of-mass tracking. It is also the reason the amplitude series described below is worth running even in a magnetic trap."));
c.push(P("Where a magnetic trap is unavailable, the Kohn-mode contribution remains removable, because it is strictly proportional to _A_^2^: a series at several sloshing amplitudes extrapolated to _A_ → 0 eliminates it without any knowledge of _w_~0~. The breathing-side term is not removable this way, since _R_~TF~ is not a free amplitude; it must either be computed from an independently measured potential or suppressed by geometry. This asymmetry between the two modes is, in our view, the practical reason to regard the anharmonicity line of Table III as binding rather than merely inconvenient."));

c.push(H2("E. What the ratio does not do"));
c.push(P("We state this explicitly because it is the natural place to overclaim. Equation (10) improves the instrumental budget and leaves the physics unchanged. Proposition 2 is untouched: _c_~FS~ and _c_~scr~ appear in Eq. (10) in the same combination and with the same power of _η_ as before, and the ratio provides no lever on either. The thermal and beyond-mean-field terms of Table II survive at full size. What the construction buys is that the measurement is no longer limited by an instrument whose stability one must argue for, and is instead limited by physics one can compute — which is the correct place for a limit to sit, and the reason to adopt the ratio even though it resolves nothing about the degeneracy."));

/* ----------------------------------------------------------------- VII */
c.push(H1("VII. A differential protocol with the vortex charge as discriminant"));
c.push(H2("A. Design principle"));
c.push(P("Corollary 2 requires a variable on which _c_~FS~ and _c_~scr~ depend differently. The vortex charge is the natural candidate, for a structural reason: the finite-size correction is a property of the density profile and its curvature, whereas a screening mechanism built on macroscopic phase coherence is, by construction, sensitive to the phase. Imprinting a singly quantized vortex, _Ψ_(_r_,_φ_,_z_) = _f_(_r_) e^_iφ_^, changes the phase field by a topologically protected amount while changing the density profile only within a core of radius of order _ξ_."));
c.push(P("The proposed observable is the double difference of the ratio of Eq. (10)"));
c.push(EQ("Δ = [(_ω_~B~/_ω_~D~)~_n_=1~ − (_ω_~B~/_ω_~D~)~_n_=0~]~exp~ − [(_ω_~B~/_ω_~D~)~_n_=1~ − (_ω_~B~/_ω_~D~)~_n_=0~]~GP~,", "(17)"));
c.push(P("in which the second bracket is computed from the Gross–Pitaevskii equation with the same trap and atom number. Thermal and trap-calibration systematics that are common to the two vortex states cancel in the first bracket; the GP finite-size background cancels against the second. What survives is precisely _c_~scr~ weighted by whatever phase sensitivity the mechanism possesses."));

c.push(H2("B. Why the quadrupole splitting is not the observable"));
c.push(P("It is tempting to use the well-known quadrupole splitting as the vortex diagnostic. For a single vortex the _m_ = ±2 modes split by _δω_ = 2⟨_L̂_~_z_~⟩/(_m_⟨_r_~⊥~^2^⟩), which for the reference configuration is 19.9 Hz, or 1.4 × 10^−1^ in relative terms [19]. That is a factor 1.3 × 10^4^ larger than the target shift. The splitting is therefore an excellent means of confirming that a vortex is present — its original purpose [19,20] — but it is not a channel in which a screening term could be seen: it is dominated by standard hydrodynamics by four orders of magnitude. The vortex must be used as a state label, not as an amplifier."));

c.push(H2("C. Protocol"));
c.push(P("The following sequence is what we would propose to an experimental group with an existing ^87^Rb apparatus."));
c.push(BULLET("Prepare a condensate at fixed _N_ with feedback stabilization to _δN_/_N_ ≤ 1 %, and at the lowest achievable _T_/_T_~c~, with the residual thermal fraction measured shot by shot rather than assumed."));
c.push(BULLET("Alternate interleaved runs with and without an imprinted vortex, created by phase imprinting [21] or by stirring [22], on a timescale short compared to laboratory drifts, so that the two vortex states share a common systematic environment. Interleaving, not sequential blocks, is essential."));
c.push(BULLET("Confirm the vortex charge in every shot via the _m_ = ±2 quadrupole splitting, discarding shots where the charge is ambiguous or where the vortex has drifted off axis."));
c.push(BULLET("Use a magnetic trap wherever possible, per Sec. VI.C. In an all-optical apparatus, record the sloshing amplitude shot by shot and plan an amplitude series for the extrapolation _A_ → 0."));
c.push(BULLET("Excite the dipole and breathing modes in the same realization and extract both frequencies from the same time record, so that the reference of Eq. (10) is contemporaneous. Sequential measurement of the two modes forfeits most of the cancellation, since it reinstates drift between the two acquisitions."));
c.push(BULLET("Excite the breathing mode at small amplitude, staying in the linear regime, and extract _ω_~B~ by fitting a damped sinusoid over the full coherent window. Form the ratio _ω_~B~/_ω_~D~ shot by shot rather than averaging the two frequencies separately."));
c.push(BULLET("Compute the experimental double difference of Eq. (17) against a Bogoliubov–de Gennes solution of the same configuration carried to a relative accuracy better than 10^−6^, with the vortex included, and with the LHY term inserted at the level of Refs. [7,8]."));
c.push(BULLET("Report Δ with its full error budget. A null result at the 10^−6^ level is a meaningful constraint and should be published as such."));

c.push(H2("D. Falsifiable outcomes"));
c.push(P("The protocol has three distinguishable outcomes, which we state in advance."));
c.push(TBL(
  ["Outcome", "Interpretation"],
  [
    ["Δ consistent with zero at 10^−6^", "First-order screening excluded at _c_~scr~ ≲ 10^−3^; the proposals of the form (1) are constrained, not refuted, since the mechanism may be phase-insensitive"],
    ["Δ non-zero, independent of _n_", "Not a phase-sensitive screening term; most likely an unmodelled GP or thermal contribution — treat as a systematic to be identified"],
    ["Δ non-zero, scaling with _n_ and with _η_ ∝ _N_^−4/5^", "Consistent with a phase-coupled screening term; the only outcome that supports the proposal, and the only one for which a follow-up over the accessible _η_ range is warranted"],
  ],
  [3200, 5600]));
c.push(CAPTION("*TABLE VII.* Pre-registered interpretation of the three possible outcomes of the differential protocol. Fixing the interpretation before the measurement is what makes the protocol a test rather than a search."));

/* ---------------------------------------------------------------- VIII */
c.push(H1("VIII. Assumptions, limitations and open items"));
c.push(H2("A. What has been assumed"));
c.push(P("Proposition 1 assumes _L_ = _R_~TF~. If the coherence scale is instead an externally imposed length larger than the cloud, _η_ is smaller and the bound tightens. If it is a sub-cloud scale, _η_ is larger, but then the physical argument that motivates Eq. (1) — suppression over the region of macroscopic coherence — must be restated, since the coherence region and the screening region no longer coincide. We regard the identification _L_ = _R_~TF~ as the only one for which Eq. (1) has its stated motivation, but this should be made explicit in any application."));
c.push(P("Proposition 2 assumes that the screening term enters linearly in _η_. A mechanism entering at _O_(_η_^2^) or with a logarithmic enhancement would not be degenerate; establishing which is the case requires the microscopic derivation, not the phenomenological form (1)."));

c.push(H2("B. What is not claimed"));
c.push(P("We do not claim that mechanisms of the form (1) are wrong. Proposition 1 restricts their domain; Proposition 2 restricts their observability in one channel. Neither is a statement about the underlying physics. We also do not claim that the numerical prefactors _c_~FS~ and _c_~scr~ coincide — only that their scalings do, which is what defeats a scaling-based measurement."));

c.push(H2("C. The uniform-potential escape route"));
c.push(P("The lock of Eq. (6) is a property of the harmonic trap, where the density profile and the confinement length are both determined by _ω_~0~ and _N_. In a uniform (box) potential [23,24] the healing length is set by the density and scattering length, _ξ_ = (8_πna_)^−1/2^, while _L_ is set by the box walls, and the two are independent. The diluteness parameter _na_^3^ and the screening parameter _η_ = (_ξ_/_L_)^2^ then decouple: for example _n_ = 10^13^ cm^−3^ and _L_ = 2.7 μm give _η_ ≈ 0.1 at _na_^3^ ≈ 1.5 × 10^−6^, a combination unreachable in any harmonic trap. This is, in our assessment, the principal constructive consequence of Proposition 1, and it is developed separately."));

c.push(H2("D. A trade-off that no single geometry resolves"));
c.push(P("Sections VI and VIII.C point in opposite directions, and the tension is worth stating plainly rather than leaving for a referee to find. The Kohn reference of Eq. (10) exists because the confinement is harmonic: the centre-of-mass mode decouples only for a quadratic external potential, and in a uniform box there is no such mode and hence no protected frequency reference. Conversely, the degeneracy of Proposition 2 is lifted only when _η_ can be varied independently of the diluteness, which requires the uniform geometry. The two remedies are therefore mutually exclusive at the level of the apparatus."));
c.push(TBL(
  ["Geometry", "Kohn frequency reference", "Degeneracy of Proposition 2", "Internal calibration available"],
  [
    ["Harmonic trap", "yes, exact (Eq. 10)", "present, unliftable", "the reference itself"],
    ["Uniform box", "absent", "lifted by mode index", "the mode-index slope"],
  ],
  [2100, 2600, 2400, 2500]));
c.push(CAPTION("*TABLE VIII.* The trade-off between the two geometries. Neither delivers both properties; each supplies a different internal calibration in place of the missing one."));
c.push(P("The resolution is not to choose but to note that each geometry carries its own internal calibration. In the harmonic trap the calibration is the Kohn mode, which fixes the frequency scale but leaves the degeneracy intact. In the uniform box the calibration is the mode-index slope, whose value is fixed by Bogoliubov theory with no free parameter, and which fixes the degeneracy while leaving the frequency scale to be established by other means. The two experiments are therefore complementary rather than competing, and a null result in one does not subsume a null result in the other. If only one can be attempted, we would place the harmonic-trap measurement first, because its systematic budget is the better understood of the two and because its by-product — the first determination of the finite-size coefficient — does not depend on the outcome."));
c.push(H2("D. Open items"));
c.push(BULLET("The prefactor _c_~FS~ for the monopole mode of a spherical condensate, with and without a vortex, is not available at the accuracy required by Eq. (17). This is a well-defined and self-contained Bogoliubov–de Gennes computation and is the immediate next step."));
c.push(BULLET("The phase sensitivity of the mechanism — whether _c_~scr~ depends on the winding number at all — cannot be decided from Eq. (1) alone. If it does not, the vortex discriminant fails and the protocol of Sec. VII must be replaced by the geometry route of Sec. VIII.C."));
c.push(BULLET("The thermal correction has been treated as a common-mode systematic. Whether it truly cancels between _n_ = 0 and _n_ = 1 configurations, given that a vortex modifies the low-lying spectrum and hence the thermal occupation, requires a finite-temperature treatment."));

/* ------------------------------------------------------------------ IX */
c.push(H1("IX. Conclusion"));
c.push(P("We have established two constraints on the experimental programme associated with screening-type corrections of the form _κ_~eff~ = _κ_~0~(1 − _η_) in trapped Bose–Einstein condensates, both following from Thomas–Fermi identities rather than from any microscopic model."));
c.push(P("First, in a harmonic trap the screening parameter is not an independent knob: _Na_/_a_~ho~ = _η_^−5/4^/15 ties it algebraically to the validity parameter of the very approximation used to derive the prediction. The regime _ξ_ → _L_, which the analogy with the Meissner effect makes rhetorically attractive, corresponds to _Na_/_a_~ho~ ≈ 0.07 and lies deep in the ideal-gas limit where neither the Thomas–Fermi profile nor the hydrodynamic mode spectrum exists. The bound survives every experimental lever: species, trap frequency and Feshbach tuning of the scattering length all cancel identically. The largest internally consistent value is _η_ ≈ 10^−2^, and we recommend that claims be restricted accordingly."));
c.push(P("Second, because _η_ = (_a_~ho~/_R_~TF~)^4^, a screening term entering at first order in _η_ has exactly the scaling of the leading finite-size correction already contained in Gross–Pitaevskii theory. The two are collinear in _N_, in _a_, in _ω_~0~ and in atomic species, and are distinguished only by a dimensionless prefactor. No scan within the harmonic-trap family can separate them."));
c.push(P("Quantitatively, for the standard ^87^Rb reference configuration the beyond-mean-field and thermal backgrounds exceed a 1.5 mHz target by factors of 870 and 1490, requiring control between 150 and 1500 times better than the present state of the art. The scarce resource, however, is not counting statistics: 25 realizations suffice at _Q_~eff~ = 10^3^ and _S_ = 30."));
c.push(P("We have further argued that the observable should be the ratio _ω_~B~/_ω_~D~ rather than the breathing frequency itself. Kohn's theorem guarantees that the dipole mode of the same cloud oscillates at exactly the trap frequency, independently of atom number, interaction and temperature, so the ratio carries a frequency reference protected by a theorem and measured contemporaneously on the same atoms; its Thomas–Fermi value 5^1/2^ is parameter-free. Trap calibration and drift then cancel identically rather than approximately, and the corresponding line leaves the error budget altogether. The construction changes nothing about the physics — the beyond-mean-field and thermal terms survive at full size, and Proposition 2 is untouched — but it moves the limiting constraint from an instrument whose stability must be argued for to a quantity that can be computed, which is where a limit belongs."));
c.push(P("The systematic promoted into the vacated position is trap anharmonicity, and it is not a minor one, because it shifts the Kohn mode itself by an amount depending on _N_, _T_ and _a_, thereby attacking the immunity the construction relies on. We have computed the two coefficients rather than estimating them, and the result changes the conclusion twice over. The breathing mode shifts by −(7/9)(_R_~TF~/_w_~0~)^2^ and the dipole mode by −(3/7)(_R_~TF~/_w_~0~)^2^, so the ratio retains _c_~an~ = 22/63 and suppresses the anharmonic systematic by a factor 2.86 — a second benefit of the same construction, arising because both modes sample the same anharmonic potential with different weights. Brute-force suppression would require a 1.46 mm waist, and since the power scales as _w_~0~^4^ at fixed trap frequency this is not available. But the coefficient is exact, which makes the shift a correction to be subtracted rather than a floor to be suppressed, and the binding quantity is its uncertainty: a 300 μm waist with the beam profiled to 1 % and the atom number known to 5 % places the residual below target at a power cost of order 10^3^. An all-optical apparatus is therefore not excluded, which the uncomputed coefficient had appeared to suggest. The magnetic alternative required correcting a claim we had made on intuition. The radial anharmonic length of an Ioffe–Pritchard trap is _w_~eff~ = 2(_μB_~0~/_mω_~0~^2^)^1/2^, in which the coil geometry does not appear; a conventional low-bias trap therefore has _w_~eff~ ≈ 255 μm and is no better than a large-waist optical trap, contrary to the appeal to centimetre-scale curvature. Only the axial direction is protected in that way. What the magnetic apparatus does supply is that _w_~eff~ scales as _B_~0~^1/2^ and can be varied in situ at fixed confinement frequency, whereas an optical waist is fixed once the beam is installed. This makes the anharmonic term measurable rather than computable: a scan across _B_~0~ = 3–100 G moves the residual by a factor 33 and permits extrapolation in 1/_w_~eff~^2^ to the anharmonicity-free intercept, with no reliance on _c_~an~, on the trap profile, or on the isotropic idealization. We regard that extrapolation as the correct use of a magnetic trap and as the strongest reason to prefer one. Separately, the Duffing term restricts the sloshing amplitude to below 0.90 μm at a 300 μm waist — a fraction of the oscillator length, and the reason to run the amplitude series even when the static term is under control."));
c.push(P("What remains binding after all of this is the reproducibility of the thermal fraction and the absence of a sufficiently accurate Gross–Pitaevskii background."));
c.push(P("Both binding constraints are addressed by differencing rather than by absolute measurement, and we have specified a protocol in which the vortex charge serves as the discriminating variable, with the double difference of Eq. (17) as the observable and three pre-registered outcomes. We note explicitly that the well-known _m_ = ±2 quadrupole splitting, though four orders of magnitude larger than the target shift, must be used as a state label and not as an amplifier."));
c.push(P("Finally, we record what we regard as the most useful by-product of Proposition 1, together with the limitation attached to it. Because the lock between _η_ and _na_^3^ is a property of harmonic confinement and not of Bose–Einstein condensation, it is broken in a uniform potential, where the screening parameter can be raised by two orders of magnitude at fixed diluteness. That geometry, however, has no Kohn mode and therefore no protected frequency reference, so the two remedies developed here are mutually exclusive at the level of the apparatus: harmonic confinement supplies the reference and carries the degeneracy, uniform confinement lifts the degeneracy and forfeits the reference. Each supplies a different internal calibration in place of the missing one, and the two measurements are complementary rather than competing. An apparatus capable of the measurement described here would also deliver, independently of the outcome, the first determination of the finite-size correction coefficient to the collective spectrum — a prediction of Gross–Pitaevskii theory that has been available for a quarter of a century and has never been measured. We consider that this second deliverable, which does not depend on the correctness of any screening proposal, is what makes the experiment worth performing."));

/* ------------------------------------------------------------- BACK MATTER */
c.push(H1("Acknowledgments"));
c.push(P("The author thanks colleagues at the Faculty of Physics, M. V. Lomonosov Moscow State University for discussions."));

c.push(H1("Competing interests"));
c.push(P("The author declares no competing interests."));

c.push(H1("Data availability"));
c.push(P("The numerical values reported in Tables I–VIII are generated by elementary evaluation of Eqs. (3)–(17); the evaluation script will be deposited in a public repository on publication. No experimental data were produced or analysed."));

c.push(H1("References"));
const refs = [
  "S. Stringari, Collective excitations of a trapped Bose-condensed gas, Phys. Rev. Lett. *77*, 2360 (1996). DOI: 10.1103/PhysRevLett.77.2360",
  "D. S. Jin, J. R. Ensher, M. R. Matthews, C. E. Wieman and E. A. Cornell, Collective excitations of a Bose-Einstein condensate in a dilute gas, Phys. Rev. Lett. *77*, 420 (1996). DOI: 10.1103/PhysRevLett.77.420",
  "M. Edwards, P. A. Ruprecht, K. Burnett, R. J. Dodd and C. W. Clark, Collective excitations of atomic Bose-Einstein condensates, Phys. Rev. Lett. *77*, 1671 (1996). DOI: 10.1103/PhysRevLett.77.1671",
  "F. Dalfovo, S. Giorgini, L. P. Pitaevskii and S. Stringari, Theory of Bose-Einstein condensation in trapped gases, Rev. Mod. Phys. *71*, 463 (1999). DOI: 10.1103/RevModPhys.71.463",
  "E. Braaten and J. Pearson, Semiclassical corrections to the oscillation frequencies of a trapped Bose-Einstein condensate, Phys. Rev. Lett. *82*, 255 (1999). DOI: 10.1103/PhysRevLett.82.255",
  "F. Dalfovo, C. Minniti, S. Stringari and L. Pitaevskii, Nonlinear dynamics of a Bose condensed gas, Phys. Lett. A *227*, 259 (1997). DOI: 10.1016/S0375-9601(97)00069-8",
  "T. D. Lee, K. Huang and C. N. Yang, Eigenvalues and eigenfunctions of a Bose system of hard spheres and its low-temperature properties, Phys. Rev. *106*, 1135 (1957). DOI: 10.1103/PhysRev.106.1135",
  "L. Pitaevskii and S. Stringari, Elementary excitations in trapped Bose-Einstein condensed gases beyond the mean-field approximation, Phys. Rev. Lett. *81*, 4541 (1998). DOI: 10.1103/PhysRevLett.81.4541",
  "D. S. Jin, M. R. Matthews, J. R. Ensher, C. E. Wieman and E. A. Cornell, Temperature-dependent damping and frequency shifts in collective excitations of a dilute Bose-Einstein condensate, Phys. Rev. Lett. *78*, 764 (1997). DOI: 10.1103/PhysRevLett.78.764",
  "W. Kohn, Cyclotron resonance and de Haas-van Alphen oscillations of an interacting electron gas, Phys. Rev. *123*, 1242 (1961). DOI: 10.1103/PhysRev.123.1242",
  "J. F. Dobson, Harmonic-potential theorem: implications for approximate many-body theories, Phys. Rev. Lett. *73*, 2244 (1994). DOI: 10.1103/PhysRevLett.73.2244",
  "C. J. Pethick and H. Smith, _Bose-Einstein Condensation in Dilute Gases_, 2nd ed. (Cambridge University Press, Cambridge, 2008).",
  "C. Chin, R. Grimm, P. Julienne and E. Tiesinga, Feshbach resonances in ultracold gases, Rev. Mod. Phys. *82*, 1225 (2010). DOI: 10.1103/RevModPhys.82.1225",
  "L. P. Pitaevskii and S. Stringari, _Bose-Einstein Condensation and Superfluidity_ (Oxford University Press, Oxford, 2016).",
  "P.-A. Pantel, D. Davesne, S. Chiacchiera and M. Urban, Trap anharmonicity and sloshing mode of a Fermi gas, Phys. Rev. A *86*, 023635 (2012). DOI: 10.1103/PhysRevA.86.023635",
  "P. O. Fedichev, G. V. Shlyapnikov and J. T. M. Walraven, Damping of low-energy excitations of a trapped Bose-Einstein condensate at finite temperatures, Phys. Rev. Lett. *80*, 2269 (1998). DOI: 10.1103/PhysRevLett.80.2269",
  "D. M. Stamper-Kurn, H.-J. Miesner, S. Inouye, M. R. Andrews and W. Ketterle, Collisionless and hydrodynamic excitations of a Bose-Einstein condensate, Phys. Rev. Lett. *81*, 500 (1998). DOI: 10.1103/PhysRevLett.81.500",
  "M.-O. Mewes, M. R. Andrews, N. J. van Druten, D. M. Kurn, D. S. Durfee, C. G. Townsend and W. Ketterle, Collective excitations of a Bose-Einstein condensate in a magnetic trap, Phys. Rev. Lett. *77*, 988 (1996). DOI: 10.1103/PhysRevLett.77.988",
  "F. Zambelli and S. Stringari, Quantized vortices and collective oscillations of a trapped Bose-Einstein condensate, Phys. Rev. Lett. *81*, 1754 (1998). DOI: 10.1103/PhysRevLett.81.1754",
  "F. Chevy, K. W. Madison and J. Dalibard, Measurement of the angular momentum of a rotating Bose-Einstein condensate, Phys. Rev. Lett. *85*, 2223 (2000). DOI: 10.1103/PhysRevLett.85.2223",
  "M. R. Matthews, B. P. Anderson, P. C. Haljan, D. S. Hall, C. E. Wieman and E. A. Cornell, Vortices in a Bose-Einstein condensate, Phys. Rev. Lett. *83*, 2498 (1999). DOI: 10.1103/PhysRevLett.83.2498",
  "K. W. Madison, F. Chevy, W. Wohlleben and J. Dalibard, Vortex formation in a stirred Bose-Einstein condensate, Phys. Rev. Lett. *84*, 806 (2000). DOI: 10.1103/PhysRevLett.84.806",
  "A. L. Gaunt, T. F. Schmidutz, I. Gotlibovych, R. P. Smith and Z. Hadzibabic, Bose-Einstein condensation of atoms in a uniform potential, Phys. Rev. Lett. *110*, 200406 (2013). DOI: 10.1103/PhysRevLett.110.200406",
  "N. Navon, R. P. Smith and Z. Hadzibabic, Quantum gases in optical boxes, Nat. Phys. *17*, 1334 (2021). DOI: 10.1038/s41567-021-01403-z",
];
refs.forEach((r, i) => c.push(REF(i + 1, r)));

/* ------------------------------------------------------------------ APPX */
c.push(H1("Appendix A: Thomas–Fermi identities used in the text"));
c.push(P("For an isotropic harmonic trap the normalization ∫_n_(**r**)_d_^3^_r_ = _N_ applied to the inverted parabola _n_(_r_) = (_μ_ − ½_mω_~0~^2^_r_^2^)/_g_ over _r_ ≤ _R_~TF~ gives _N_ = (8_π_/15)(_μ_/_g_)_R_~TF~^3^. Substituting _μ_ = ½_mω_~0~^2^_R_~TF~^2^ and _g_ = 4_πħ_^2^_a_/_m_ and solving for _R_~TF~ yields Eq. (3). Lemma 1 then follows in one line, and Eq. (5) follows from _η_ = (_ξ_/_R_~TF~)^2^ = (_a_~ho~^2^/_R_~TF~^2^)^2^."));
c.push(P("The species independence asserted in Sec. III.B is manifest in Eq. (6): the left-hand side is the dimensionless combination that fixes the TF regime, and the right-hand side contains only _η_. Any pair (_a_, _ω_~0~) that produces a given _η_ produces the same _Na_/_a_~ho~; the atom number _N_ required to reach it changes, but the regime does not. We verified this numerically for ^87^Rb at _ω_~0~/2_π_ ∈ {10, 50, 100, 200} Hz and for ^39^K at _a_ ∈ {1, 10, 100}_a_~0~, recovering Table I in every case."));
c.push(P("For the uniform potential of Sec. VIII.C the corresponding relation is _η_ = (8_πnaL_^2^)^−1^, in which the diluteness parameter _na_^3^ does not appear. The absence of a lock in that geometry is therefore not an approximation but a structural difference between harmonic and box confinement."));

/* ------------------------------------------------------------------ WRITE */
c.push(H1("Appendix B: anharmonic coefficients for a Thomas–Fermi cloud"));
c.push(P("We take the isotropic model _V_(_r_) = _Ar_^2^ + _br_^4^ with _A_ = ½_mω_~0~^2^ and, for a Gaussian beam of waist _w_~0~, _b_ = −_A_/_w_~0~^2^. The dimensionless parameter is _u_ = _bR_^2^/_A_ = −(_R_/_w_~0~)^2^."));
c.push(P("*Breathing mode.* The Thomas–Fermi density is _n_(_r_) = [_μ_ − _V_(_r_)]/_g_ with _μ_ = _AR_^2^ + _bR_^4^ fixed by _n_(_R_) = 0. Direct integration gives"));
c.push(EQ("_Ng_ = (8_π_/105)_AR_^5^(7 + 10_u_),   ⟨_r_^2^⟩ = _R_^2^(9 + 14_u_)/[3(7 + 10_u_)],", "(B1)"));
c.push(P("whose expansion is ⟨_r_^2^⟩ = (3/7)_R_^2^[1 + (8/63)_u_]. Fixing _N_ and _b_ and solving the first relation perturbatively gives _R_ = _R_~0~[1 − (2/7)_u_~0~] with _u_~0~ = _bR_~0~^2^/_A_, hence ⟨_r_^2^⟩ = (3/7)_R_~0~^2^[1 − (4/9)_u_~0~]. The monopole frequency then follows from the ratio of sum rules"));
c.push(EQ("_ω_~M~^2^ = −2⟨_r_^2^⟩ / (∂⟨_r_^2^⟩/∂_ω_~0~^2^),", "(B2)"));
c.push(P("which is applicable because the perturbation conjugate to Σ_r_~_i_~^2^ shifts _A_ alone and leaves _b_ untouched. With _R_~0~^2^ ∝ _A_^−2/5^ and _u_~0~ ∝ _A_^−7/5^ this yields _ω_~M~^2^ = 5_ω_~0~^2^[1 + (14/9)_u_~0~], i.e. Eq. (13). At _b_ = 0 the expression reduces to _ω_~M~ = 5^1/2^_ω_~0~, as it must."));
c.push(P("*Numerical verification.* Solving Eq. (B1) for _R_ at fixed _Ng_ and _b_, evaluating ⟨_r_^2^⟩ and differentiating numerically with respect to _A_, we obtain for the relative shift −7.77800 × 10^−5^ at _u_~0~ = −10^−4^ against the analytic −7.77778 × 10^−5^; −7.7822 × 10^−4^ against −7.7778 × 10^−4^ at _u_~0~ = −10^−3^; and −7.8229 × 10^−3^ against −7.7778 × 10^−3^ at _u_~0~ = −10^−2^. The departure at the last point, 0.58 %, is the expected second-order term."));
c.push(P("*Dipole mode.* Writing the coordinate of each particle as _X_ + _x_~_i_~ with Σ_x_~_i_~ = 0 and expanding _V_(_X_ + _x_~_i_~) for _V_(_x_) = ½_mω_~0~^2^_x_^2^(1 − _x_^2^/_w_~0~^2^), the terms odd in _x_~_i_~ average to zero for a symmetric cloud and the coefficient of _X_^2^ becomes ½_mω_~0~^2^[1 − 6⟨_x_^2^⟩/_w_~0~^2^], giving _ω_~D~^2^ = _ω_~0~^2^[1 − 6⟨_x_^2^⟩/_w_~0~^2^]. For the Thomas–Fermi profile ⟨_x_^2^⟩ = ⟨_r_^2^⟩/3 = _R_^2^/7, which gives the first term of Eq. (14). The coefficient of _X_^4^ is −½_mω_~0~^2^/_w_~0~^2^ per particle, and the standard Duffing shift 3_λA_~osc~^2^/2_mω_^2^ with that _λ_ gives the second term."));
c.push(P("*Limitations.* The model is isotropic; a real single-beam trap has different radial and axial anharmonicity and the two coefficients must be recomputed for the actual geometry, though the structure — partial cancellation with a residual of order a third — is not expected to change. The sum rule (B2) gives an upper bound on the lowest compressional frequency and is exact for the Thomas–Fermi monopole in a harmonic trap; its use at first order in _u_~0~ is consistent with the accuracy claimed. Corrections of order _u_~0~^2^ are neglected throughout, which Table IV justifies for _w_~0~ ≥ 100 μm."));
const doc = buildDoc("Tishin — Validity bound and finite-size degeneracy", c);
Packer.toBuffer(doc).then(b => {
  fs.writeFileSync('./out/Paper1_Validity_Bound_and_Degeneracy.docx', b);
  console.log('paper 1 written');
});
