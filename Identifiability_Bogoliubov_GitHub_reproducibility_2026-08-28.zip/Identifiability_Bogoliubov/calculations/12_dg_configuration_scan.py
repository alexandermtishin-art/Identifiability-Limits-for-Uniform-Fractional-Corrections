#!/usr/bin/env python3
"""
Configuration-scan identifiability check for the DG-motivated coefficient.

Separates two models that must not be conflated:
  A) phenomenological global uniform shift s: omega -> (1+s) omega_B;
  B) DG-motivated coefficient c_scr with configuration-dependent
     s_r = c_scr * eta_r, eta_r=(xi_r/L_r)^2.

Relative configuration ratios xi_r/xi0 and L_r/L0 are treated as known,
while the common absolute scales xi0 and L0 float.  The test reports the
Jacobian rank and the fraction of the signal derivative orthogonal to the
nuisance span.
"""
import numpy as np

HBAR=1.054571817e-34
AMU=1.66053906660e-27
M=87*AMU
A=5.3e-9
N_DENS=1e20
L0=5e-6
C_SCR=0.00833
XI0=1/np.sqrt(8*np.pi*N_DENS*A)
ETA0=(XI0/L0)**2
SY=1e-6


def rows_for_scan(J, L_ratios, xi_ratios, model='uniform'):
    rows=[]
    for lr,xr in zip(L_ratios,xi_ratios):
        j=np.arange(1,J+1,dtype=float)
        xi=XI0*xr
        L=L0*lr
        eta=(xi/L)**2
        u=(np.pi*j*xi/L)**2/2
        # Bare Bogoliubov derivatives wrt common absolute ln xi0 and ln L0.
        dxi_B=-1/(1+u)
        dL_B=-(1+2*u)/(1+u)
        if model=='uniform':
            ds=np.ones_like(j)
            dxi=dxi_B
            dL=dL_B
            rows.append(np.column_stack([ds,dxi,dL]))
        elif model=='dg':
            # Full model: omega_obs=(1+c_scr*eta) omega_B.
            # eta changes as +2 under ln xi0 and -2 under ln L0.
            fac=(C_SCR*eta)/(1+C_SCR*eta)
            dc=np.full_like(j, eta/(1+C_SCR*eta))
            dxi=dxi_B + 2*fac
            dL=dL_B - 2*fac
            rows.append(np.column_stack([dc,dxi,dL]))
        else:
            raise ValueError(model)
    return np.vstack(rows)


def metrics(X):
    signal=X[:,0]
    Z=X[:,1:]
    Q=np.linalg.qr(Z,mode='reduced')[0]
    resid=signal-Q@(Q.T@signal)
    frac=np.linalg.norm(resid)/np.linalg.norm(signal)
    rank=np.linalg.matrix_rank(X,tol=1e-12)
    # Linear Fisher uncertainty for first parameter, if full rank.
    if rank==X.shape[1]:
        cov=np.linalg.inv(X.T@X/SY**2)
        sig=np.sqrt(cov[0,0])
    else:
        sig=np.inf
    return rank,frac,np.linalg.norm(resid),sig

scans=[
    ('single configuration', [1.0], [1.0]),
    ('3 box sizes', [0.7,1.0,1.4], [1.0,1.0,1.0]),
    ('3 healing lengths / density scan', [1.0,1.0,1.0], [0.7,1.0,1.4]),
    ('common-scale scan eta fixed', [0.7,1.0,1.4], [0.7,1.0,1.4]),
    ('crossed L and xi scan', [0.7,1.0,1.4,0.8,1.2], [1.2,1.0,0.8,0.7,1.4]),
]

print('=== CONFIGURATION-SCAN IDENTIFIABILITY CHECK ===')
print(f'xi0={XI0*1e6:.6f} um, L0={L0*1e6:.3f} um, eta0={ETA0:.9e}, c_scr={C_SCR}')
print(f'per-datum relative sigma={SY:.1e}; J=1..4 per configuration')
print()
print('A) PHENOMENOLOGICAL GLOBAL UNIFORM s')
for label,lrs,xrs in scans:
    X=rows_for_scan(4,lrs,xrs,'uniform')
    rank,frac,norm,sig=metrics(X)
    ident=np.max(np.abs(X[:,1]+X[:,2]+2*X[:,0]))
    print(f'{label:34s}: rank={rank}/3, orth.frac={frac:.3e}, identity={ident:.3e}, sigma(s)={sig}')

print('\nB) DG-MOTIVATED GLOBAL c_scr WITH s_r=c_scr*eta_r')
for label,lrs,xrs in scans:
    X=rows_for_scan(4,lrs,xrs,'dg')
    rank,frac,norm,sig=metrics(X)
    # common-scale identity remains dxi+dL=-2 for the full model
    identity=np.max(np.abs(X[:,1]+X[:,2]+2*np.ones(X.shape[0])))
    # report eta spread
    etas=np.array([(XI0*xr/(L0*lr))**2 for lr,xr in zip(lrs,xrs)])
    spread=np.ptp(etas)/np.mean(etas) if len(etas)>1 else 0.0
    significance=C_SCR/sig if np.isfinite(sig) else 0.0
    print(f'{label:34s}: eta rel.range={spread:.3e}, rank={rank}/3, orth.frac={frac:.3e}, sigma(c)={sig:.3e}, c/sigma={significance:.2f}, common-scale id={identity:.2e}')

print('\nVERDICT')
print('1) A global phenomenological uniform shift s remains exactly rank-deficient under relative scans.')
print('2) A DG coefficient c_scr is a different inference problem because s_r=c_scr*eta_r varies across configurations when eta_r varies.')
print('3) If eta_r changes between configurations, the c_scr derivative is generally linearly independent of the two common absolute-scale derivatives and the Jacobian becomes full rank.')
print('4) If xi and L are scanned proportionally so eta_r is fixed, the DG coefficient remains degenerate, as expected.')
