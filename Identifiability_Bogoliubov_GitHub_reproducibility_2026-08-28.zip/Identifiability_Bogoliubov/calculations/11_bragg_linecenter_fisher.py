#!/usr/bin/env python3
"""
the identifiability manuscript, Test 2.8: Bragg-specific line-center Fisher/Cramer-Rao benchmark.

Model
-----
A weak, symmetric Bragg resonance is represented by a Gaussian response
  y(f)=A exp[-(f-f0)^2/(2 sigma_line^2)] + b
sampled across +/-3 sigma_line.  We fit f0 jointly with amplitude A, background b,
and width sigma_line.  For independent Gaussian detection noise sigma_y, the
Fisher matrix gives the local Cramer-Rao bound.

This is a spectroscopy-specific benchmark, not a complete many-body Bragg model.
It answers how line-center precision scales with linewidth, SNR, and number of
frequency samples, and whether sub-mHz center estimation is compatible with a
finite-Hz raw linewidth in principle.
"""
import numpy as np

def model(theta,f):
    A,f0,sig,b=theta
    z=(f-f0)/sig
    return A*np.exp(-0.5*z*z)+b

def jac(theta,f):
    A,f0,sig,b=theta
    z=(f-f0)/sig
    e=np.exp(-0.5*z*z)
    dA=e
    df0=A*e*z/sig
    dsig=A*e*z*z/sig
    db=np.ones_like(f)
    return np.column_stack([dA,df0,dsig,db])

def crlb(width_hz,snr,npts):
    sig=width_hz/2.354820045 # Gaussian sigma from FWHM
    f=np.linspace(-3*sig,3*sig,npts)
    theta=np.array([1.0,0.0,sig,0.0])
    noise=1/snr
    J=jac(theta,f)
    F=J.T@J/noise**2
    C=np.linalg.pinv(F)
    return np.sqrt(C[1,1])

print("=== IDENTIFIABILITY MANUSCRIPT TEST 2.8: BRAGG LINE-CENTER FISHER BENCHMARK ===")
print("Gaussian weak-response line; f0 fitted jointly with amplitude, width and background.")
print()
for width in [2.0,10.0,30.0]:
    for snr in [100,1000,10000]:
        s=crlb(width,snr,61)
        print(f"FWHM={width:5.1f} Hz, point-SNR={snr:5d}, 61 samples -> sigma_f0={s*1e3:9.3f} mHz")
    print()

target=0.190e-3
print("POINT-SNR REQUIRED FOR HARDEST 0.190 mHz TARGET (61 frequency points)")
for width in [2.0,10.0,30.0]:
    unit=crlb(width,1.0,61)
    need=unit/target
    print(f"FWHM={width:5.1f} Hz -> point-SNR ≈ {need:,.0f}")

print()
print("AVERAGING EXAMPLE")
width=2.0
single_snr=100
unit=crlb(width,single_snr,61)
shots=(unit/target)**2
print(f"For a {width:g}-Hz FWHM line and per-scan point-SNR={single_snr},")
print(f"single-scan CRLB sigma_f0={unit*1e3:.2f} mHz.")
print(f"Ideal independent averaging to 0.190 mHz requires ~{shots:.0f} equivalent scans.")
print()
print("TEST-2.8 VERDICT")
print("A raw Hz-scale linewidth does not impose a Hz-scale line-center floor.")
print("Sub-mHz estimation is allowed by the line-shape Fisher information, but requires very high")
print("effective SNR / repeated scans and, more importantly, an unbiased and stable response model.")
print("This benchmark does not include frequency drift, correlated atom-number noise, nonlinear Bragg")
print("response, finite-temperature asymmetry, or calibration systematics; those can dominate the CRLB.")
