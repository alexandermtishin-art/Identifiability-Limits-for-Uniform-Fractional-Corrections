#!/usr/bin/env python3
"""Physically motivated LHY and finite-temperature nuisance-shape diagnostic.

This is deliberately a *shape diagnostic*, not a precision Beliaev-Popov
self-energy calculation.

LHY proxy:
  Use the Lee-Huang-Yang equation of state
    mu = g n [1 + 32/(3 sqrt(pi)) sqrt(n a^3)]
  and the corresponding compressibility scale
    n dmu/dn = g n [1 + 16/sqrt(pi) sqrt(n a^3)].
  Inserting that scale into a Bogoliubov-form interpolation gives the correct
  low-k LHY sound-speed correction while retaining a k-dependent crossover.

Finite-T proxy:
  Use a first-order Popov-style condensate-density replacement
    n0/n = 1 - (T/Tc)^(3/2)
  (ideal-gas condensate fraction, used here only as a transparent diagnostic)
  in E_k = sqrt[eps_k (eps_k + 2 g n0)].

The purpose is to quantify how much these standard-physics directions project
onto a uniform multiplicative offset over the manuscript's k xi window.
"""
from pathlib import Path
import numpy as np
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parents[1]
FIGDIR = ROOT / "figures"
OUTDIR = ROOT / "outputs"
FIGDIR.mkdir(exist_ok=True)
OUTDIR.mkdir(exist_ok=True)

N = 1e20
A = 5.3e-9
TAU = 0.10  # illustrative T/Tc for the Popov proxy
S_BENCH = 2.50144e-5
X = np.geomspace(0.18, 1.8, 12)  # x = k xi

sqrt_gas = np.sqrt(N * A ** 3)
# Relative correction of the compressibility scale n dmu/dn to g n.
alpha_lhy = 16 / np.sqrt(np.pi) * sqrt_gas
# eps_k/(g n) = (k xi)^2 for xi=hbar/sqrt(2mgn).
lhy = np.sqrt((X ** 2 + 2 * (1 + alpha_lhy)) / (X ** 2 + 2)) - 1

f0 = 1 - TAU ** 1.5
finiteT = np.sqrt((X ** 2 + 2 * f0) / (X ** 2 + 2)) - 1
uniform = np.full_like(X, S_BENCH)


def projection_metrics(y):
    u = np.ones_like(y)
    mean = np.dot(u, y) / np.dot(u, u)
    resid = y - mean * u
    cosine = np.dot(u, y) / (np.linalg.norm(u) * np.linalg.norm(y))
    orth_fraction = np.linalg.norm(resid) / np.linalg.norm(y)
    return mean, resid, cosine, orth_fraction


mean_lhy, res_lhy, cos_lhy, orth_lhy = projection_metrics(lhy)
mean_T, res_T, cos_T, orth_T = projection_metrics(finiteT)

fig = plt.figure(figsize=(10.5, 4.4))
ax1 = fig.add_axes([0.08, 0.18, 0.38, 0.72])
ax1.plot(X, lhy, marker="o", label="LHY equation-of-state proxy")
ax1.plot(X, finiteT, marker="s", label=rf"Popov proxy, $T/T_c={TAU:.2f}$")
ax1.axhline(S_BENCH, linestyle="--", label="uniform benchmark $s$")
ax1.set_xlabel(r"$k\xi$")
ax1.set_ylabel(r"Fractional shift $\Delta\omega/\omega_B$")
ax1.set_title("(a) Standard-physics corrections are structured in momentum")
ax1.legend(frameon=False, fontsize=9)

ax2 = fig.add_axes([0.57, 0.18, 0.38, 0.72])
ax2.plot(X, res_lhy, marker="o", label="LHY residual")
ax2.plot(X, res_T, marker="s", label="finite-T residual")
ax2.axhline(0, linewidth=1)
ax2.set_xlabel(r"$k\xi$")
ax2.set_ylabel("Residual after best uniform component")
ax2.set_title("(b) Nonuniform component after projection onto $s$")
ax2.legend(frameon=False, fontsize=9)
fig.savefig(FIGDIR / "Figure5_LHY_finiteT_structured_shapes.png", dpi=350, bbox_inches="tight")
plt.close(fig)

with open(OUTDIR / "16_lhy_finiteT_structured_shapes_values.txt", "w") as f:
    f.write(f"sqrt(n a^3) = {sqrt_gas:.9e}\n")
    f.write(f"LHY compressibility relative correction = {alpha_lhy:.9e}\n")
    f.write(f"LHY shift range = {lhy.min():.9e} to {lhy.max():.9e}\n")
    f.write(f"LHY best uniform component = {mean_lhy:.9e}\n")
    f.write(f"LHY cosine with uniform direction = {cos_lhy:.9f}\n")
    f.write(f"LHY orthogonal fraction = {orth_lhy:.9f}\n")
    f.write(f"finite-T proxy T/Tc = {TAU:.3f}, n0/n = {f0:.9f}\n")
    f.write(f"finite-T shift range = {finiteT.min():.9e} to {finiteT.max():.9e}\n")
    f.write(f"finite-T best uniform component = {mean_T:.9e}\n")
    f.write(f"finite-T cosine with uniform direction = {cos_T:.9f}\n")
    f.write(f"finite-T orthogonal fraction = {orth_T:.9f}\n")

print("sqrt(n a^3) =", sqrt_gas)
print("LHY cosine/orthogonal fraction =", cos_lhy, orth_lhy)
print("finite-T cosine/orthogonal fraction =", cos_T, orth_T)
print("wrote", FIGDIR / "Figure5_LHY_finiteT_structured_shapes.png")
