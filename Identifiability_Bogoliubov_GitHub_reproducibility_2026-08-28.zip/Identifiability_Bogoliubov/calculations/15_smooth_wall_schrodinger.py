#!/usr/bin/env python3
"""Smooth-wall one-dimensional Schrödinger diagnostic.

Uses the flat-bottom potential
    V(x)=V0/2 * [1+tanh((|x|-L/2)/w)]
to compute low-lying eigen-wave-numbers. Propagates them through the
Bogoliubov dispersion and tests whether the wall-induced spectral shift is
uniform. Also reports Jacobian conditioning with fixed versus floating wall
parameters.
"""
from pathlib import Path
import numpy as np
import matplotlib.pyplot as plt
from scipy.linalg import eigh_tridiagonal

ROOT = Path(__file__).resolve().parents[1]
FIGDIR = ROOT / "figures"
OUTDIR = ROOT / "outputs"
FIGDIR.mkdir(exist_ok=True)
OUTDIR.mkdir(exist_ok=True)

HBAR = 1.054571817e-34
AMU = 1.66053906660e-27
M = 87 * AMU
A = 5.3e-9
N_DENS = 1e20
XI0 = 1 / np.sqrt(8 * np.pi * N_DENS * A)
LREF = 5e-6
JMODES = 8


def eig_k(L=LREF, w=0.01 * LREF, kappa0L=100.0, J=JMODES, N=2600):
    l = L / LREF
    ww = w / LREF
    ymax = max(0.95, 0.5 * l + 10 * ww + 0.35)
    y = np.linspace(-ymax, ymax, N)
    dy = y[1] - y[0]
    edge = 0.5 * (1 + np.tanh((np.abs(y) - 0.5 * l) / ww))
    U0 = kappa0L ** 2
    diag = 2 / dy ** 2 + U0 * edge
    off = -np.ones(N - 1) / dy ** 2
    vals = eigh_tridiagonal(diag, off, select="i", select_range=(0, J - 1),
                            check_finite=False, tol=1e-10)[0]
    return np.sqrt(vals) / LREF


def bog_omega(k, xi=XI0):
    c = HBAR / (np.sqrt(2) * M * xi)
    return c * k * np.sqrt(1 + (k * xi) ** 2 / 2)


kappa0L = 100.0
w0 = 0.01 * LREF
j = np.arange(1, JMODES + 1)
k_hard = np.pi * j / LREF
k_smooth = eig_k(w=w0, kappa0L=kappa0L)
frac_w = bog_omega(k_smooth) / bog_omega(k_hard) - 1
constant = np.mean(frac_w)
structured = frac_w - constant


def logfreq(xi=XI0, L=LREF, w=w0, kappa0L=kappa0L):
    return np.log(bog_omega(eig_k(L=L, w=w, kappa0L=kappa0L), xi))


def deriv(param, h=2e-4):
    base = {"xi": XI0, "L": LREF, "w": w0, "kappa0L": kappa0L}
    bp, bm = dict(base), dict(base)
    bp[param] *= np.exp(h)
    bm[param] *= np.exp(-h)
    return (logfreq(**bp) - logfreq(**bm)) / (2 * h)


def deriv_V0(h=2e-4):
    return (logfreq(kappa0L=kappa0L * np.exp(h / 2)) -
            logfreq(kappa0L=kappa0L * np.exp(-h / 2))) / (2 * h)


def orthfrac(Z):
    Q = np.linalg.qr(Z, mode="reduced")[0]
    one = np.ones(JMODES)
    r = one - Q @ (Q.T @ one)
    return np.linalg.norm(r) / np.linalg.norm(one)


dxi, dL, dw, dV = deriv("xi"), deriv("L"), deriv("w"), deriv_V0()
one = np.ones(JMODES)
rank_fixed = np.linalg.matrix_rank(np.column_stack([one, dxi, dL]), tol=1e-8)
rank_float = np.linalg.matrix_rank(np.column_stack([one, dxi, dL, dw, dV]), tol=1e-8)
of_fixed = orthfrac(np.column_stack([dxi, dL]))
of_float = orthfrac(np.column_stack([dxi, dL, dw, dV]))

fig, ax = plt.subplots(figsize=(7.4, 5.0))
ax.plot(j, frac_w, marker="o", label="smooth-wall fractional spectral shift")
ax.axhline(constant, linestyle="--", label="best constant component")
ax.plot(j, structured, marker="s", label="structured residual after constant subtraction")
ax.set_xlabel("Standing-mode index $j$")
ax.set_ylabel(r"Fractional shift $\Delta\omega_j/\omega_j$")
ax.set_title("Smooth-wall correction is not a uniform spectral offset")
ax.legend(frameon=False)
fig.savefig(FIGDIR / "Figure4_smooth_wall_nuisance_shape.png", dpi=350, bbox_inches="tight")
plt.close(fig)

with open(OUTDIR / "15_smooth_wall_schrodinger_values.txt", "w") as f:
    f.write(f"wall shift range: {frac_w.min():+.9e} to {frac_w.max():+.9e}\n")
    f.write(f"structured residual peak-to-peak: {np.ptp(structured):.9e}\n")
    f.write(f"fixed wall rank([s,xi,L])={rank_fixed}/3\n")
    f.write(f"fixed wall signal orthogonal fraction={of_fixed:.9e}\n")
    f.write(f"floating wall rank([s,xi,L,w,V0])={rank_float}/5\n")
    f.write(f"floating wall signal orthogonal fraction={of_float:.9e}\n")
print("wall shift range", frac_w.min(), frac_w.max())
print("structured peak-to-peak", np.ptp(structured))
print("fixed/floating orthogonal fraction", of_fixed, of_float)
print("wrote", FIGDIR / "Figure4_smooth_wall_nuisance_shape.png")
