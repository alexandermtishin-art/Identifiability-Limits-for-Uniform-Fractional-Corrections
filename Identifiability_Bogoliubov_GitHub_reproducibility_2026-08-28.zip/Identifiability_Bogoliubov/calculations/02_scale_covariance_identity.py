#!/usr/bin/env python3
"""Symbolic/numerical check of the scale-orbit identifiability theorem.

This is a reproducibility companion, not a numerical proof requirement.
It verifies the homogeneous-scale identity used in the strengthened the identifiability manuscript
and then checks the Bogoliubov standing-mode corollary.
"""

import sympy as sp


def general_scale_covariance_check():
    A, B, nu = sp.symbols("A B nu", positive=True, finite=True, nonzero=True)
    u = B / A
    F = sp.Function("F")
    omega = A ** (-nu) * F(u)

    dlnA = sp.simplify(A * sp.diff(omega, A) / omega)
    dlnB = sp.simplify(B * sp.diff(omega, B) / omega)
    euler_sum = sp.simplify(dlnA + dlnB)

    expected = -nu
    residual = sp.simplify(euler_sum - expected)
    assert residual == 0

    # Hence the uniform fractional signal vector 1 is in the nuisance span:
    # 1 = -(1/nu) (d ln omega/d ln A + d ln omega/d ln B), nu != 0.
    return dlnA, dlnB, euler_sum


def bogoliubov_corollary_check():
    L, xi, j = sp.symbols("L xi j", positive=True, finite=True, nonzero=True)
    pi = sp.pi
    k = pi * j / L

    # Overall constants are irrelevant to logarithmic derivatives.
    # c ∝ xi^{-1}; exact Bogoliubov dispersion:
    omega = xi ** (-1) * k * sp.sqrt(1 + k**2 * xi**2 / 2)

    dlnL = sp.simplify(L * sp.diff(omega, L) / omega)
    dlnxi = sp.simplify(xi * sp.diff(omega, xi) / omega)
    identity = sp.simplify(dlnL + dlnxi)
    assert sp.simplify(identity + 2) == 0

    # Uniform fractional direction is therefore exactly
    # 1 = -(1/2) (dlnomega/dlnL + dlnomega/dlnxi).
    return dlnL, dlnxi, identity


def finite_rescaling_check():
    lam, L, xi, j = sp.symbols(
        "lambda L xi j", positive=True, finite=True, nonzero=True
    )
    k = sp.pi * j / L
    omega = xi ** (-1) * k * sp.sqrt(1 + k**2 * xi**2 / 2)

    omega_scaled = sp.simplify(
        omega.subs({L: lam * L, xi: lam * xi}, simultaneous=True)
    )
    ratio = sp.simplify(omega_scaled / omega)
    assert sp.simplify(ratio - lam ** (-2)) == 0
    return ratio


if __name__ == "__main__":
    dA, dB, euler = general_scale_covariance_check()
    dL, dxi, bog = bogoliubov_corollary_check()
    finite_ratio = finite_rescaling_check()

    print("Scale-orbit identifiability theorem companion check")
    print("----------------------------------------------------")
    print("General representation: omega(A,B) = A^(-nu) F(B/A)")
    print("d ln omega / d ln A =", dA)
    print("d ln omega / d ln B =", dB)
    print("sum =", euler, "[PASS: equals -nu]")
    print()
    print("Bogoliubov standing-mode corollary")
    print("d ln omega / d ln L =", dL)
    print("d ln omega / d ln xi =", dxi)
    print("sum =", bog, "[PASS: equals -2]")
    print("finite common rescaling omega(lambda L, lambda xi)/omega(L,xi) =", finite_ratio)
    print("[PASS: uniform fractional signal lies exactly in the scale-orbit nuisance direction]")
