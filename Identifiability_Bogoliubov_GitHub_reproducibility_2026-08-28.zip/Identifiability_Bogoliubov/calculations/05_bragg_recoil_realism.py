#!/usr/bin/env python3
"""
the identifiability manuscript, Test 2.4: Bragg/recoil realism stress test.

Goal:
Test whether the calibrated-k rescue of Test 2.3 remains identifiable once
measurement-level nuisances are included.

Uniform-gas Bogoliubov dispersion:
    omega(k) = sqrt(eps_k (eps_k + 2 g n))/hbar
             = c k sqrt(1 + k^2 xi^2/2).

Screening model:
    omega -> (1+s) omega,  s = c_scr eta.

Parameters in the linearized log-frequency fit:
    s                mode-independent fractional screening
    ln xi            density/healing-length nuisance
    ln k_scale       calibrated momentum-scale nuisance (Gaussian prior)
    q0               additive frequency-zero offset in Hz (Bragg detuning origin)
    qinh             conservative density-inhomogeneity shape nuisance

The inhomogeneity shape is represented by the second derivative of ln omega
with respect to ln xi, which is the leading even correction from a narrow
distribution of density/healing length.  Its amplitude is allowed to float
freely.  This is a shape stress-test, not a microscopic finite-T theory.

A separate global frequency-scale nuisance is exactly degenerate with s.
Therefore an absolute time/frequency reference is logically mandatory.  We
quantify the required prior on that reference.
"""

import numpy as np

HBAR=1.054571817e-34
H=2*np.pi*HBAR
AMU=1.66053906660e-27
M=87*AMU
A=5.3e-9
N_DENS=1e20
LREF=5e-6
C_SCR=0.00833

G=4*np.pi*HBAR**2*A/M
XI=1/np.sqrt(8*np.pi*N_DENS*A)
ETA=(XI/LREF)**2
TARGET=C_SCR*ETA

def omega(k):
    eps=HBAR**2*k**2/(2*M)
    return np.sqrt(eps*(eps+2*G*N_DENS))/HBAR

def dln_dlnxi(k):
    u=(k*XI)**2/2
    return -1/(1+u)

def d2ln_dlnxi2(k):
    # d/d ln xi of -1/(1+u), u propto xi^2
    u=(k*XI)**2/2
    return 2*u/(1+u)**2

def build(J, include_offset=True, include_inhom=True, include_freqscale=False):
    j=np.arange(1,J+1,dtype=float)
    k=np.pi*j/LREF
    w=omega(k)
    f=w/(2*np.pi)
    u=(k*XI)**2/2

    cols=[np.ones(J), dln_dlnxi(k), (1+2*u)/(1+u)]  # s, lnxi, lnk
    names=["s","lnxi","lnk"]

    if include_offset:
        # additive frequency offset df0 produces d ln f = df0/f
        cols.append(1/f)
        names.append("df0_Hz")
    if include_inhom:
        cols.append(d2ln_dlnxi2(k))
        names.append("inh_shape")
    if include_freqscale:
        cols.append(np.ones(J))
        names.append("freqscale")
    return j,k,f,np.column_stack(cols),names

def sigma_s(J=8, sigma_rel=1e-6, pk=2e-6, pfreq=None,
            sigma_df0=None, include_inhom=True):
    j,k,f,X,names=build(J,True,include_inhom,pfreq is not None)
    F=(X.T@X)/(sigma_rel**2)
    # k prior
    ik=names.index("lnk")
    if pk is not None:
        F[ik,ik]+=1/pk**2
    # additive detuning-zero prior in Hz
    io=names.index("df0_Hz")
    if sigma_df0 is not None:
        F[io,io]+=1/sigma_df0**2
    # global timebase/frequency scale prior
    if pfreq is not None:
        ig=names.index("freqscale")
        F[ig,ig]+=1/pfreq**2

    evals,evecs=np.linalg.eigh(F)
    tol=1e-11*np.max(evals)
    null=evecs[:,evals<=tol]
    if null.size and np.any(np.abs(null[0,:])>1e-8):
        return np.inf, names, f
    cov=np.linalg.pinv(F,rcond=1e-13)
    return np.sqrt(max(cov[0,0],0)), names, f

print("=== IDENTIFIABILITY MANUSCRIPT TEST 2.4: BRAGG/RECOIL REALISM STRESS TEST ===")
print(f"87Rb, n=1e14 cm^-3, xi={XI*1e6:.6f} um, eta(ref L=5 um)={ETA:.9e}")
print(f"benchmark screening fractional shift s={TARGET:.9e}")
print()

J=8
j,k,f,_,_=build(J)
print("MODE / MOMENTUM / FREQUENCY SCALE")
print("j   k (1/um)    f_Bog (Hz)    screening shift (mHz)")
for jj,kk,ff in zip(j,k,f):
    print(f"{int(jj):2d}  {kk*1e-6:8.4f}   {ff:10.3f}     {ff*TARGET*1e3:10.4f}")

print()
print("Required center precision corresponding to relative 1e-6:")
for jj,ff in zip(j,f):
    print(f"j={int(jj):2d}: {ff*1e-6*1e3:.4f} mHz")

print()
print("=== LOGICAL TIMEBASE TEST ===")
sig,_,_=sigma_s(J=8,sigma_rel=1e-6,pk=2e-6,pfreq=None,sigma_df0=1e-4,include_inhom=True)
print(f"With no free global frequency-scale nuisance: sigma(s)={sig:.3e}, target/Sigma={TARGET/sig:.2f}")
sig_free,_,_=sigma_s(J=8,sigma_rel=1e-6,pk=2e-6,pfreq=1e99,sigma_df0=1e-4,include_inhom=True)
print(f"If global frequency scale is completely free: sigma(s)={sig_free}")
print("=> an absolute time/frequency reference is mandatory, exactly as an absolute k anchor is.")

print()
print("=== FREQUENCY-SCALE PRIOR REQUIREMENT ===")
for pf in [1e-4,1e-5,5e-6,2e-6,1e-6,5e-7,1e-7,1e-8]:
    sig,_,_=sigma_s(J=8,sigma_rel=1e-6,pk=2e-6,pfreq=pf,sigma_df0=1e-4,include_inhom=True)
    snr=0 if not np.isfinite(sig) else TARGET/sig
    print(f"sigma_fscale/f={pf:.1e}: sigma(s)={sig:.3e}, target/Sigma={snr:.2f}")

print()
print("=== k-SCALE + ADDITIVE DETUNING-OFFSET STRESS TEST ===")
for pk in [1e-5,5e-6,2e-6,1e-6,5e-7]:
    for sdf in [1e-2,1e-3,1e-4,1e-5]:
        sig,_,_=sigma_s(J=8,sigma_rel=1e-6,pk=pk,pfreq=1e-8,
                        sigma_df0=sdf,include_inhom=True)
        print(f"pk={pk:.1e}, sigma_df0={sdf:.0e} Hz -> target/Sigma={TARGET/sig:.2f}")
    print()

print("=== MODE-COUNT / PER-MODE PRECISION WITH SHAPE NUISANCE ===")
for JJ in [4,5,6,8,10,12]:
    for sy in [2e-6,1e-6,5e-7]:
        sig,_,_=sigma_s(J=JJ,sigma_rel=sy,pk=2e-6,pfreq=1e-8,
                        sigma_df0=1e-4,include_inhom=True)
        print(f"j=1..{JJ:2d}, sigma_rel={sy:.1e}: target/Sigma={TARGET/sig:.2f}")
    print()

print("=== PULSE-DURATION REQUIREMENT (FOURIER WIDTH ONLY) ===")
print("A Fourier-limited pulse of duration tau has a line width of order 1/tau.")
print("To make the transform width itself comparable to a sub-mHz center precision")
print("requires very long pulses; however line-center estimation can beat the raw width by SNR.")
for width_mhz in [100,10,1,0.3]:
    tau=1/(width_mhz*1e-3)
    print(f"raw width {width_mhz:6.1f} mHz -> tau ~ {tau:8.1f} s")

print()
print("FINAL TEST-2.4 VERDICT:")
print("1) The calibrated-k route is NOT killed by exact-dispersion identifiability.")
print("2) It requires TWO absolute metrology anchors: momentum k and frequency/timebase.")
print("3) A free global frequency scale is exactly degenerate with screening.")
print("4) With k prior ~2e-6, frequency-scale prior ~1e-8, an additive detuning-zero prior")
print("   at 1e-4 Hz, and a conservative free inhomogeneity-shape nuisance, 8-12 momentum")
print("   points at ~1e-6 relative center precision remain statistically viable.")
print("5) The practical bottleneck is not rank but spectroscopy: the benchmark shifts are")
print("   only ~10-100 mHz across the chosen k range, while 1e-6 relative center precision")
print("   corresponds to sub-mHz to few-mHz line-center estimation.")
print("6) Therefore the route survives as a precision-spectroscopy proposal, but it is not")
print("   experimentally cheap. A literature novelty/feasibility check is now mandatory.")
