# Structural Identifiability of Uniform Bogoliubov-Spectrum Corrections

Reproducibility package for the calculations accompanying the manuscript on
structural identifiability of uniform fractional corrections to the Bogoliubov
spectrum of a homogeneous Bose gas.

**This repository contains calculation code, generated numerical outputs, and
calculation-generated figures only. It intentionally does not contain the
manuscript DOCX/PDF and contains no material from other papers.**

## Quick start

```bash
python -m pip install -r requirements.txt
python run_all.py
```

`run_all.py` executes every script in `calculations/` in a fresh Python process
and writes its console output to `outputs/`. Calculation-generated figures are
written to `figures/`.

## Calculation map

| Script | Purpose / manuscript result |
|---|---|
| `01_exact_dispersion_and_truncation.py` | Exact Bogoliubov dispersion; failure of the truncated standing-mode intercept strategy and exact scale degeneracy checks. |
| `02_scale_covariance_identity.py` | Direct numerical/symbolic check of the scale-covariance identity used in the structural-degeneracy argument. |
| `03_boundary_calibration_identifiability.py` | Boundary/absolute-scale calibration checks. |
| `04_minimal_observable_rescue.py` | Tests which external observable directions restore local identifiability. |
| `05_bragg_recoil_realism.py` | Bragg/recoil calibration realism stress tests. |
| `06_full_nuisance_identifiability.py` | Full nuisance-space Jacobian/Fisher conditioning. |
| `07_quantitative_prior_budget.py` | Quantitative prior budget and all Table-I 5-sigma boundaries. |
| `08_calibration_budget_map.py` | Two-dimensional calibration-budget map (Figure 3). |
| `09_published_capability_comparison.py` | Comparison with representative published homogeneous-box spectroscopy (Table II quantities). |
| `10_quantum_statistical_limit.py` | Ideal SQL particle-number/resource estimates (Table III). |
| `11_bragg_linecenter_fisher.py` | Bragg line-center Cramer-Rao/Fisher benchmark. |
| `12_dg_configuration_scan.py` | Distinguishes global phenomenological `s` from configuration-dependent `c_scr` inference under eta scans. |
| `13_svd_configuration_scan.py` | Column-normalized Jacobian SVD and rank-recovery visualization (Figure 2). |
| `14_finite_wall_identifiability.py` | Finite-wall identifiability diagnostic. |
| `15_smooth_wall_schrodinger.py` | Smooth-wall 1D Schrodinger eigenproblem and structured wall-nuisance shape (Figure 4). |
| `16_lhy_finiteT_structured_shapes.py` | Physically motivated LHY equation-of-state and finite-temperature Popov shape diagnostics (Figure 5). |

## Key reproducibility checks

Running the full package reproduces, among other quantities:

- Global phenomenological `s`, column-normalized Jacobian singular values:
  `1.72570328, 0.148149185, 2.4146e-16`.
- Configuration-dependent global `c_scr`, corresponding singular values:
  `1.65398985, 0.50102877, 0.11527248`.
- Baseline Fisher significance: approximately `5.24 sigma`.
- One-at-a-time 5-sigma prior boundaries (baseline-held):
  - wave-number scale: `2.246e-6`,
  - healing-length scale: `5.806e-6`,
  - global frequency scale: `1.495e-6`,
  - four structured nuisance priors relaxed together: `2.525e-6`.
- Smooth-wall diagnostic: nonuniform spectral residual peak-to-peak
  `4.97e-3`; fixed independently known wall profile formally restores full
  rank but with weak conditioning, whereas floating wall parameters recover an
  almost scale-degenerate direction.
- LHY/finite-temperature shape diagnostic over `0.18 <= k xi <= 1.8`:
  each has about 24% of its shape norm orthogonal to the best uniform component,
  despite a cosine overlap of about 0.97 in magnitude with the uniform direction.

See `VALIDATION.md` for the run audit and numerical summary.

## Physical-scope note for Figure 5

The LHY and finite-temperature calculations are deliberately transparent
**shape diagnostics**, not a replacement for a complete Beliaev-Popov
self-energy calculation. The LHY proxy uses the standard dilute-gas equation
of state and its compressibility correction; the finite-temperature proxy uses
a first-order Popov-style condensate-density replacement. Their role in the
manuscript is to demonstrate how ordinary many-body effects can project strongly
onto a uniform direction while retaining a momentum-dependent residual.

Relevant standard references are T. D. Lee, K. Huang, and C. N. Yang,
*Phys. Rev.* **106**, 1135 (1957), and H. Shi and A. Griffin, *Phys. Rep.*
**304**, 1-87 (1998), DOI 10.1016/S0370-1573(98)00015-5.

## Notes

- No experimental data are included or analyzed.
- Numerical values are protocol-dependent design/stress-test quantities, not
  universal experimental limits.
- The DG-motivated coefficient is used as a benchmark/model-dependent inference
  target where explicitly stated. The exact uniform-`s` identifiability result
  does not depend on the microscopic origin of the benchmark.
