#!/usr/bin/env python3
"""Run every calculation in this reproducibility package.

Each script is executed in a fresh Python process. Standard output and standard
error are written to outputs/<script>_stdout.txt. The run stops on the first
failure and returns a nonzero exit code.
"""
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
CALC = ROOT / "calculations"
OUT = ROOT / "outputs"
OUT.mkdir(exist_ok=True)

scripts = sorted(CALC.glob("*.py"))
print(f"Running {len(scripts)} calculation scripts")
for script in scripts:
    logfile = OUT / f"{script.stem}_stdout.txt"
    print(f"[RUN] {script.name}")
    proc = subprocess.run([sys.executable, str(script)], cwd=ROOT,
                          text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    logfile.write_text(proc.stdout, encoding="utf-8")
    if proc.returncode != 0:
        print(proc.stdout)
        print(f"[FAIL] {script.name}; see {logfile}")
        raise SystemExit(proc.returncode)
    print(f"[ OK] {script.name}")
print("All calculations completed successfully.")
