import numpy as np
hbar=1.054571817e-34; amu=1.66053907e-27
m=87*amu; a=5.3e-9
def xi(n): return 1/np.sqrt(8*np.pi*n*a)
def cs(n): return np.sqrt(4*np.pi*hbar**2*a*n/m**2)
print("=== WORKING POINT: Rb87 box, n=1e14 cm^-3, L=5 um ===")
n=1e20; L=5e-6; e=(xi(n)/L)**2; c=cs(n)
print(f" xi={xi(n)*1e6:.4f} um  eta={e:.4e}  n a^3={n*a**3:.3e}  c={c*1e3:.3f} mm/s  mu/h={4*np.pi*hbar*a*n/(m*2*np.pi)*hbar/hbar:.1f}")
mu=4*np.pi*hbar**2*a*n/m
print(f" mu/h={mu/(2*np.pi*hbar):.1f} Hz  mu/kB={mu/1.380649e-23*1e9:.1f} nK")
print("\n j | f_j [Hz] | QP rel = 2.4674 j^2 eta | QP abs [Hz] | screening rel (c=8.33e-3) | screening abs [mHz]")
csr=8.33e-3  # synced 2026-08-23 to match C_SCR used in the kill-test scripts (was 8e-3)
for j in range(1,6):
    f=c*j/(2*L); qp=(np.pi**2/4)*j**2*e; sc=csr*e
    print(f" {j} | {f:8.2f} | {qp:.4e}            | {qp*f:10.4f}  | {sc:.4e}            | {sc*f*1e3:9.3f}")
print(f"\n required relative resolution B = c_scr*eta = {csr*e:.3e}")
print(f" compare harmonic-trap requirement 6.71e-06  -> box is {6.71e-6/(csr*e):.2f}x easier")
for Q in [1e2,1e3,1e4]:
    for S in [10,30]:
        print(f"   Q={Q:.0e} S={S:2d}: N_shots={(1/(Q*S*csr*e))**2:9.2f}  ({(1/(Q*S*csr*e))**2*30/3600:6.3f} h)")
print("\n=== eta reachable at fixed diluteness (box vs harmonic) ===")
print(" box, n a^3 = 1.5e-5 fixed (n=1e14 cm^-3):")
for L in [2e-6,3e-6,5e-6,10e-6,20e-6]:
    print(f"   L={L*1e6:5.1f} um -> eta={(xi(n)/L)**2:.3e}, f_1={cs(n)/(2*L):7.1f} Hz")
print(" harmonic at same diluteness n(0)a^3=1.5e-5: eta fixed at ~8e-4 by Eq.(6). No lever.")
